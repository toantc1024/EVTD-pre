
import {
  initializeApp
} from "./firebase-app.js";
const firebaseConfig = {
  apiKey: "AIzaSyD68tUQTr02XIRSlOCidLxADehWFZ3yjMU",
  authDomain: "evtd-app.firebaseapp.com",
  databaseURL: "https://evtd-app-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "evtd-app",
  storageBucket: "evtd-app.appspot.com",
  messagingSenderId: "43580014900",
  appId: "1:43580014900:web:4d8b4d3406cb9330c92561",
  measurementId: "G-GFHLFDQBM5"
};
const app = initializeApp(firebaseConfig);

import {
  getDatabase,
  ref,
  set,
  child,
  get,
  onChildChanged,
  update
} from "./firebase-database.js";

 
const db = getDatabase();
const dbRef = ref(db);

function AuthenticateUser(data, user) {
  get(child(dbRef, "UserList/" + user)).then((snapshot) => {
    var first = JSON.parse(data),
        second = JSON.parse(snapshot.val().yourDictionary);
    Object.keys(first).forEach(function(key){
      if(!second.hasOwnProperty(key)){
        second[key] = first[key];
    }});
  update(ref(db, "UserList/" +user), {
      yourDictionary: JSON.stringify(second)
        })
        .then(() => {})
        .catch((error) => {});
  });
}

export function main(data,user, initiate) {
  if(user!=""){
  if (initiate == true){
    const dbRef = ref(db);
    function callData(valueData, user){
      chrome.storage.local.set({
        'color_code':valueData[user].evtdColor
      })
      chrome.storage.local.set({
        'yourDictionary':valueData[user].yourDictionary
      })
  
    }
    onChildChanged(dbRef, (snapshot)=>callData(snapshot.val() , user), {
      onlyOnce: false
    });

  }
 else {
  AuthenticateUser(data,user);
 }
}
}
