function src_update(lang){
}
//-------------------------------------------------------------------------------------------------//
var modal_today = document.getElementById("today-modal");
var us_on, vn_on;
var span = document.getElementsByClassName("close_today")[0];
var get_btn = document.getElementById("get_w");
get_btn.onclick = function() {
  modal_today.style.display = "block"; us_on = 1; vn_on = 1; ex_on = 1;
  mean_us.innerHTML = "<i class='fas fa-caret-down'></i>";
  document.getElementById("word-m1").style.display = "none";
  mean_vn.innerHTML = "<i class='fas fa-caret-down'></i>";
  document.getElementById("word-m2").style.display = "none";
  ex_t.innerHTML = "<i class='fas fa-caret-down'></i>";
  document.getElementById("ex_w").style.display = "none";
}
// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal_today.style.display = "none";responsiveVoice.cancel();
  }
document.getElementById("word-us").onclick = function(){
  responsiveVoice.speak(localStorage.getItem("word-t2"), "UK English Male");
}
document.getElementById("word-uk").onclick = function(){
  responsiveVoice.speak(localStorage.getItem("word-t2"), "US English Male");
}
document.getElementById("word-m1").onclick = function(){
  responsiveVoice.speak(localStorage.getItem("word-t3"), "UK English Female");
}
document.getElementById("word-m1").onclick = function(){
  responsiveVoice.speak(localStorage.getItem("word-t3"), "UK English Female");
}
var mean_vn = document.getElementById("mean-vn");
mean_vn.onclick = function(){
   if(vn_on === 1){
     mean_vn.innerHTML = "<i class='fas fa-caret-right'></i>";
     document.getElementById("word-m2").style.display = "block";
     vn_on = 0;
   } else {
     mean_vn.innerHTML = "<i class='fas fa-caret-down'></i>";
     document.getElementById("word-m2").style.display = "none";
     vn_on = 1;
    }
}
var mean_us = document.getElementById("mean-us");
mean_us.onclick = function(){
   if(us_on === 1){
     mean_us.innerHTML = "<i class='fas fa-caret-right'></i>";
     document.getElementById("word-m1").style.display = "block";
     us_on= 0;
   } else {
     mean_us.innerHTML = "<i class='fas fa-caret-down'></i>";
     document.getElementById("word-m1").style.display = "none";
     responsiveVoice.cancel();
     us_on = 1;
    }
}

var ex_t = document.getElementById("ex_t");
ex_t.onclick = function(){
   if(ex_on === 1){
     ex_t.innerHTML = "<i class='fas fa-caret-right'></i>";
     document.getElementById("ex_w").style.display = "block";
     ex_on = 0;
   } else {
     ex_t.innerHTML = "<i class='fas fa-caret-down'></i>";
     document.getElementById("ex_w").style.display = "none";
     ex_on = 1;
    }
}