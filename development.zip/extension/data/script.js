import {
  initializeApp
} from "./firebase-app.js";
const firebaseConfig = {
  apiKey: "AIzaSyD68tUQTr02XIRSlOCidLxADehWFZ3yjMU",
  authDomain: "evtd-app.firebaseapp.com",
  databaseURL: "https://evtd-app-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "evtd-app",
  storageBucket: "evtd-app.appspot.com",
  messagingSenderId: "43580014900",
  appId: "1:43580014900:web:4d8b4d3406cb9330c92561",
  measurementId: "G-GFHLFDQBM5"
};
const app = initializeApp(firebaseConfig);

import {
  getDatabase,
  ref,
  set,
  child,
  get
} from "./firebase-database.js";

const db = getDatabase();

const name = document.getElementById('nameInp');
const username = document.getElementById('userInp');
const pass = document.getElementById('passInp');
const repass = document.getElementById('repassInp');
const submit = document.getElementById('sub_btn');
//-----------------------------------------------VALIDATION- EVTD------------------------//
function isEmptyOrSpaces(str) {
  return str === null || str.match(/^ *$/) !== null;
}

function Validation(obj) {
  console.log(obj);
  if (!isEmptyOrSpaces(obj.value) && obj.value.length >= 5) {
    document.getElementById("p" + obj.id).style.visibility = "hidden";
    return true;
  } else {
    document.getElementById("p" + obj.id).style.visibility = "visible";
    return false;
  }
}

function RepassValid() {
  if (repass.value === pass.value) {
    document.getElementById("prepass").style.visibility = "hidden";
    return true;
  } else {
    document.getElementById("prepass").style.visibility = "visible";
    return false;
  }
}
//---------------------------------------REGISTER USer TO FIREBASe----------------------//

function RegisterUser() {
  const dbRef = ref(db);
  get(child(dbRef, "UserList/" + username.value)).then((snapshot) => {
    if (snapshot.exists()) {
      document.getElementById('account_state').style.visibility = "visible";
    } else {
      set(ref(db, "UserList/"+username.value), //Đặt giá trị tên người dùng.
      {
        language: "vi",
        fullname: name.value,
        username: username.value,
        password: encPass(),
        yourDictionary: "{}",
        dailyGoal: "{}",
        userDream: "{}",
        numberofWord: 2,
        languageTreasure: "{}",
        evtdColor: 0,
        colorChanged: false,
        languageChanged: false,
        deletedHistory: false
      })
        .then(() => {
          container.classList.remove("active");
          document.getElementById('account_notification').style.visibility = "visible";
          document.getElementById('userlogin').value = username.value;
          document.getElementById('userpass').value = "";
        })
        .catch((error) => {
          console.log("error" + error);
        })
    }
  });
}
function encPass() {
  return CryptoJS.AES.encrypt(pass.value, pass.value).toString();
}
//
name.addEventListener('change', function () {
  Validation(name);
});
pass.addEventListener('change', function () {
  Validation(pass);
});
repass.addEventListener('change', function () {
  RepassValid();
});
username.addEventListener('change', function () {
  document.getElementById('account_state').style.visibility = "hidden";
  Validation(username);
});
submit.addEventListener('click', function () {
  if (Validation(name) && Validation(pass) && Validation(username) && RepassValid()) RegisterUser();
});





const container = document.querySelector(".container"),
  pwShowHide = document.querySelectorAll(".showHidePw"),
  pwFields = document.querySelectorAll(".password"),
  signUp = document.querySelector(".signup-link"),
  login = document.querySelector(".login-link");

pwShowHide.forEach(eyeIcon => {
  eyeIcon.addEventListener("click", () => {
    pwFields.forEach(pwField => {
      if (pwField.type === "password") {
        pwField.type = "text";

        pwShowHide.forEach(icon => {
          icon.classList.replace("uil-eye-slash", "uil-eye");
        })
      } else {
        pwField.type = "password";
        pwShowHide.forEach(icon => {
          icon.classList.replace("uil-eye", "uil-eye-slash");
        })
      }
    })
  })
})

signUp.addEventListener("click", () => {
  container.classList.add("active");
  document.getElementById('account_state').style.visibility = "hidden";


});
login.addEventListener("click", () => {
  container.classList.remove("active");
  document.getElementById('user_status').style.visibility = 'hidden';
  document.getElementById('password_status').style.visibility = 'hidden';
});


const userlogin = document.getElementById('userlogin'),
  passlogin = document.getElementById('userpass'),
  loginbtn = document.getElementById('loginbtn');

function AuthenticateUser() {
  const dbRef = ref(db);
  get(child(dbRef, "UserList/" + userlogin.value)).then((snapshot) => {
    if (isEmptyOrSpaces(passlogin.value)) {
      return false;
    };
    if (snapshot.exists()) {
      let dbpass = decPass(snapshot.val().password);
      if (dbpass == passlogin.value) {
        document.getElementById('user_status').style.visibility = 'hidden';
        document.getElementById('password_status').style.visibility = 'hidden';
        loginData(userlogin.value, passlogin.value);
      } else {
        document.getElementById('password_status').style.visibility = 'visible';
        document.getElementById('user_status').style.visibility = 'hidden';
      }
    } else {
      document.getElementById('user_status').style.visibility = 'visible';
      document.getElementById('password_status').style.visibility = 'hidden';
    }
  });
}

function decPass(dbpass) {
  return CryptoJS.AES.decrypt(dbpass, passlogin.value).toString(CryptoJS.enc.Utf8);
}
userlogin.addEventListener('change', function () {
  userlogin.value = userlogin.value;
})

function loginData(user, pass) {
  localStorage.setItem("keepLoggedIn", 'yes');
  localStorage.setItem("user", JSON.stringify(user));
  chrome.storage.local.set({"userAccount": user})

  localStorage.setItem("pass", JSON.stringify(pass));

  localStorage.setItem('evtd_FirstTimeLogin', 1);
  window.location = "./home/index.html";
  
}
loginbtn.addEventListener('click', AuthenticateUser);

window.onload = function () {
  
  var style_code = ["linear-gradient(315deg, #4158D0 0%, #C850C0 46%, #FFCC70 100%)",
  "linear-gradient(315deg, #f5c62c 0%, #fca606 46%, #ff831d 100%)",
  " linear-gradient(315deg, rgba(255,15,15,1) 0%, rgba(255,46,46,1) 3%, rgba(255,213,13,1) 97%)",
  "linear-gradient(315deg, rgba(3,214,223,1) 0%, rgba(231,225,4,1) 91%, rgba(240,233,2,1) 100%)",
  "linear-gradient(315deg,rgb(92, 35, 247) ,rgb(81, 107, 255) 46%,rgb(255, 111, 183) 100%)",
  "linear-gradient(315deg, rgba(0,255,141,1) 0%, rgba(34,150,255,1) 81%, rgba(11,110,255,1) 97%)",
  "linear-gradient(315deg, rgba(66,212,255,1) 0%, rgba(66,153,255,1) 16%, rgba(13,52,255,1) 100%)",
  "linear-gradient(315deg, rgba(255,66,66,1) 0%, rgba(255,66,130,1) 18%, rgba(255,238,0,1) 100%)",
  "linear-gradient(315deg, rgba(4,214,235,1) 0%, rgba(118,0,255,1) 49%, rgba(248,27,255,1) 82%)"];
   document.body.style.background = style_code[localStorage.getItem('style_id')];
  if (localStorage.getItem('user') != null)   window.location = "./home/index.html";
}

///
