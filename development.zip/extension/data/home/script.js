
import {
  initializeApp
} from "../firebase-app.js";
const firebaseConfig = {
  apiKey: "AIzaSyD68tUQTr02XIRSlOCidLxADehWFZ3yjMU",
  authDomain: "evtd-app.firebaseapp.com",
  databaseURL: "https://evtd-app-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "evtd-app",
  storageBucket: "evtd-app.appspot.com",
  messagingSenderId: "43580014900",
  appId: "1:43580014900:web:4d8b4d3406cb9330c92561",
  measurementId: "G-GFHLFDQBM5"
};
const app = initializeApp(firebaseConfig);

import { getDatabase, ref, query,set, child, get, onValue, onChildAdded, onChildChanged, onChildRemoved, update} from "../firebase-database.js";
var userName;
const db = getDatabase(); 
function evtdFilterElement(attribute, value){
  responsiveVoice.cancel();
  var obj = document.getElementById('modalwordCardSync').children[0].children;
  for(let k = 0; k < obj.length; k++){
    var card = document.getElementById('modalwordCardSync').children[0].children[k];
    var coin = 0;
    if(attribute=='type')coin=1;
    var class_e = 'evtdHiddenElement'+attribute;
    var compare = card.children[0].children[1].children[coin].innerText;
    if(value=="Tất cả")compare=value;

    if(compare!=value){
        if(!hasClass(card, class_e))addClass(card, class_e);
      } else {
        if(hasClass(card,class_e)) removeClass(card, class_e);
      }    
  }
}
function hasClass(el, className)
{
    if (el.classList)
        return el.classList.contains(className);
    return !!el.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'));
}

function addClass(el, className)
{
    if (el.classList)
        el.classList.add(className)
    else if (!hasClass(el, className))
        el.className += " " + className;
}

function removeClass(el, className)
{
    if (el.classList)
        el.classList.remove(className)
    else if (hasClass(el, className))
    {
        var reg = new RegExp('(\\s|^)' + className + '(\\s|$)');
        el.className = el.className.replace(reg, ' ');
    }
}
function  evtdFilterSearchInputfilter(text){
  
  var direct = document.getElementById('modalwordCardSync').children[0].children;
    for(let k = 0; k < direct.length; k++){
      if(direct[k].children[0].children[0].innerText.indexOf(text)<0){
        if(!hasClass(direct[k], 'evtdHiddenElementSearch'))addClass(direct[k], 'evtdHiddenElementSearch');
      } else {
        if(hasClass(direct[k],'evtdHiddenElementSearch')) removeClass(direct[k], 'evtdHiddenElementSearch');
      }    
    }
    
}
document.getElementById('evtdFlashCardOpenModal').addEventListener('click', function(){
    var groupUnique = {};
    const dbRef = ref(db);
    get(child(dbRef, "UserList/" + JSON.parse(userName) + "/languageTreasure")).then((snapshot) => {
      var languageTreasure = JSON.parse(snapshot.val());
      Object.keys(languageTreasure).forEach(function (group) {
        groupUnique[group] = 1;
      })
      document.getElementById('evtdFlashCardGroup').innerHTML = ``;
      Object.keys(groupUnique).forEach(function(group){

        var option = document.createElement('option');
        option.innerHTML = group;
        document.getElementById('evtdFlashCardGroup').appendChild(option);
      })
    });
    LoadFlashEVTD();
    
});
document.getElementById('evtdFlashCardGroup').addEventListener('change', function(){
  LoadFlashEVTD();
});
function LoadFlashEVTD(){
  const dbRef = ref(db);

  localStorage.setItem('indexFlashCard', 0);
  get(child(dbRef, "UserList/" + JSON.parse(userName) + "/languageTreasure")).then((snapshot) => {
    var ListOfCards = {};
    var group = document.getElementById('evtdFlashCardGroup').value;
    var languageTreasure = JSON.parse(snapshot.val());
    if(!jQuery.isEmptyObject(languageTreasure)){
      Object.keys(languageTreasure[group]).forEach(function(type){
        Object.keys(languageTreasure[group][type]).forEach(function(word){
          var bundle = {},
              means = languageTreasure[group][type][word]['mean'];
           var   random = Math.floor(Math.random()*means.length);
          bundle[word] = {
            'group':group,
            'type':type,
            'mean':means[random]
          }
          ListOfCards[word] = bundle[word];
        })            
      })
      
     localStorage.setItem('dataCard', JSON.stringify(ListOfCards));
    localStorage.setItem('sizeofFlashCard', Object.keys(ListOfCards).length);
    setCard();
  }

  });

}
document.getElementById('evtdFlashCardGroupLeft').addEventListener('click', function(){
  var index = parseInt(localStorage.getItem('indexFlashCard'));
  if(index>=1){
    localStorage.setItem('indexFlashCard', index-1);
    setCard();
  }
});
document.getElementById('evtdFlashCardGroupRight').addEventListener('click', function(){
  var size = parseInt(localStorage.getItem('sizeofFlashCard')),
      index = parseInt(localStorage.getItem('indexFlashCard'));
  if(index<size-1){
    localStorage.setItem('indexFlashCard', index+1);
    setCard();
  }
});
function setCard(){
  var current = parseInt(localStorage.getItem('indexFlashCard')),
      data = JSON.parse(localStorage.getItem('dataCard'));
  // console.log('set: ',data[current]);
  console.log('At: ',current);
  document.getElementById('dataFlashWord').innerHTML =
  document.getElementById('dataFlashTitle').innerHTML = Object.keys(data)[current];
  document.getElementById('dataFlashType').innerHTML = data[Object.keys(data)[current]]['type'];
  document.getElementById('dataFlashMean').innerHTML = data[Object.keys(data)[current]]['mean'];
}
function loadEventListener(){
  document.getElementById('inputGroupSelect01Modal').addEventListener('change', function(){
     document.getElementById('inputGroupSelect02Modal').innerHTML = `<option>Tất cả</option>`;;
     var group = this.value;
     const dbRef = ref(db);
     get(child(dbRef, "UserList/"+JSON.parse(userName)+"/languageTreasure")).then((snapshot)=>{
            var treasure =  JSON.parse(snapshot.val());
            if(group=="Tất cả"){
              // "Delete all"
            } else {
              Object.keys(treasure[group]).forEach(function(key){
                var op = document.createElement('option');
                op.innerHTML = key;
                document.getElementById('inputGroupSelect02Modal').appendChild(op);
              });
            }

          });
  });
  document.getElementById('inputGroupSelect01').addEventListener('change', function(){
    evtdFilterElement('group', this.value);
  });
  document.getElementById('inputGroupSelect02').addEventListener('change', function(){
    evtdFilterElement('type', this.value);
  });
  document.getElementById('inputGroupSelect03').addEventListener('change', function(){
    evtdQuickSort(this.value);
  })
}

function evtdQuickSort(type){
  responsiveVoice.cancel();
  var subjects = document.getElementById('modalwordCardSync').children[0].children;
  var subjectsArray = Array.from(subjects);
  let sorted = subjectsArray.sort(function(n,r){
    function val(e){
      if(type=='Mới nhất'||type=="Cũ nhất"){
        return parseInt(e.getAttribute('etime'));
      } else if ("A - Z"==type||type=="Z - A"){
        return e.children[0].children[0].innerText;        
      }
    }
      if(type=="Mới nhất"||type=="Z - A") return val(n)>val(r)?-1:val(n)>val(r)?1:0;
      if(type=="Cũ nhất"||type=="A - Z") return val(n)<val(r)?-1:val(n)>val(r)?1:0;
    });
  var be = document.getElementById('modalwordCardSync').children[0];
  be.innerHTML = ``;
  sorted.forEach(e => be.appendChild(e));
}
function AuthenticateUser(){
  if(localStorage.getItem('keepLoggedIn')=='yes'){
    userName = localStorage.getItem('user');
  } else {
    userName = sessionStorage.getItem('user');
  }
  if(userName == null){
    window.location = '../index.html';
  }
  localStorage.setItem('hasdeleted',0);
  localStorage.setItem('modified', 0);
  const dbRef = ref(db);
var style_code = ["linear-gradient(315deg, #4158D0 0%, #C850C0 46%, #FFCC70 100%)",
"linear-gradient(315deg, #f5c62c 0%, #fca606 46%, #ff831d 100%)",
" linear-gradient(315deg, rgba(255,15,15,1) 0%, rgba(255,46,46,1) 3%, rgba(255,213,13,1) 97%)",
"linear-gradient(315deg, rgba(3,214,223,1) 0%, rgba(231,225,4,1) 91%, rgba(240,233,2,1) 100%)",
"linear-gradient(315deg,rgb(92, 35, 247) ,rgb(81, 107, 255) 46%,rgb(255, 111, 183) 100%)",
"linear-gradient(315deg, rgba(0,255,141,1) 0%, rgba(34,150,255,1) 81%, rgba(11,110,255,1) 97%)",
"linear-gradient(315deg, rgba(66,212,255,1) 0%, rgba(66,153,255,1) 16%, rgba(13,52,255,1) 100%)",
"linear-gradient(315deg, rgba(255,66,66,1) 0%, rgba(255,66,130,1) 18%, rgba(255,238,0,1) 100%)",
"linear-gradient(315deg, rgba(4,214,235,1) 0%, rgba(118,0,255,1) 49%, rgba(248,27,255,1) 82%)"];

document.getElementById('evtdAddNewWordinfoModal_selectGroup').onchange = function(){
  this.parentNode.children[0].value =  this.options[this.selectedIndex].text;
};
document.getElementById('evtdAddNewWordinfoModal_selectType').onchange = function(){
  this.parentNode.children[0].value =  this.options[this.selectedIndex].text;
};
document.getElementById('evtdEditNewWord_selectGroup').onchange = function(){
  this.parentNode.children[0].value =  this.options[this.selectedIndex].text;
};
document.getElementById('evtdEditNewWord_selectType').onchange = function(){
  this.parentNode.children[0].value =  this.options[this.selectedIndex].text;
};
function cardloader(dictionary){
  var hist = document.getElementById('history-sync');
  hist.innerHTML = ``;
  var dict = dictionary;

      Object.keys(dict).forEach(function(key){
        var definitions = [];
        var examples = [];
      
        var card = document.createElement('div'),
          card_header = document.createElement('div'),
          card_body = document.createElement('div'),
          card_title = document.createElement('div'),
          card_text = document.createElement('div');
      card.className = 'card mt-2';
      card_header.className = 'card-header';
      card_body.className = 'card-body';
      card_title.className = 'card-title';
      card_text.className = 'card-text';

      card_header.innerHTML = dict[key]['timestamp'];
      card_title.innerHTML  = key;
      card_text.innerHTML = dict[key]['mean'];
      card.appendChild(card_header);
      if (dict[key].hasOwnProperty('loader')){
        if(dict[key]['loader'].hasOwnProperty('relatedWord'))delete dict[key]['loader']['relatedWord'];
        Object.keys(dict[key]['loader']).forEach(function(k){
           var def = dict[key]['loader'][k];
          
           for(let i = 0; i < Object.keys(def).length; i++){
            var processing = Object.keys(def)[i];
              var expand = def[Object.keys(def)[i]];
              if(expand.length!=0){
                processing = processing + " ("+ Object.keys(expand[0])[0] + ": "+  expand[0][Object.keys(expand[0])[0]]+")";
                for(let j = 0; j < Object.keys(expand).length; j++){
                  examples.push([Object.keys(expand[j])[0]]);
                  //,expand[j][Object.keys(expand[j])[0]]
                }
              }
              definitions.push(processing);
            }
          });
      }
      
      var Tag =document.createElement('div');
      var defTag = document.createElement('div');
      for (var i = 0; i < definitions.length; i++){
        var def = document.createElement('span');
        def.innerHTML = definitions[i];
        defTag.appendChild(def);
      }
      Tag.appendChild(defTag);
      var exTag = document.createElement('div');
      for(var i = 0; i < examples.length; i++){
        var ex = document.createElement('span');
        ex.innerHTML = examples[i];
        exTag.appendChild(ex);
      }
      Tag.appendChild(exTag);
      Tag.style.display = 'none';
      Tag.className = 'EvtdWordSuggestionPackage';
      card_body.appendChild(card_title);
      card_body.appendChild(card_text);
      card.appendChild(card_body);
      card.appendChild(Tag);
      hist.appendChild(card);  
    });
  document.getElementById('evtdNewWordSuggestion').innerHTML = hist.innerHTML;
  for(let i = 0; i < hist.children.length; i++){
    hist.children[i].removeChild(hist.children[i].querySelector('.EvtdWordSuggestionPackage'));
  }
  document.getElementById('evtdModalDeleteList').innerHTML = document.getElementById('history-sync').innerHTML;
  
  var suggestion = document.getElementById('evtdNewWordSuggestion').children;

  for(let k = 0; k < suggestion.length; k++){
    var accept = document.createElement('button');
    accept.innerHTML = 'Thay thế';
    accept.addEventListener('click', function(){
      document.getElementById('modalCardReplaceDivContainer').innerHTML = this.parentNode.parentNode.lastChild.innerHTML; 
    });

    
    accept.setAttribute('class', 'evtdNewWordSuggestionoptionFeed showmodalsugesstion');
    accept.setAttribute('data-show-modal-suggestion', 'modalCardReplace');    
    document.getElementById('evtdNewWordSuggestion').children[k].children[0].appendChild(accept);
  }
  suggestion = document.getElementsByClassName('evtdNewWordSuggestionoptionFeed');
  for(let k = 0; k < suggestion.length; k++){
    suggestion[k].addEventListener('click', function(){
      var btn = document.createElement('button');
      document.getElementById('modalCardReplace_accept').innerHTML= ``;
      btn.setAttribute('type', 'button');
      btn.setAttribute('class', 'btn'); 
      btn.setAttribute('data-bs-dismiss', 'modal');
      btn.innerHTML = 'Đồng ý';
      document.getElementById('modalCardReplace_accept').appendChild(btn);
      if (suggestion[k].hasAttribute('data-show-modal-suggestion')) showModal(suggestion[k].getAttribute('data-show-modal-suggestion'));

      btn.addEventListener('click', function(){
        document.getElementById('evtdAddNewWordinfoModal_card').children[0].children[0].children[0].value = suggestion[k].parentNode.parentNode.children[1].children[0].innerHTML;
        document.getElementById('evtdAddNewWordinfoModal_card').children[0].children[3].children[0].value = '';
        document.getElementById('evtdAddNewWordinfoModal_card').children[0].children[2].children[0].value = '';
        document.getElementsByClassName('evtdFieldAdd_mean')[0].innerHTML = ``;
        document.getElementsByClassName('evtdFieldAdd_example')[0].innerHTML = ``;
        var  list_def = document.getElementById('modalCardReplaceDivContainer').children[0].children,
             list_ex = document.getElementById('modalCardReplaceDivContainer').children[1].children;
        for(let i = 0; i < list_def.length; i++){
            var f = document.createElement('div');
            f.setAttribute('class', 'input-group mb-1 evtdInputFieldCreateJquery_mean');
            f.innerHTML = `
            <textarea type="text" class="form-control mt-1 shadow-none"  spellcheck="false"  placeholder="Nhập định nghĩa" aria-label="" aria-describedby="basic-addon1"></textarea>
            <button class="deleteEVTDInputField" type="button"><i class="fa-solid fa-delete-left"></i></button>
            `;
            f.children[0].value = list_def[i].innerHTML;
            document.getElementsByClassName('evtdFieldAdd_mean')[0].appendChild(f);            
        }
        for(let i = 0; i < list_ex.length; i++){
          var f = document.createElement('div');
          f.setAttribute('class', 'input-group mb-1 evtdInputFieldCreateJquery_example');
          f.innerHTML = `
          <input type="text" class="form-control mt-1 shadow-none" spellcheck="false" placeholder="Nhập câu ví dụ" aria-label="" aria-describedby="basic-addon1">
          <button class="deleteEVTDInputField" type="button"><i class="fa-solid fa-delete-left"></i></button>
          `;
          f.children[0].value = list_ex[i].innerHTML;
          document.getElementsByClassName('evtdFieldAdd_example')[0].appendChild(f);            
      }
          
      });
    })
  }
}
document.getElementById('goalNumberofWord').addEventListener('click', function(){
  if(this.parentNode.children[0].value==0||this.parentNode.children[0].value==null||this.parentNode.children[0].value<=0)return;
  update(ref(db, "UserList/" + JSON.parse(userName)), {
    numberofWord: this.parentNode.children[0].value
  })
  var coin = this.parentNode.children[0].value;
  document.getElementById('evtdGoalFlushGroup').innerHTML = ``;
  get(child(dbRef, "UserList/"+JSON.parse(userName)+"/dailyGoal")).then((snapshot)=>{
    var dates = JSON.parse(snapshot.val());
    Object.keys(dates).forEach(function(date){
      var li = document.createElement('li');
      li.className = 'list-group-item';
      li.innerHTML = date + ", " +dates[date] + " / "+ coin+ " từ vựng. ("+Math.round(dates[date]/coin*100)+"%)";
      document.getElementById('evtdGoalFlushGroup').appendChild(li);
    })
  })
})

document.getElementById('evtdGoalFlushGroupDream').addEventListener('click', function(){
  // $('#dreamContainer').append(``);
  var dream = document.createElement('div');
  dream.style ="border:1px solid rgba(255,255,255,.37); padding:5px; border-radius:5px; margin-bottom:5px;";
  dream.innerHTML = `

  <div class="input-group mb-1 evtdInputFieldCreateJquery_mean">
    <textarea type="text" class="form-control mt-1 shadow-none" style='height:100px'
      spellcheck="false" placeholder="Gửi gắm ước mơ của bạn vào đây" aria-label=""
      aria-describedby="basic-addon1"></textarea>

  </div>
  <div class="input-group mb-1 evtdInputFieldCreateJquery_example">
    <input type="date" name="trip-start" value="2022-06-22" class="form-control mt-1 shadow-none"
      spellcheck="false" placeholder="Nhập câu ví dụ" aria-label="" aria-describedby="basic-addon1">
    <button class="deleteEVTDInputField evtdGoalFlushGroupDream" type="button"><i
        class="fa-solid fa-flag"></i></button>
  </div>
  `;
  dream.children[0].children[0].addEventListener('change',function(){
    dream.children[1].children[1].innerHTML = `<i class="fa-solid fa-flag"></i>`;
  })
  dream.children[0].children[0].addEventListener('keyup',function(){
    dream.children[1].children[1].innerHTML = `<i class="fa-solid fa-flag"></i>`;
  })
  dream.children[1].children[0].addEventListener('change',function(){
    dream.children[1].children[1].innerHTML = `<i class="fa-solid fa-flag"></i>`;
  })
  dream.children[1].children[1].addEventListener('click', function(){
    var text = this.parentNode.parentNode.children[0].children[0].value,
        date = this.parentNode.children[0].value;
    if(text==""){
      dream.parentNode.removeChild(dream);
    } else {
    get(child(dbRef, "UserList/"+JSON.parse(userName)+"/userDream")).then((snapshot)=>{
        var userDreams = JSON.parse(snapshot.val());
       userDreams[text] = date;
        update(ref(db, "UserList/" + JSON.parse(userName)), {
          userDream:JSON.stringify(userDreams) 
        })
        
        this.innerHTML = `<i class="fa-solid fa-check"></i>`;
      });
    }
     })
  document.getElementById('dreamContainer').appendChild(dream);
})
document.getElementById('evtdGoalFlushGroupDream').addEventListener('click', function(){
 
})
document.getElementById('evtdModalOpenButton').addEventListener('click', function(){
    document.getElementById('evtdGoalFlushGroup').innerHTML = ``;
    document.getElementById('dreamContainer').innerHTML = ``;
    get(child(dbRef, "UserList/"+JSON.parse(userName))).then((snapshot)=>{
      var dates = JSON.parse(snapshot.val().dailyGoal);
      var dreams = JSON.parse(snapshot.val().userDream);
      for(let k = 0; k < Object.keys(dreams).length; k++){
        var dreamText = Object.keys(dreams)[k],
            dreamDate = dreams[Object.keys(dreams)[k]];
            var dream = document.createElement('div');
            dream.style ="border:1px solid rgba(255,255,255,.37); padding:5px; border-radius:5px; margin-bottom:5px;";
            dream.innerHTML = `
          
            <div class="input-group mb-1 evtdInputFieldCreateJquery_mean">
              <textarea type="text" class="form-control mt-1 shadow-none" style='height:100px'
                spellcheck="false" placeholder="Gửi gắm ước mơ của bạn vào đây" aria-label=""
                aria-describedby="basic-addon1"></textarea>
          
            </div>
            <div class="input-group mb-1 evtdInputFieldCreateJquery_example">
              <input type="date" name="trip-start" value="2022-06-22" class="form-control mt-1 shadow-none"
                spellcheck="false" placeholder="Nhập câu ví dụ" aria-label="" aria-describedby="basic-addon1">
              <button class="deleteEVTDInputField evtdGoalFlushGroupDream" type="button"><i
                  class="fa-solid fa-flag"></i></button>
            <button style="display:none">Text goes here</button>
            </div>
            `;
          dream.children[1].children[2].innerHTML = dream.children[0].children[0].value = dreamText;
            dream.children[1].children[0].value = dreamDate;
            dream.children[0].children[0].addEventListener('change',function(){
              dream.children[1].children[1].innerHTML = `<i class="fa-solid fa-flag"></i>`;
            })
            dream.children[0].children[0].addEventListener('keyup',function(){
              dream.children[1].children[1].innerHTML = `<i class="fa-solid fa-flag"></i>`;
            })
            dream.children[1].children[0].addEventListener('change',function(){
              dream.children[1].children[1].innerHTML = `<i class="fa-solid fa-flag"></i>`;
            })
            dream.children[1].children[1].addEventListener('click', function(){
              get(child(dbRef, "UserList/"+JSON.parse(userName)+"/userDream")).then((snapshot)=>{
                var userDreams = JSON.parse(snapshot.val());
                var text = this.parentNode.parentNode.children[0].children[0].value,
                  date = this.parentNode.children[0].value;
              if(text==""){
                var val = this.parentNode.children[2].innerHTML
                delete userDreams[val];
                this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);
          
              } else {
                  userDreams[text]=date;
              }
              update(ref(db, "UserList/" + JSON.parse(userName)), {
                userDream:JSON.stringify(userDreams) 
              })
              this.innerHTML = `<i class="fa-solid fa-check"></i>`;
               })
              });

            document.getElementById('dreamContainer').appendChild(dream);
          }
      Object.keys(dates).forEach(function(date){
        var li = document.createElement('li');
        li.className = 'list-group-item';
        li.innerHTML = date + ", " +dates[date] + " / "+snapshot.val().numberofWord + " từ vựng. ("+Math.round(dates[date]/snapshot.val().numberofWord*100)+"%)";
        document.getElementById('evtdGoalFlushGroup').appendChild(li);
      })
      document.getElementById('goalNumberofWord').parentNode.children[0].value = snapshot.val().numberofWord;

    })
});
document.getElementById('reDirectAcceptPageModal').addEventListener('click', function(){
  window.open("https://github.com/ghelix2004/EVTD-pre/blob/main/Help.md");
});
$(".cardz").on("click", () => {
  $(".cardz .front").toggleClass("flipped");
  $(".cardz .back").toggleClass("back-flipped");
  $(".cardz").addClass("lift-card");
  setTimeout(() => {
    $(".cardz").removeClass("lift-card");
  }, 1000);
});

chrome.storage.local.set({"userAccount": JSON.parse(userName)});
function UpdateColor(code){
  document.body.style.background = style_code[code];
  document.getElementById('redirectPageModalOptionEVTD').style.background = style_code[code];
  document.getElementsByClassName('evtdDropdownMenu')[0].style.background = style_code[code];
  document.getElementById('evtdMenuOptionModal').style.background = style_code[code];
  document.getElementById('directPageModal').style.background = style_code[code];
  document.getElementById('languageModalBook_background').style.background = style_code[code];
  document.getElementById('evtdAddNewWordinfoModal').style.background = style_code[code];
  document.getElementById('evtdEditinfoModal').style.background = style_code[code];
  document.getElementById('ManagerInfoModal').style.background = style_code[code];
  document.getElementById('dataFlashCardEVTD').style.background = style_code[code];
  document.getElementById('ContributelanguageModalBook_background').style.background = style_code[code];
}
const evtdColor = ref(db, 'UserList/'+JSON.parse(userName)+'/evtdColor');
onValue(evtdColor, (snapshot) => {
UpdateColor(JSON.parse(snapshot.val()));
}, {
  onlyOnce:false
})
const yourDictionary = ref(db, 'UserList/'+JSON.parse(userName)+'/yourDictionary');
onValue(yourDictionary, (snapshot) => {
  cardloader(JSON.parse(snapshot.val()));
}, {
  onlyOnce:false
})
const languageTreasure = ref(db, 'UserList/'+JSON.parse(userName)+'/languageTreasure');
function UpdateLang(){
console.log('->');
  if(localStorage.getItem('hasdeleted')!=1&&localStorage.getItem('modified')!=1) severCardLoader()
            else {
              localStorage.setItem('hasdeleted',0);
              localStorage.setItem('modified', 0);
              UpdateSortQuery(null, null);
            }
}
onValue(languageTreasure, (snapshot) => {
    UpdateLang();
            }, {
  onlyOnce:false
})
loadEventListener();


get(child(dbRef, "UserList/"+JSON.parse(userName))).then((snapshot)=>{
  document.getElementById('userName').innerHTML = `Chào, ` + snapshot.val().fullname;
  document.getElementById('evtdNameUser').innerText = `Chào, `+ snapshot.val().fullname;
  document.getElementById('userNameMobile').innerHTML = `Chào, `+ snapshot.val().fullname;
  document.getElementById('evtdLoaderScreen').setAttribute('class', 'fade');
  UpdateColor(snapshot.val().evtdColor);

//
var colorOpt = document.getElementsByClassName('ColorOptionButton')
for(let i = 0; i < colorOpt.length; i++){
  colorOpt[i].children[0].style.background = style_code[i];
  colorOpt[i].children[0].onmouseover = function(){
    document.getElementById('directPageModal').style.background = style_code[i];
    
  }
  colorOpt[i].children[0].setAttribute('data-bs-dismiss', 'modal');
  colorOpt[i].children[0].setAttribute('color', i);
  colorOpt[i].children[0].onclick = function(){
    UpdateColor(this.getAttribute('color'));
    document.getElementById('directPageModal').style.background = style_code[this.getAttribute('color')];
    localStorage.setItem('style_id',  this.getAttribute('color'));
    update(ref(db, "UserList/" + JSON.parse(userName)), {
      evtdColor: this.getAttribute('color'),
      colorChanged: true
    })
    .then(() => {})
    .catch((error) => {});
  };
  colorOpt[i].children[0].onmouseout = function(){
    document.getElementById('directPageModal').style.background = document.body.style.background;
  }
}

//
document.getElementById('_evtdResetButtonId').onclick = function(){
  update(ref(db, "UserList/" + JSON.parse(userName)), {
    yourDictionary: '{}',
    deletedHistory: true
  })
  .then(() => {})
  .catch((error) => {});
  document.getElementById('history-sync').innerHTML = ``;
}
document.getElementById('evtdModalDeleteButton').onclick = function(){
  document.getElementById('evtdModalDeleteList').innerHTML = document.getElementById('history-sync').innerHTML;
}  
//

// cardloader(JSON.parse(snapshot.val().yourDictionary));
document.getElementById('evtdLoaderScreen').style = 'opacity:0!important';
document.getElementById('evtdLoaderScreen').style = 'display:none!important';
     
}); 
}
window.onload = AuthenticateUser();

Array.from(document.getElementsByClassName('showmodal')).forEach( (e) => {
  e.addEventListener('click', function(element) {
    element.preventDefault();
    if (e.hasAttribute('data-show-modal')) {
      showModal(e.getAttribute('data-show-modal'));
    }
  }); 
});
function showModal(modal) {
  const mid = document.getElementById(modal);
  let evtdModal = new bootstrap.Modal(mid);
  evtdModal.show();
}

document.getElementById('evtdFilterSearchButtonClear').addEventListener('click', function(){
  document.getElementById('evtdFilterSearchInput').value = '';
  responsiveVoice.cancel();
  evtdFilterSearchInputfilter('');
});
document.getElementById('evtdFilterSearchInput').addEventListener('keypress', function(event){
  if (event.key === "Enter") {
  responsiveVoice.cancel();
  evtdFilterSearchInputfilter(this.value);
  }
})
function severCardLoader() {
  const dbRef = ref(db);  
  var image = [];
  get(child(dbRef, "UserList/" + JSON.parse(userName) + "/languageTreasure")).then((snapshot) => {
     var languageTreasure = JSON.parse(snapshot.val());
     if(languageTreasure==null){
      localStorage.removeItem('user');
      localStorage.removeItem('pass');
      localStorage.removeItem('keepLoggedIn');
      sessionStorage.removeItem('user');
      sessionStorage.removeItem('pass');
      chrome.storage.local.set({"userAccount": null});
      window.location = '../index.html';
     }
     var dict = {};
     
     var groupUnique = {},
     typeUnique = {};
     document.getElementById('modalwordCardSync').children[0].innerHTML = '';
     Object.keys(languageTreasure).forEach(function (group) {
       Object.keys(languageTreasure[group]).forEach(function (type) {
         Object.keys(languageTreasure[group][type]).forEach(function (word) {
         var   example = languageTreasure[group][type][word]['example'],
            mean = languageTreasure[group][type][word]['mean'],
            time = languageTreasure[group][type][word]['time'];
                       image = languageTreasure[group][type][word]['image'];
            groupUnique[group] = 1;
            typeUnique[type] = 1;
            
    
    var card = document.createElement('div'),
    card_header = document.createElement('div'),
    card_title = document.createElement('h5'),
    card_btn_container = document.createElement('div'),
    card_btnGroup = document.createElement('div'),
    card_btnType = document.createElement('div'),
    card_ul = document.createElement('ul'),
    card_navitem_mean = document.createElement('li'),
    card_navitem_ex = document.createElement('li'),
    card_navitem_btn = document.createElement('li'),
    card_navitem_image = document.createElement('li'),
    card_a_mean = document.createElement('a'),
    card_a_image = document.createElement('a'),
    card_a_example = document.createElement('a');
    card.setAttribute('class', 'card mb-2');
    
    card.setAttribute('etime', time);
    //links

      card_navitem_mean.setAttribute('class', 'nav-item'),
      card_a_mean.setAttribute('class', 'nav-link active'),
      card_a_mean.setAttribute('aria-current', 'true'),
      card_a_mean.setAttribute('data-bs-toggle', 'tab'),
      card_a_mean.setAttribute('href', '#dhcp');
      card_navitem_mean.appendChild(card_a_mean);
  
      card_navitem_ex.setAttribute('class', 'nav-item'),
      card_a_example.setAttribute('class', 'nav-link'),
      card_a_example.setAttribute('data-bs-toggle','tab'),
      card_a_example.setAttribute('href', '#static');
      card_navitem_ex.appendChild(card_a_example);
      card_a_image.setAttribute('class', 'nav-link'),
      card_a_image.setAttribute('data-bs-toggle','tab'),
      card_a_image.setAttribute('href', '#void');
      card_navitem_image.appendChild(card_a_image);
      card_navitem_image.setAttribute('class', 'nav-item');
      card_navitem_btn.setAttribute('class', 'nav-item'),
      card_ul.setAttribute('class', 'nav nav-tabs card-header-tabs');
      card_ul.setAttribute('data-bs-tabs','tabs');
      card_ul.appendChild(card_navitem_mean);
      card_ul.appendChild(card_navitem_ex);
      card_ul.appendChild(card_navitem_image);

      card_ul.appendChild(card_navitem_btn);
      var this_language = 'as';
      var card_sound = document.createElement('div');
      card_sound.setAttribute('class', 'btn btnTypeEVTDWORD');
      card_sound.setAttribute('lang_speak','null');
      card_sound.style.marginLeft = '5px';
      card_sound.addEventListener('click', function(){
    	var lang_speak = { "af": "Afrikaans Male", "am": "UK English Female", "ar": "Arabic Female", "as": "UK English Female", "az": "UK English Female", "ba": "UK English Female", "bg": "UK English Female", "bn": "UK English Female", "bo": "UK English Female", "bs": "Bosnian Male", "ca": "French Canadian Female", "cs": "Czech Male", "cy": "Welsh Male", "da": "Danish Male", "de": "Deutsch Female", "dv": "UK English Female", "el": "Greek male", "en": "US English Female", "es": "Spanish Latin American Female", "et": "Estonian Male", "eu": "UK English Female", "fa": "UK English Female", "fi": "Finnish Female", "fil": "Filipino Female", "fj": "UK English Female", "fo": "UK English Female", "fr": "French Female", "fr-CA": "French Canadian Female", "ga": "UK English Female", "gl": "UK English Female", "gu": "UK English Female", "he": "UK English Female", "hi": "Hindi Female", "hr": "Serbo-Croatian Male", "hsb": "UK English Female", "ht": "UK English Female", "hu": "Hungarian Female", "hy": "Armenian Male", "id": "Indonesian Female", "ikt": "UK English Female", "is": "Icelandic Female", "it": "Italian Female", "iu": "UK English Female", "iu-Latn": "UK English Female", "ja": "Japanese Female", "ka": "UK English Female", "kk": "UK English Female", "km": "UK English Female", "kmr": "UK English Female", "kn": "UK English Female", "ko": "Korean Male", "ku": "UK English Female", "ky": "UK English Female", "lo": "UK English Female", "lt": "Latvian Male", "lv": "Latvian Male", "mg": "UK English Female", "mi": "UK English Female", "mk": "Macedonian Male", "ml": "UK English Female", "mn-Cyrl": "UK English Female", "mn-Mong": "UK English Female", "mr": "UK English Female", "ms": "UK English Female", "mt": "UK English Female", "mww": "UK English Female", "my": "UK English Female", "nb": "Norwegian Female", "ne": "Nepali", "nl": "Dutch Female", "or": "Tiếng Odia", "otq": "UK English Female", "pa": "UK English Female", "pl": "Polish Female", "prs": "UK English Female", "ps": "UK English Female", "pt": "Brazilian Portuguese Male", "pt-PT": "Portuguese Male", "ro": "Romanian Female", "ru": "Russian Female", "sk": "Slovak Female", "sl": "UK English Female", "sm": "UK English Female", "so": "UK English Female", "sq": "Albanian Male", "sr-Cyrl": "Serbian Male", "sr-Latn": "Serbian Male", "sv": "Swedish Female", "sw": "Swahili Male", "ta": "Tamil Female", "te": "UK English Female", "th": "Thai Female", "ti": "UK English Female", "tk": "UK English Female", "tlh-Latn": "UK English Female", "tlh-Piqd": "UK English Female", "to": "UK English Female", "tr": "Turkish Female", "tt": "UK English Female", "ty": "UK English Female", "ug": "UK English Female", "uk": "UK English Female", "ur": "UK English Female", "uz": "UK English Female", "vi": "Vietnamese Female", "yua": "UK English Female", "yue": "Chinese Female", "zh-Hans": "Chinese Male", "zh-Hant": "Chinese Taiwan Female", "zu": "UK English Female"};
      responsiveVoice.speak(word, lang_speak['am']);
      });
  card_header.setAttribute('class', 'card-header'),
  card_title.setAttribute('class', 'card-title'),
  card_btn_container.setAttribute('class', 'm-1'),
  card_btnGroup.setAttribute('class', 'btn btnTypeEVTDWORD'),
  card_btnType.setAttribute('class', 'btn btnTypeEVTDWORD');
  card_btnType.style.marginLeft = '5px';
  if(group!='')card_btn_container.appendChild(card_btnGroup);
  if(type!='')card_btn_container.appendChild(card_btnType);
  card_sound.innerHTML ='<i class="fas fa-volume-up"></i>';
  card_btn_container.appendChild(card_sound);
  
  card_header.appendChild(card_title);
  card_header.appendChild(card_btn_container);
  card_header.appendChild(card_ul);
  card.appendChild(card_header);
  
  card_a_mean.innerHTML = 'Nghĩa',
  card_a_example.innerHTML = 'Ví dụ';
  card_a_image.innerHTML = 'Ảnh';
  var card_a_button = document.createElement('div');
  card_a_button.innerHTML = 'Sửa <i class="fas fa-edit"></i>';
  card_a_button.style="margin-left:5px";
  card_a_button.setAttribute('class', 'btn btnTypeEVTDWORD showModalEdit');
  card_a_button.setAttribute('data-show-edit','evtdEditinfoModal')

  card_btn_container.appendChild(card_a_button);
  var card_a_button2 = document.createElement('div');
  card_a_button2.innerHTML = 'Xóa <i class="fa-solid fa-trash-can"></i>';
  card_a_button2.style="margin-left:5px";
  card_a_button2.setAttribute
  card_a_button2.setAttribute('class', 'btn btnTypeEVTDWORD showmodalevtd');
  card_a_button2.setAttribute('data-show-modal-evtd', 'modalCardDelete');
  card_btn_container.appendChild(card_a_button2);
  
  var path = document.createElement('div');
  path.style.display = 'none';
  var arr = [group, type, word];
  
  path.innerHTML = JSON.stringify(arr);

  card_a_button2.appendChild(path);
  

  var formCard = document.createElement('form');
  formCard.style='max-height: 300px;overflow-y: scroll;overflow-x: auto;';
  formCard.setAttribute('class', 'card-body tab-content');
  var tabPaneMean = document.createElement('div');
  var tabPanelImage = document.createElement('div');

  tabPaneMean.setAttribute('class', 'tab-pane active');
  var tabPaneExample = document.createElement('div');
  formCard.appendChild(tabPaneMean);
  formCard.appendChild(tabPaneExample);
  formCard.appendChild(tabPanelImage);
  card.appendChild(formCard);
  tabPanelImage.setAttribute('class', 'tab-pane');
  tabPaneExample.setAttribute('class', 'tab-pane');
  tabPaneMean.setAttribute('id', 'mean'+time);
  tabPaneExample.setAttribute('id', 'ex'+time);
  tabPanelImage.setAttribute('id', 'image'+time);
  card_a_example.setAttribute('href', '#ex'+time);
  card_a_mean.setAttribute('href', '#mean'+time);
  card_a_image.setAttribute('href', '#image'+time);
  tabPaneMean.innerHTML = ``;
  tabPaneExample.innerHTML =``;
          card_title.innerHTML = word;
          card_btnGroup.innerHTML = group;
          card_btnType.innerHTML = type;
               var lang_speak = { "af": "Afrikaans Male", "am": "UK English Female", "ar": "Arabic Female", "as": "UK English Female", "az": "UK English Female", "ba": "UK English Female", "bg": "UK English Female", "bn": "UK English Female", "bo": "UK English Female", "bs": "Bosnian Male", "ca": "French Canadian Female", "cs": "Czech Male", "cy": "Welsh Male", "da": "Danish Male", "de": "Deutsch Female", "dv": "UK English Female", "el": "Greek male", "en": "US English Female", "es": "Spanish Latin American Female", "et": "Estonian Male", "eu": "UK English Female", "fa": "UK English Female", "fi": "Finnish Female", "fil": "Filipino Female", "fj": "UK English Female", "fo": "UK English Female", "fr": "French Female", "fr-CA": "French Canadian Female", "ga": "UK English Female", "gl": "UK English Female", "gu": "UK English Female", "he": "UK English Female", "hi": "Hindi Female", "hr": "Serbo-Croatian Male", "hsb": "UK English Female", "ht": "UK English Female", "hu": "Hungarian Female", "hy": "Armenian Male", "id": "Indonesian Female", "ikt": "UK English Female", "is": "Icelandic Female", "it": "Italian Female", "iu": "UK English Female", "iu-Latn": "UK English Female", "ja": "Japanese Female", "ka": "UK English Female", "kk": "UK English Female", "km": "UK English Female", "kmr": "UK English Female", "kn": "UK English Female", "ko": "Korean Male", "ku": "UK English Female", "ky": "UK English Female", "lo": "UK English Female", "lt": "Latvian Male", "lv": "Latvian Male", "mg": "UK English Female", "mi": "UK English Female", "mk": "Macedonian Male", "ml": "UK English Female", "mn-Cyrl": "UK English Female", "mn-Mong": "UK English Female", "mr": "UK English Female", "ms": "UK English Female", "mt": "UK English Female", "mww": "UK English Female", "my": "UK English Female", "nb": "Norwegian Female", "ne": "Nepali", "nl": "Dutch Female", "or": "Tiếng Odia", "otq": "UK English Female", "pa": "UK English Female", "pl": "Polish Female", "prs": "UK English Female", "ps": "UK English Female", "pt": "Brazilian Portuguese Male", "pt-PT": "Portuguese Male", "ro": "Romanian Female", "ru": "Russian Female", "sk": "Slovak Female", "sl": "UK English Female", "sm": "UK English Female", "so": "UK English Female", "sq": "Albanian Male", "sr-Cyrl": "Serbian Male", "sr-Latn": "Serbian Male", "sv": "Swedish Female", "sw": "Swahili Male", "ta": "Tamil Female", "te": "UK English Female", "th": "Thai Female", "ti": "UK English Female", "tk": "UK English Female", "tlh-Latn": "UK English Female", "tlh-Piqd": "UK English Female", "to": "UK English Female", "tr": "Turkish Female", "tt": "UK English Female", "ty": "UK English Female", "ug": "UK English Female", "uk": "UK English Female", "ur": "UK English Female", "uz": "UK English Female", "vi": "Vietnamese Female", "yua": "UK English Female", "yue": "Chinese Female", "zh-Hans": "Chinese Male", "zh-Hant": "Chinese Taiwan Female", "zu": "UK English Female"};
               if(image!=undefined)
               for(let k = 0; k < image.length; k++){
            var img = document.createElement('img');
            img.src = image[k];
            var card_sound = document.createElement('div');
            card_sound.style.marginBottom = '5px';
            card_sound.style.marginRight = '5px';
            card_sound.setAttribute('class', 'btn btnTypeEVTDWORD');
            card_sound.appendChild(img);

            tabPanelImage.appendChild(card_sound  );
          }
          for(let k = 0; k < mean.length; k++){
              var div = document.createElement('div');
              div.style = 'max-height:75px; overflow-y:auto; overflow-x:hidden;font-size: 16px; background: rgb(255 255 255 / 17%); border: 1px solid rgb(255 255 255 / 37%); border-radius: 5px; padding: 5px; box-sizing: border-box; margin-bottom: 5px; color: rgb(0 0 0 / 64%);';
              div.innerHTML = mean[k];
              var card_sound = document.createElement('div');
              card_sound.setAttribute('class', 'btn btnTypeEVTDWORD');
              // card_sound.setAttribute('lang_speak','null');150px
              card_sound.style.marginBottom = '5px';
              card_sound.style.marginRight = '5px';
              card_sound.style.textAlign = 'left';
              card_sound.style.fontSize = '14px';
              card_sound.innerHTML ='<i class="fas fa-volume-up"></i>';
              card_sound.addEventListener('click', function(){
              responsiveVoice.speak(mean[k], lang_speak['am']);
              });
              card_sound.appendChild(div);
              tabPaneMean.appendChild(card_sound);
            }
            for(let k = 0; k < example.length; k++){
              var div = document.createElement('div');
              div.style = 'max-height:75px; overflow-y:auto; overflow-x:hidden;font-size: 16px; background: rgb(255 255 255 / 17%); border: 1px solid rgb(255 255 255 / 37%); border-radius: 5px; padding: 5px; box-sizing: border-box; margin-bottom: 5px; color: rgb(0 0 0 / 64%);';
              div.innerHTML = example[k];
              var card_sound = document.createElement('div');
              card_sound.setAttribute('class', 'btn btnTypeEVTDWORD');
              // card_sound.setAttribute('lang_speak','null');
              card_sound.style.marginBottom = '5px';
              card_sound.style.textAlign = 'left';
              card_sound.style.fontSize = '14px';
              card_sound.style.marginRight = '5px';
              card_sound.innerHTML ='<i class="fas fa-volume-up"></i>';
              card_sound.addEventListener('click', function(){
              responsiveVoice.speak(example[k], lang_speak['am']);
              });
              card_sound.appendChild(div);
              tabPaneExample.appendChild(card_sound);
            }
      document.getElementById('modalwordCardSync').children[0].appendChild(card);
  
          })
       });
     })
     Array.from(document.getElementsByClassName('showmodalevtd')).forEach( (e) => {
      e.addEventListener('click', function(element) {
        element.preventDefault();
        responsiveVoice.cancel();
        if (e.hasAttribute('data-show-modal-evtd')) {
          showModal(e.getAttribute('data-show-modal-evtd'));
          document.getElementById('modalCardDeleteAccept').innerHTML = '';
          var btn = document.createElement('button');
          btn.setAttribute('type', 'button');
          btn.setAttribute('class', 'btn');
          btn.setAttribute('data-bs-dismiss', 'modal');
          btn.innerHTML = 'Đồng ý';
          btn.addEventListener('click', function(){
            var path = JSON.parse(e.children[1].innerHTML);
            var group = path[0], type = path[1], word = path[2];
            const dbRef = ref(db);
            get(child(dbRef, "UserList/"+JSON.parse(userName)+"/languageTreasure")).then((snapshot)=>{
              
              if(group=="") group = "*";
               if(type=="") type = "*";
              var treasure =  JSON.parse(snapshot.val());

              delete treasure[group][type][word];
              if(jQuery.isEmptyObject(treasure[group][type])) delete treasure[group][type];
              if(jQuery.isEmptyObject(treasure[group])) delete treasure[group];
              localStorage.setItem('hasdeleted',1);
              e.parentNode.parentNode.parentNode.parentNode.removeChild(e.parentNode.parentNode.parentNode);
              update(ref(db, "UserList/" + JSON.parse(userName)), {
                languageTreasure: JSON.stringify(treasure)
              })
              .then(() => {})
              .catch((error) => {});
            });
          })
            document.getElementById('modalCardDeleteAccept').appendChild(btn);
            document.getElementById('modalCardDeleteContent').innerHTML = 'Thẻ ' + this.parentNode.parentNode.children[0].innerText + ' sẽ bị xóa'; 
          
        }
      }); 
    });
  
    Array.from(document.getElementsByClassName('showModalEdit')).forEach( (e) => {
      e.addEventListener('click', function(event){
        responsiveVoice.cancel();
        event.preventDefault();
        if(e.hasAttribute('data-show-edit')){
          showModal(e.getAttribute('data-show-edit'));
  
  ///fix codes here
  
          var this_card = this.parentNode.parentNode.parentNode,
              word = this_card.children[0].children[0].innerText,
              group = this_card.children[0].children[1].children[0].innerText,
              type =  this_card.children[0].children[1].children[1].innerText;
          var means = [];
          var means_part = this_card.children[1].children[0].children;
          for(let f = 0; f < means_part.length; f++) means.push(means_part[f].children[1].innerText);
          var exs = [];
          var exs_part = this_card.children[1].children[1].children;
          for(let f = 0; f < exs_part.length; f++) exs.push(exs_part[f].children[1].innerText);
          document.getElementById('evtdEditNewWord_selectGroup').parentNode.children[0].value = group;
          document.getElementById('evtdEditNewWord_selectType').parentNode.children[0].value = type;
          document.getElementById('evtdEditNewWord_selectGroup').value = group;
          document.getElementById('evtdEditNewWord_selectType').value = type;
          
          document.getElementById('evtdEditNewWord_Input').value = word;
  
          var mean_container = document.getElementById('evtdEditWordinfoModal_mean').children[1];
          mean_container.innerHTML = '';
          for(let k = 0; k < means.length; k++){
            var pseudo_mean = document.createElement('div');
            pseudo_mean.setAttribute('class', 'input-group mb-1 evtdInputFieldCreateJquery_mean');
            pseudo_mean.innerHTML = `<textarea type="text" class="form-control mt-1 shadow-none"  spellcheck="false"  placeholder="Nhập định nghĩa" aria-label="" aria-describedby="basic-addon1"></textarea>
            <button class="deleteEVTDInputField" type="button"><i class="fa-solid fa-delete-left"></i></button>`;
            pseudo_mean.children[0].value = means[k];
            mean_container.appendChild(pseudo_mean);
          }
          var example_container = document.getElementById('evtdEditWordinfoModal_example').children[1]
          example_container.innerHTML = '';
          var image_container = document.getElementById('evtdFixWordinfoModal_image').children[1];
          image_container.innerHTML = ``;
          var image = this_card.children[1].lastChild.children;
          if(image.innerHTML != '')
          for(let k = 0; k < image.length; k++){
            var div = document.createElement('div');
            div.setAttribute('class', 'input-group mb-1 evtdInputFieldCreateJquery');
            div.innerHTML = ` <input class="evtdImageAddingPageCreate" type="file"  accept=".jpg, .jpeg, .png" />
    <button class="deleteEVTDInputField" type="button"><i
        class="fa-solid fa-delete-left"></i></button>
    <img class="imagePreviewCreate"/>`;
            div.children[0].addEventListener('change', function (e) {
              e.preventDefault();
              if (!this.files || !this.files[0]) return;
              const FR = new FileReader();
              FR.addEventListener("load", function (evt) {
                const MAX_WIDTH = 512;
                const MAX_HEIGHT = 512;
                let img = new Image()
                img.src = evt.target.result
                img.onload = () => {
                    let canvas = document.createElement('canvas')
                    let width = img.width
                    let height = img.height
        
                    if (width > height) {
                        if (width > MAX_WIDTH) {
                            height *= MAX_WIDTH / width
                            width = MAX_WIDTH
                        }
                    } else {
                        if (height > MAX_HEIGHT) {
                            width *= MAX_HEIGHT / height
                            height = MAX_HEIGHT
                        }
                    }
                    canvas.width = width
                    canvas.height = height
                    let ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    e.target.parentNode.querySelector('.imagePreviewCreate').src = canvas.toDataURL();
                  }
              });
              FR.readAsDataURL(this.files[0]);
            });

              div.querySelector('.imagePreviewCreate').src = image[k].children[0].src;
            document.getElementById('evtdFieldFix_image') .appendChild(div);
  } 
          for(let k = 0; k < exs.length; k++){
            var pseudo_ex = document.createElement('div');
            pseudo_ex.setAttribute('class', 'input-group mb-1 evtdInputFieldCreateJquery_mean');
            pseudo_ex.innerHTML = `<textarea type="text" class="form-control mt-1 shadow-none"  spellcheck="false"  placeholder="Nhập định nghĩa" aria-label="" aria-describedby="basic-addon1"></textarea>
            <button class="deleteEVTDInputField" type="button"><i class="fa-solid fa-delete-left"></i></button>`;
            pseudo_ex.children[0].value = exs[k];
            example_container.appendChild(pseudo_ex);
          }
            var save = document.getElementById('evtdEditWordinfoModalSaveButton');
            save.innerHTML = '';
            var btn = document.createElement('button');
            btn.className = 'btn';
            btn.setAttribute('type', 'button');
            // btn.setAttribute('data-bs-dismiss', 'modal');
            btn.innerHTML = `Lưu`;
            btn.addEventListener('click', function(){ 
              //saveAllContent
              btn.innerHTML = ` <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
              <span class="sr-only">Loading...</span>`;
              var mean_container = document.getElementById('evtdEditWordinfoModal_mean').children[1];
              var ex_container = document.getElementById('evtdEditWordinfoModal_example').children[1];
              var imageContainer = document.getElementById('evtdFieldFix_image').children;
              var imageparts = [];
              if(this_card.querySelector('form.card-body').lastChild.innerHTML!='')
              this_card.querySelector('form.card-body').lastChild.innerHTML = ``;

              for(var zippo = 0; zippo < imageContainer.length; zippo++){
                if(imageContainer[zippo].querySelector('.imagePreviewCreate').src=="")continue;

                imageparts.push(imageContainer[zippo].querySelector('.imagePreviewCreate').src);
                console.log(this_card.querySelector('form.card-body').lastChild.children[0]);
                var imgdiv = document.createElement('div');
                imgdiv.setAttribute('class', 'btn btnTypeEVTDWORD');
                imgdiv.style.marginBottom = '5px';
                imgdiv.style.marginRight = '5px';
                var img = document.createElement('img');
                img.src = imageContainer[zippo].querySelector('.imagePreviewCreate').src;
                imgdiv.appendChild(img);

                this_card.querySelector('form.card-body').lastChild.appendChild(imgdiv);
              }
              // console.log(mean_container);
              var means_part = this_card.children[1].children[0];
              means_part.innerHTML = '';
              var newexamples = [],
                  newmeans = [];
              for(var zippo = 0; zippo < mean_container.children.length; zippo++){
                var extract = mean_container.children[zippo].children[0].value;
                if (extract=="")continue;
                var div = document.createElement('div');
                div.style = 'max-height:75px; overflow-y:auto; overflow-x:hidden;font-size: 16px; background: rgb(255 255 255 / 17%); border: 1px solid rgb(255 255 255 / 37%); border-radius: 5px; padding: 5px; box-sizing: border-box; margin-bottom: 5px; color: rgb(0 0 0 / 64%);';
                div.innerHTML = extract;
                newmeans.push(extract);
                var divsound = document.createElement('div');
                divsound.setAttribute('class', 'btn btnTypeEVTDWORD');
                divsound.style.marginBottom = '5px';
                divsound.style.marginRight = '5px';
                divsound.style.textAlign = 'left';
                divsound.style.fontSize = '14px';
                divsound.innerHTML ='<i class="fas fa-volume-up"></i>';
                divsound.onclick = function(e){
                  e.preventDefault();
                  responsiveVoice.speak(this.children[1].innerText, 'US English Female');
                }
                divsound.appendChild(div);
                means_part.appendChild(divsound);
              }
              var exs_part = this_card.children[1].children[1];
              exs_part.innerHTML = '';
              for(var zippo = 0; zippo < ex_container.children.length; zippo++){
                if (extract=="")continue;
                newexamples.push(extract);
                var extract = ex_container.children[zippo].children[0].value;
                var div = document.createElement('div');
                div.style = 'max-height:75px; overflow-y:auto; overflow-x:hidden;font-size: 16px; background: rgb(255 255 255 / 17%); border: 1px solid rgb(255 255 255 / 37%); border-radius: 5px; padding: 5px; box-sizing: border-box; margin-bottom: 5px; color: rgb(0 0 0 / 64%);';
                div.innerHTML = extract;
                var divsound = document.createElement('div');
                divsound.setAttribute('class', 'btn btnTypeEVTDWORD');
                divsound.style.marginBottom = '5px';
                divsound.style.marginRight = '5px';
                divsound.style.textAlign = 'left';
                divsound.style.fontSize = '14px';
                divsound.innerHTML ='<i class="fas fa-volume-up"></i>';
                divsound.onclick = function(e){
                  e.preventDefault();
                  responsiveVoice.speak(this.children[1].innerText, 'US English Female');
                }
                divsound.appendChild(div);
                exs_part.appendChild(divsound);
              }
              var nw = '',
                  nt = '',
                  ng = '';
              nw = document.getElementById('evtdEditNewWord_Input').value,
              ng = document.getElementById('evtdEditNewWord_selectGroup').parentNode.children[0].value,
              nt = document.getElementById('evtdEditNewWord_selectType').parentNode.children[0].value;
              const dbRef = ref(db);
              get(child(dbRef, "UserList/"+JSON.parse(userName)+"/languageTreasure")).then((snapshot)=>{
              
                var treasure =  JSON.parse(snapshot.val());
                
                  delete treasure[group][type][word];
                  var newword = {
                    'time':Date.now(),
                    'group':ng,
                    'type':nt,
                    'mean':newmeans,
                    'example':newexamples,
                    'image':imageparts
                  }
                  if(jQuery.isEmptyObject(treasure[group][type]))delete treasure[group][type];
                  if(jQuery.isEmptyObject(treasure[group]))delete treasure[group];
                  if(!treasure.hasOwnProperty(ng))treasure[ng]={};
                  if(!treasure[ng].hasOwnProperty(nt))treasure[ng][nt]={};
                  if(!treasure[ng][nt].hasOwnProperty(nw))treasure[ng][nt][nw]=newword;
                  showModal('modalCardReplaceModify');
                  document.getElementById('modalCardReplaceModify_accept').innerHTML =``;
                  var btnac = document.createElement('button');
                  btnac.setAttribute('type', 'button');
                  btnac.setAttribute('class', 'btn'); 
                  btnac.innerHTML = 'Đồng ý';
                  
                  document.getElementById('modalCardReplaceModify_accept').appendChild(btnac);
                  btnac.addEventListener('click', function(){
                    $('#evtdEditinfoModal').modal('hide');
                    var arr = [ng,nt,nw];
                    this_card.children[0].children[1].lastChild.children[1].innerText = JSON.stringify(arr); 
                    localStorage.setItem('modified',1);
                    this_card.children[0].children[0].innerText = document.getElementById('evtdEditNewWord_Input').value,
                    this_card.children[0].children[1].children[0].innerText = document.getElementById('evtdEditNewWord_selectGroup').parentNode.children[0].value,
                    this_card.children[0].children[1].children[1].innerText = document.getElementById('evtdEditNewWord_selectType').parentNode.children[0].value;
                    $('#modalCardReplaceModify').modal('hide');
                    update(ref(db, "UserList/" + JSON.parse(userName)), {
                      languageTreasure: JSON.stringify(treasure)
                    })
                    .then(() => {})
                    .catch((error) => {});
                  })
              });
            });
            save.appendChild(btn);
  
  
        }
      })
    });
  UpdateSortQuery(groupUnique, typeUnique);
  evtdQuickSort("Mới nhất");
  //
  
  
    });

}
function UpdateSortQuery(groupX, typeX) {
    var groupUnique = {}, typeUnique = {}
    const dbRef = ref(db);
    get(child(dbRef, "UserList/" + JSON.parse(userName) + "/languageTreasure")).then((snapshot) => {
      var languageTreasure = JSON.parse(snapshot.val());
      Object.keys(languageTreasure).forEach(function (group) {
        groupUnique[group] = 1;
        Object.keys(languageTreasure[group]).forEach(function (type) {
          typeUnique[type] = 1;
        });
      })
        document.getElementById('evtdAddNewWordinfoModal_selectGroup').innerHTML =
          document.getElementById('evtdAddNewWordinfoModal_selectType').innerHTML =
          document.getElementById('inputGroupSelect01Modal').innerHTML = 
          document.getElementById('inputGroupSelect02Modal').innerHTML = 
          document.getElementById('inputGroupSelect01').innerHTML =
          document.getElementById('evtdEditNewWord_selectGroup').innerHTML =
          document.getElementById('evtdEditNewWord_selectType').innerHTML =
          document.getElementById('inputGroupSelect02').innerHTML = '<option>Tất cả</option>';
        //  document.getElementsByClassName('evtdFilterOption')[0].parentNode.parentNode.children[1].child
        Object.keys(groupUnique).forEach(function (group) {
          var opt = document.createElement('option'),
            opt2 = document.createElement('option'),
            opt3 = document.createElement('option'),
            opt4 = document.createElement('option');
          opt.innerHTML = group;
          opt2.innerHTML = group;
          opt3.innerHTML = group;
          opt4.innerHTML = group;
          document.getElementById('inputGroupSelect01').appendChild(opt);
          document.getElementById('inputGroupSelect01Modal').appendChild(opt4);
          document.getElementById('evtdAddNewWordinfoModal_selectGroup').appendChild(opt2);
          document.getElementById('evtdEditNewWord_selectGroup').appendChild(opt3);
        })

        Object.keys(typeUnique).forEach(function (type) {
          var opt = document.createElement('option'),
            opt2 = document.createElement('option'),
            opt3 = document.createElement('option');
          opt.innerHTML = type;
          opt2.innerHTML = type;
          opt3.innerHTML = type;
          document.getElementById('inputGroupSelect02').appendChild(opt);
          document.getElementById('evtdAddNewWordinfoModal_selectType').appendChild(opt2);
          document.getElementById('evtdEditNewWord_selectType').appendChild(opt3);
        })
        
    })
    
}
$(document).ready(function() {
  var max_fields = 10;
  var wrapperadd = $(".evtdFieldAdd_example");
  var wrapperimage = $(".evtdFieldEdit_image");

  $('.edit_form_fieldEVTD_image').click(function(e){
    e.preventDefault();
    var div = document.createElement('div');
    div.setAttribute('class', 'input-group mb-1 evtdInputFieldCreateJquery');
    div.innerHTML = ` <input class="evtdImageAddingPageCreate" type="file" accept=".jpg, .jpeg, .png" />
    <button class="deleteEVTDInputField" type="button"><i
        class="fa-solid fa-delete-left"></i></button>
    <img class="imagePreviewCreate"/>`;
    div.children[0].addEventListener('change', function(e){
        e.preventDefault();
        if (!this.files || !this.files[0]) return;
        const FR = new FileReader();
        FR.addEventListener("load", function(evt) {

          const MAX_WIDTH = 512;
          const MAX_HEIGHT = 512;
          let img = new Image()
          img.src = evt.target.result
          img.onload = () => {
              let canvas = document.createElement('canvas')
              let width = img.width
              let height = img.height
  
              if (width > height) {
                  if (width > MAX_WIDTH) {
                      height *= MAX_WIDTH / width
                      width = MAX_WIDTH
                  }
              } else {
                  if (height > MAX_HEIGHT) {
                      width *= MAX_HEIGHT / height
                      height = MAX_HEIGHT
                  }
              }
              canvas.width = width
              canvas.height = height
              let ctx = canvas.getContext('2d');
              ctx.drawImage(img, 0, 0, width, height);
              e.target.parentNode.querySelector('.imagePreviewCreate').src = canvas.toDataURL();
            }
        }); 
        FR.readAsDataURL(this.files[0]);        
      });
    document.getElementById('evtdFieldEdit_image').appendChild(div);
    
  });
  $(".add_form_fieldEVTD_example").click(function(e) {
      e.preventDefault();
          $(wrapperadd).append(`
          <div class="input-group mb-1 evtdInputFieldCreateJquery_example">
          <input type="text" class="form-control mt-1 shadow-none"  spellcheck="false"  placeholder="Nhập câu ví dụ" aria-label="" aria-describedby="basic-addon1">
          <button class="deleteEVTDInputField" type="button"><i class="fa-solid fa-delete-left"></i></button>
          </div>

          `); //add input box
  });

  $(wrapperimage).on("click", ".deleteEVTDInputField", function(e) {
    e.preventDefault();
    $(this).parent('div').remove();
})
  $(wrapperadd).on("click", ".deleteEVTDInputField", function(e) {
      e.preventDefault();
      $(this).parent('div').remove();
  })
  var wrapperedit = $(".evtdFieldEdit_example");
  $(".edit_form_fieldEVTD_example").click(function(e) {
      e.preventDefault();
          $(wrapperedit).append(`
          <div class="input-group mb-1 evtdInputFieldCreateJquery_example">
          <input type="text" class="form-control mt-1 shadow-none"  spellcheck="false"  placeholder="Nhập câu ví dụ" aria-label="" aria-describedby="basic-addon1">
          <button class="deleteEVTDInputField" type="button"><i class="fa-solid fa-delete-left"></i></button>
          </div>

          `); //add input box
  });
  
  $(wrapperedit).on("click", ".deleteEVTDInputField", function(e) {
      e.preventDefault();
      $(this).parent('div').remove();
  })
});
document.getElementById('evtdAddNewWordinfoModal_selectGroup_Add').addEventListener('click', function(){
  var images = document.getElementById('evtdFieldEdit_image').children;
  var image = [];
  for(let k = 0; k < images.length; k++){
    var dbsrc = images[k].querySelector('.imagePreviewCreate').src;
    
    if (dbsrc!=""&&(new TextEncoder().encode(dbsrc)).length/(1024*1024)<=10){
      image.push(images[k].querySelector('.imagePreviewCreate').src);
    }
  }
  var wordCard = {},
      word = document.getElementById('evtdAddNewWordinfoModal_card').children[0].children[0].children[0].value,
      mean = [],
      example = [],
      type = document.getElementById('evtdAddNewWordinfoModal_card').children[0].children[3].children[0].value,
      group = document.getElementById('evtdAddNewWordinfoModal_card').children[0].children[2].children[0].value,
      mean_element = document.getElementById('evtdAddNewWordinfoModal_mean').children[1].children,
      example_element = document.getElementById('evtdAddNewWordinfoModal_example').children[1].children;
      wordCard[word] = {
        'mean':mean,
        'example':example,
        'type':type,
        'time':Date.now(),
        'group':group,
        'image': image
      }
  if(word == "")return;
     for(let k = 0; k <mean_element.length; k++) if(mean_element[k].children[0].value!="") wordCard[word]['mean'].push(mean_element[k].children[0].value);
     for(let k = 0; k <example_element.length; k++) if(example_element[k].children[0].value!="") wordCard[word]['example'].push(example_element[k].children[0].value);
      document.getElementById('evtdAddNewWordinfoModal_card').children[0].children[0].children[0].value = '';
      document.getElementById('evtdAddNewWordinfoModal_card').children[0].children[3].children[0].value = '';
      document.getElementById('evtdAddNewWordinfoModal_card').children[0].children[2].children[0].value = '';
      document.getElementsByClassName('evtdFieldAdd_mean')[0].innerHTML = `        <div class="input-group mb-1 evtdInputFieldCreateJquery_mean">
      <textarea type="text" class="form-control mt-1 shadow-none"  spellcheck="false"  placeholder="Nhập định nghĩa" aria-label="" aria-describedby="basic-addon1"></textarea>
      <button class="deleteEVTDInputField" type="button"><i class="fa-solid fa-delete-left"></i></button>
      </div>`;
      document.getElementsByClassName('evtdFieldAdd_example')[0].innerHTML = `<div class="input-group mb-1 evtdInputFieldCreateJquery_example">
      <input type="text" class="form-control mt-1 shadow-none" spellcheck="false" placeholder="Nhập câu ví dụ" aria-label="" aria-describedby="basic-addon1">
      <button class="deleteEVTDInputField" type="button"><i class="fa-solid fa-delete-left"></i></button>
    </div>`;
    $('select').prop('selectedIndex', 0);
        const dbRef = ref(db);
    get(child(dbRef, "UserList/"+JSON.parse(userName))).then((snapshot)=>{
      if(group=="") group = "*";
      if(type=="") type = "*";
      var treasure =  JSON.parse(snapshot.val().languageTreasure);
      if(!treasure.hasOwnProperty(group)) treasure[group] = {};
      if(!treasure[group].hasOwnProperty(type)) treasure[group][type] = {};
      if(!treasure[group][type].hasOwnProperty(word)) treasure[group][type][word] = wordCard[word]
      else {
        //Word will be replaced.
      }
      var countDate =  JSON.parse(snapshot.val().dailyGoal);
      var date = new Date();
      var today = date.getDate()+"/"+(parseInt(date.getMonth())+1)+"/"+date.getFullYear()      
      if(!countDate.hasOwnProperty(today)) countDate[today] = 0;
      countDate[today] = countDate[today] + 1;
      update(ref(db, "UserList/" + JSON.parse(userName)), {
        languageTreasure: JSON.stringify(treasure),
        dailyGoal: JSON.stringify(countDate)
      })
      .then(() => {})
      .catch((error) => {});
    });
});
document.getElementById('ManagerInfoModalOpen').addEventListener('click', function(){
  document.getElementById('inputGroupSelect01Modal').value = 'Tất cả';
  document.getElementById('inputGroupSelect02Modal').value = '';
  
})
$(document).ready(function() {
  var wrapperadd = $(".evtdFieldAdd_mean");
  var wrapperedit = $(".evtdFieldEdit_mean");
  
  $(".add_form_fieldEVTD_mean").click(function(e) {
      e.preventDefault();
          $(wrapperadd).append(`
          <div class="input-group mb-1 evtdInputFieldCreateJquery_mean">
          <textarea type="text" class="form-control mt-1 shadow-none"  spellcheck="false"  placeholder="Nhập định nghĩa" aria-label="" aria-describedby="basic-addon1"></textarea>
          <button class="deleteEVTDInputField" type="button"><i class="fa-solid fa-delete-left"></i></button>
          </div>

          `); //add input box
  });
  $(".edit_form_fieldEVTD_mean").click(function(e) {
    e.preventDefault();
        $(wrapperedit).append(`
        <div class="input-group mb-1 evtdInputFieldCreateJquery_mean">
        <textarea type="text" class="form-control mt-1 shadow-none"  spellcheck="false"  placeholder="Nhập định nghĩa" aria-label="" aria-describedby="basic-addon1"></textarea>
        <button class="deleteEVTDInputField" type="button"><i class="fa-solid fa-delete-left"></i></button>
        </div>

        `); //add input box
});
var wrapfix = $('.evtdFieldFix_image');
$(".fix_form_fieldEVTD_image").click(function(e) {
  e.preventDefault();
            var div = document.createElement('div');
            div.setAttribute('class', 'input-group mb-1 evtdInputFieldCreateJquery');
            div.innerHTML = ` <input class="evtdImageAddingPageCreate" type="file" accept=".jpg, .jpeg, .png" />
    <button class="deleteEVTDInputField" type="button"><i
        class="fa-solid fa-delete-left"></i></button>
    <img class="imagePreviewCreate"/>`;
            div.children[0].addEventListener('change', function (e) {
              e.preventDefault();
              if (!this.files || !this.files[0]) return;
              const FR = new FileReader();
              FR.addEventListener("load", function (evt) {
                const MAX_WIDTH = 300;
                const MAX_HEIGHT = 300;
                let img = new Image()
                img.src = evt.target.result
                img.onload = () => {
                    let canvas = document.createElement('canvas')
                    let width = img.width
                    let height = img.height
        
                    if (width > height) {
                        if (width > MAX_WIDTH) {
                            height *= MAX_WIDTH / width
                            width = MAX_WIDTH
                        }
                    } else {
                        if (height > MAX_HEIGHT) {
                            width *= MAX_HEIGHT / height
                            height = MAX_HEIGHT
                        }
                    }
                    canvas.width = width
                    canvas.height = height
                    let ctx = canvas.getContext('2d');
                    ctx.drawImage(img, 0, 0, width, height);
                    e.target.parentNode.querySelector('.imagePreviewCreate').src = canvas.toDataURL();
                  }
              });
              FR.readAsDataURL(this.files[0]);
            });
            document.getElementById('evtdFieldFix_image').appendChild(div);
});
$(wrapfix).on("click", ".deleteEVTDInputField", function(e){
  e.preventDefault();
  $(this).parent('div').remove();
})
  $(wrapperedit).on("click", ".deleteEVTDInputField", function(e) {
      e.preventDefault();
      $(this).parent('div').remove();
  })
  
  $(wrapperadd).on("click", ".deleteEVTDInputField", function(e) {
    e.preventDefault();
    $(this).parent('div').remove();
})
});
document.getElementById('acceptManagerDelete').addEventListener('click', function(){
  var group = document.getElementById('inputGroupSelect01Modal').value,
      type = document.getElementById('inputGroupSelect02Modal').value;
  const dbRef = ref(db);
  get(child(dbRef, "UserList/" + JSON.parse(userName) + "/languageTreasure")).then((snapshot) => {
    var treasure = JSON.parse(snapshot.val());
    if(type=="Tất cả"){
      delete treasure[group];
    } 
    if (group=="Tất cả"){
      treasure = {};
    }

  if(!jQuery.isEmptyObject(treasure)&&!jQuery.isEmptyObject(treasure[group])&&!jQuery.isEmptyObject(treasure[group][type])) delete treasure[group][type];
    if(jQuery.isEmptyObject(treasure[group]))delete treasure[group];
    update(ref(db, "UserList/" + JSON.parse((userName))), {
      languageTreasure:  JSON.stringify(treasure)
    })
    .then(() => {})
    .catch((error) => {});    
 
  })
  document.getElementById('inputGroupSelect02Modal').innerHTML = `<option>Tất cả</option>`;

});
document.getElementById('modalCardReplaceModifyconfirmClose').addEventListener('click', function(e){
  document.getElementById('evtdEditWordinfoModalSaveButton').children[0].innerHTML = "Lưu";
});
$(document).keyup(function(e) {
  if (e.key === "Escape") { // escape key maps to keycode `27`
    responsiveVoice.cancel();
    if(document.getElementById('evtdEditWordinfoModalSaveButton').children[0]!=undefined) document.getElementById('evtdEditWordinfoModalSaveButton').children[0].innerHTML = "Lưu";
 }
});
 document.getElementById('evtdFilterCreatenewCard').addEventListener('click', function(){
  responsiveVoice.cancel();
  document.getElementById('modalCardReplaceDivContainer').innerHTML = ``;
  document.getElementById('evtdFieldEdit_image').innerHTML = ``;
  severCardLoader();

 });
   document.body.addEventListener('keypress', function(e){
    if(e.key=='Escape') responsiveVoice.cancel();
   });
   document.getElementById('languageModalBook_closeBtn').addEventListener('click', function(){
    responsiveVoice.cancel();
  })
// });
document.getElementById('evtdLanguageTreasure').addEventListener('click', function(){
  severCardLoader();
  
})
$(".evtdcard").on("click", () => {
  $(".evtdcard .front").toggleClass("flipped");
  $(".evtdcard .back").toggleClass("back-flipped");
  $(".evtdcard").addClass("lift-card");
});
document.getElementById('logoutBtn').addEventListener('click', function(){
  localStorage.removeItem('user');
  localStorage.removeItem('pass');
  localStorage.removeItem('keepLoggedIn');
  sessionStorage.removeItem('user');
  sessionStorage.removeItem('pass');
  chrome.storage.local.set({"userAccount": null});
  window.location = '../index.html';
})
document.getElementById('logoutBtnMobile').addEventListener('click', function(){
  localStorage.removeItem('user');
  localStorage.removeItem('pass');
  localStorage.removeItem('keepLoggedIn');
  sessionStorage.removeItem('user');
  sessionStorage.removeItem('pass');
  chrome.storage.local.set({"userAccount": null});
  localStorage.removeItem('evtd_FirstTimeLogin');
  window.location = '../index.html';
})