var style_code = ["linear-gradient(315deg, #4158D0 0%, #C850C0 46%, #FFCC70 100%)",
"linear-gradient(315deg, #f5c62c 0%, #fca606 46%, #ff831d 100%)",
" linear-gradient(315deg, rgba(255,15,15,1) 0%, rgba(255,46,46,1) 3%, rgba(255,213,13,1) 97%)",
"linear-gradient(315deg, rgba(3,214,223,1) 0%, rgba(231,225,4,1) 91%, rgba(240,233,2,1) 100%)",
"linear-gradient(315deg,rgb(92, 35, 247) ,rgb(81, 107, 255) 46%,rgb(255, 111, 183) 100%)",
"linear-gradient(315deg, rgba(0,255,141,1) 0%, rgba(34,150,255,1) 81%, rgba(11,110,255,1) 97%)",
"linear-gradient(315deg, rgba(66,212,255,1) 0%, rgba(66,153,255,1) 16%, rgba(13,52,255,1) 100%)",
"linear-gradient(315deg, rgba(255,66,66,1) 0%, rgba(255,66,130,1) 18%, rgba(255,238,0,1) 100%)",
"linear-gradient(315deg, rgba(4,214,235,1) 0%, rgba(118,0,255,1) 49%, rgba(248,27,255,1) 82%)"];
function UpdateColor(id){
	document.body.style.background = style_code[id];
	document.getElementById("list-hist").style.background = style_code[id];
	document.getElementById("menu").style.background = style_code[id];
	document.getElementById("color-content").style.background = style_code[id];
	document.getElementById("today-content").style.background = style_code[id];
  }
window.onload = function () {
	if (localStorage.getItem("style_id") != null) {
		var id = localStorage.getItem("style_id");
		UpdateColor(id);
	} else {
		localStorage.setItem("style_id", 0);
		chrome.storage.local.set({
			'color_code': 0
		});
    UpdateColor(0);
  }

function load_w() {
	if (localStorage.getItem("today_w") != null) {
		var obj = database[localStorage.getItem("today_w") % Object.keys(database).length];
		localStorage.setItem("word-t2", obj['word']);
		localStorage.setItem("word-t3", obj['mean']);
		document.getElementById("word-d1").innerHTML = obj['word'] + " <i><div style='display: inline-block; font-size:12.5px;font-family:  sans-serif;z-index: 999999;'>" + obj['type'] + "</div></i>";
		document.getElementById("word-us").innerHTML = "<i style='font-size: 12.5px; color: #323232; height: 12.5px; margin-right: 2.5px; background: rgba(255,255,255,.8); width: 14.5px; padding: 2px; border-radius: 50%; border: 1px solid rgba(255,255,255,.27);' class='fa-solid fa-volume-high'></i><div style='display:inline-block; font-size:9.5px'>US</div>   " + "<div style='display: inline-block; font-size:15px;font-family:  sans-serif;z-index: 999999;'>" + obj['us'] + "</div>";
		document.getElementById("word-uk").innerHTML = "<i style='font-size: 12.5px; color: #323232; height: 12.5px; margin-right: 2.5px; background: rgba(255,255,255,.8); width: 14.5px; padding: 2px; border-radius: 50%; border: 1px solid rgba(255,255,255,.27);' class='fa-solid fa-volume-high'></i><div style='display:inline-block; font-size:9.5px'>UK</div> " + "<div style='display: inline-block; font-size:15px;font-family:  sans-serif;z-index: 999999;'>" + obj['uk'] + "</div>";
		document.getElementById("word-m1").innerHTML = "<div style='color: rgb(48, 48, 48);display: inline-block; font-size:13.75px;font-family:  sans-serif;z-index: 999999;'>● " + obj['mean'] + "</div>";
		document.getElementById("word-m2").innerHTML = "<div style='color: rgb(48, 48, 48);display: inline-block; font-size:13.75px;font-family:  sans-serif;z-index: 999999;'>● " + obj['vimean'] + "</div>";
		var obj_ex = obj['ex'];
		let count = 0;
		var ex = document.getElementById("ex_w");
		ex.innerHTML = "";
		Object.keys(obj_ex).forEach(function (key) {
			count = count + 1;
			var nodeHeader = document.createElement("DIV");
			nodeHeader.classList.add("ex_w");
			nodeHeader.innerHTML = count.toString() + " <i class='fas fa-star' style='color:#2974ff'></i>" + key;
			ex.appendChild(nodeHeader);
			for (const sentence of obj_ex[key]) {
				var example_sentence = document.createElement("DIV");
				example_sentence.innerHTML = "● " + sentence;
				ex.appendChild(example_sentence);
			}
		});
		var obj_img = obj['img'];
		var img_div = document.getElementById("ex_img");
		img_div.innerHTML = "";
		for (const img of obj_img) {
			var img_element = document.createElement("IMG");
			img_element.style = "width: 50%; height: 50%";
			img_element.src = img;
			img_div.appendChild(img_element);
		}
	}
}

	chrome.storage.local.get(['popupCallindex'], function(data){
		localStorage.setItem('popupCallindex', data['popupCallindex']);
	});
	var settingBtns = document.getElementsByClassName('settingButtonLanguage');
	for(var i = 0; i < settingBtns.length; i++){
		settingBtns[i].addEventListener('click', function(){
			chrome.storage.local.set({
				'languagePack': this.value
			})
			localStorage.setItem('languagePack', this.value);
			languageLoad();
		});
	}
	chrome.storage.local.get(['introduction'], function(database){	
		if(database['introduction']==1){
			modalSetting.style.display = "block";
			document.getElementById("modalSetting").style.background = "linear-gradient(315deg, #4158D0 0%, #C850C0 46%, #FFCC70 100%)";
			chrome.storage.local.set({
				'introduction': 0
			});
		}
	})
	    
	var d_w = localStorage.getItem("date_w");
	if (d_w != null) {
		let d_w_1 = localStorage.getItem("today_w");
		if (d_w != new Date().getDate()) {
			d_w_1++;
			localStorage.setItem("today_w", d_w_1);
			localStorage.setItem("date_w", new Date().getDate());
		}
	} else {
		localStorage.setItem("today_w", 0);
		localStorage.setItem("date_w", new Date().getDate());
	}
	responsiveVoice.enableWindowClickHook();
	document.getElementById("word-m1").style.display = "none";
	document.getElementById("word-m2").style.display = "none";
	document.getElementById("ex_w").style.display = "none";
	load_w();
	document.getElementById("history").style.display = "block";
	
};
var language_full = {}, 
	evtd_application = ['7cd95279b3msh22ca2841711a976p16c40cjsn6496096309d5', 'cab04e5891msh4c24f8994ca0b68p13e901jsn85591d19350a',  '7a80ca2ef5mshb089d282f64bc61p1f4b03jsn3d7f719f941e', '6ea68323dcmshee0d767e1a662d2p19d328jsn32b06331969c', '12300f284emsh4f8ef82b9cd45cdp1b59e1jsn350b64316fcd', '0dc529f275mshb90d90ae899cc1ep1655fcjsn82dd810a35d7'];
document.addEventListener('DOMContentLoaded', function () {
	
	if (localStorage.getItem("trans_lang") === null) {
		localStorage.setItem("trans_lang", "vi");
	}
	if (localStorage.getItem("source_lang") === null) {
		localStorage.setItem("source_lang", "auto");
	}
	document.getElementById("source_btn").innerText = language_full[localStorage.getItem("source_lang")];
	document.getElementById("target_btn").innerText = language_full[localStorage.getItem("trans_lang")];
	document.getElementById("source_btn").addEventListener("click", show_source);
	document.getElementById("target_btn").addEventListener("click", show_target);
	document.getElementById("sourceClose").addEventListener('click', sourceClose);
	document.getElementById("targetClose").addEventListener('click', targetClose);
	Object.keys(language_full).forEach(function (key) {
		var btn = document.createElement('button');
		btn.id = 'sr_' + key;
		btn.value = key;
		btn.innerText = language_full[key];
		btn.addEventListener('click', update_source);
		document.getElementById('source_drop').appendChild(btn);
	});
	Object.keys(language_full).forEach(function (key) {
		if (key != "auto") {
			var btn = document.createElement('button');
			btn.id = 'tg_' + key;
			btn.value = key;
			btn.innerText = language_full[key];
			btn.addEventListener('click', update_target);
			document.getElementById('target_drop').appendChild(btn);
		}
	});
	document.getElementById("inputSource").addEventListener("keyup", filterSource);
	document.getElementById("inputTarget").addEventListener("keyup", filterTarget);
	document.getElementById("sound-source").addEventListener("click", sound_source);
	document.getElementById("sound-target").addEventListener("click", sound_target);
	document.getElementById("sound-source").addEventListener("click", sound_source);
	document.getElementById("sound-target").addEventListener("click", sound_target);
	document.getElementById("copy-target").addEventListener("click", targetCopy),
		document.getElementById("copy-source").addEventListener("click", sourceCopy),
		document.getElementById("copy-target").addEventListener("mouseout", outTarget),
		document.getElementById("copy-source").addEventListener("mouseout", outSource);

	document.body.addEventListener('mouseup', processFunction);
	document.body.addEventListener('mousedown', processFunction);
	document.body.addEventListener('cut', processFunction);
	document.body.addEventListener('change', processFunction);
	document.body.addEventListener('keyup', processFunction);
	languageLoad();
});
function languageLoad(){
	chrome.storage.local.get(["languagePack"], function (data) {
		localStorage.setItem('languagePack', data['languagePack']);
		
		var obj =languagePack[data["languagePack"]]["popupPage"],
			placeHolder = languagePack[data["languagePack"]]['scriptPopup']['placeHolder'];
		language_full = languagePack[data["languagePack"]]['scriptPopup']['language_full'];
		Object.keys(placeHolder).forEach(function(e){
			document.getElementById(e).setAttribute('placeholder', placeHolder[e]);
		});
		document.getElementById('source_drop').innerHTML = '';
		document.getElementById('target_drop').innerHTML = '';
		Object.keys(language_full).forEach(function (key) {
			var btn = document.createElement('button');
			btn.id = 'sr_' + key;
			btn.value = key;
			btn.innerText = language_full[key];
			btn.addEventListener('click', update_source);
			document.getElementById('source_drop').appendChild(btn);
		});
		Object.keys(language_full).forEach(function (key) {
			if (key != "auto") {
				var btn = document.createElement('button');
				btn.id = 'tg_' + key;
				btn.value = key;
				btn.innerText = language_full[key];
				btn.addEventListener('click', update_target);
				document.getElementById('target_drop').appendChild(btn);
			}
		});
		Object.keys(obj).forEach(function(key){
			if(document.getElementById(key).getAttribute('logged')!='true')
				document.getElementById(key).innerText = obj[key];
		});
		document.getElementById("source_btn").innerText = language_full[localStorage.getItem("source_lang")];
		document.getElementById("target_btn").innerText = language_full[localStorage.getItem("trans_lang")];
	});
}
var typingTimer;   
var doneTypingInterval = 1000; 
$('#text-source').keydown(function() {
	if(!document.getElementById('waiting-button').classList.contains('waiting')){
		document.getElementById('text-target').value = ' ';
		document.getElementById('typing-button').classList.add('waiting');
	}
})
$('#text-source').keyup(function(){
    clearTimeout(typingTimer);
	if(document.getElementById('text-target').getAttribute('prevalue') == document.getElementById('text-source').value){
		document.getElementById('typing-button').classList.remove('waiting');
		document.getElementById('text-target').value = document.getElementById('text-target').getAttribute('pretrans'); 
	} 
	else {
    if ($('#text-source').val) {
        typingTimer = setTimeout(function(){
			document.getElementById('typing-button').classList.remove('waiting');
			document.getElementById('text-target').value = ' ';
			document.getElementById('waiting-button').classList.add('waiting');
			process_text(document.getElementById('text-source').value);
        }, doneTypingInterval);
    }
}
});
function sourceClose(){
	var list = document.getElementById("source_drop").children;
	document.getElementById("inputSource").value = "";
	for(var i = 0; i < list.length; i++){
		list[i].style.display = "";
	}
}
function targetClose(){
	var list = document.getElementById("target_drop").children;
	document.getElementById("inputTarget").value = "";
	for(var i = 0; i < list.length; i++){
		list[i].style.display = "";
	}
}
function processFunction() {
	document.getElementById('limitation').innerText = document.getElementById("text-source").value.length + '/1000';
}
function filterSource() {
	var input = document.getElementById('inputSource'),
		filter = input.value.toUpperCase(),
		list = document.getElementById("source_drop").children;
	for(var i = 0; i < list.length; i++){
		var match = list[i].innerText;
		if(match.toUpperCase().indexOf(filter) > -1){
			list[i].style.display = "";
		} else {
			list[i].style.display = "none";
		}
	}
}
function filterTarget() {
	var input = document.getElementById('inputTarget'),
		filter = input.value.toUpperCase(),
		list = document.getElementById("target_drop").children;
	for(var i = 0; i < list.length; i++){
		var match = list[i].innerText;
		if(match.toUpperCase().indexOf(filter) > -1){
			list[i].style.display = "";
		} else {
			list[i].style.display = "none";
		}
	}
}
function targetCopy() {
	var copytarget = document.getElementById("text-target");
	copytarget.select();
	copytarget.setSelectionRange(0, 99999);
	navigator.clipboard.writeText(copytarget.value);
	copytarget.setSelectionRange(0, 0);

	var tooltarget = document.getElementById("ToolTarget");
	tooltarget.innerHTML = languagePack[localStorage.getItem('languagePack')]['scriptPopup']['content_copied_status']
}

function sourceCopy() {
	var copysource = document.getElementById("text-source");
	copysource.select();
	copysource.setSelectionRange(0, 99999);
	navigator.clipboard.writeText(copysource.value);
	copysource.setSelectionRange(0, 0);

	var toolsource = document.getElementById("ToolSource");
	toolsource.innerHTML = languagePack[localStorage.getItem('languagePack')]['scriptPopup']['content_copied_status']
}

function outTarget() {
	var tooltarget = document.getElementById("ToolTarget");
	tooltarget.innerHTML = languagePack[localStorage.getItem('languagePack')]['popupPage']['ToolSource']
}

function outSource() {
	var toolsource = document.getElementById("ToolSource");
	toolsource.innerHTML = languagePack[localStorage.getItem('languagePack')]['popupPage']['ToolSource']
}
var	languagePack = {
		"vi": {
			"popupPage": {
				"content_access_login": "Truy cập tài khoản",
				"content_login_option": "Đăng nhập",
				"ToolSource": "Sao chép",
				"ToolTarget": "Sao chép",
				"content_access_query": "Truy cập vào English Book",
				"content_checkmarkButton": "Shift + E để bật/tắt EVTD",
				"content_designHeader": "Đổi giao diện",
				"content_design_title": "Đổi giao diện",
				"content_ex_t": "Câu ví dụ",
				"content_get_w": "Từ vựng theo ngày",
				"content_get_w_title": "Từ vựng theo ngày",
				"content_history_title": "Lịch sử tra cứu",
				"content_image_illustration": "Ảnh minh họa",
				"content_language_title": "Ngôn ngữ",
				"content_mean_lang": "Hiện nghĩa",
				"content_open_option": "Đọc sách Tiếng Anh",
				"content_open_setting": "Cài đặt",
				"content_query_history": "Xóa lịch sử tra cứu?",
				"content_settingHeader": "Cài đặt",
				"content_show_hist_btn": "Lịch sử tra cứu",
				"dict-type": "Tra cứu theo cách của bạn",
				"direct-no": "Không",
				"direct-yes": "Có",
				"loginDirect-no": "Không",
				"loginDirect-yes": "Có",
				"evtdSlogan": "Tra cứu theo cách của bạn",
				"evtd_title_content": "EVTD - Từ Điển Trình Duyệt",
				"reset-no": "Không",
				"reset-yes": "Có",
				"source_btn": "Chọn ngôn ngữ",
				"target_btn": "Chọn ngôn ngữ",
				"content_access_start": "Bắt đầu sử dụng EVTD",
				"_loginRequired_accountManager": "Đăng ký / Đăng nhập"
			},
			"scriptPopup": {
				"content_source_btn": "Tự động",
				"content_empty_history_title": "Lịch sử trống",
				"content_copied_status": "Đã sao chép",
				"language_full": {
					"af": "Tiếng Afrikaans",
					"am": "Tiếng Amharic",
					"ar": "Tiếng Ả Rập",
					"as": "Tiếng Assam",
					"auto": "Tự động",
					"az": "Tiếng Azerbaijan",
					"ba": "Tiếng Bashkir",
					"bg": "Tiếng Bulgaria",
					"bn": "Tiếng Bangla",
					"bo": "Tiếng Tây Tạng",
					"bs": "Tiếng Bosnia",
					"ca": "Tiếng Catalan",
					"cs": "Tiếng Séc",
					"cy": "Tiếng Wales",
					"da": "Tiếng Đan Mạch",
					"de": "Tiếng Đức",
					"dv": "Tiếng Divehi",
					"el": "Tiếng Hy Lạp",
					"en": "Tiếng Anh",
					"es": "Tiếng Tây Ban Nha",
					"et": "Tiếng Estonia",
					"eu": "Tiếng Basque",
					"fa": "Tiếng Ba Tư",
					"fi": "Tiếng Phần Lan",
					"fil": "Tiếng Philippines",
					"fj": "Tiếng Fiji",
					"fo": "Tiếng Faroe",
					"fr": "Tiếng Pháp",
					"fr-CA": "Tiếng Pháp (Canada)",
					"ga": "Tiếng Ireland",
					"gl": "Tiếng Galician",
					"gu": "Tiếng Gujarati",
					"he": "Tiếng Do Thái",
					"hi": "Tiếng Hindi",
					"hr": "Tiếng Croatia",
					"hsb": "Tiếng Thượng Sorbia",
					"ht": "Tiếng Haiti",
					"hu": "Tiếng Hungary",
					"hy": "Tiếng Armenia",
					"id": "Tiếng Indonesia",
					"ikt": "Tiếng Inuinnaqtun",
					"is": "Tiếng Iceland",
					"it": "Tiếng Italy",
					"iu": "Tiếng Inuktitut",
					"iu-Latn": "Inuktitut (Latin)",
					"ja": "Tiếng Nhật",
					"ka": "Tiếng Georgia",
					"kk": "Tiếng Kazakh",
					"km": "Tiếng Khmer",
					"kmr": "Tiếng Kurd (Bắc)",
					"kn": "Tiếng Kannada",
					"ko": "Tiếng Hàn",
					"ku": "Tiếng Kurd (Trung)",
					"ky": "Tiếng Kyrgyz",
					"lo": "Tiếng Lào",
					"lt": "Tiếng Litva",
					"lv": "Tiếng Latvia",
					"mg": "Tiếng Malagasy",
					"mi": "Tiếng Maori",
					"mk": "Tiếng Macedonia",
					"ml": "Tiếng Malayalam",
					"mn-Cyrl": "Mongolian (Cyrillic)",
					"mn-Mong": "Mongolian",
					"mr": "Tiếng Marathi",
					"ms": "Tiếng Mã Lai",
					"mt": "Tiếng Malta",
					"mww": "Tiếng H’Mông",
					"my": "Tiếng Miến Điện",
					"nb": "Tiếng Na Uy (Bokmål)",
					"ne": "Tiếng Nepal",
					"nl": "Tiếng Hà Lan",
					"or": "Tiếng Odia",
					"otq": "Querétaro Otomi",
					"pa": "Tiếng Punjab",
					"pl": "Tiếng Ba Lan",
					"prs": "Tiếng Dari",
					"ps": "Tiếng Pashto",
					"pt": "Bồ Đào Nha (Brazil)",
					"pt-PT": "Tiếng Bồ Đào Nha",
					"ro": "Tiếng Romania",
					"ru": "Tiếng Nga",
					"sk": "Tiếng Slovak",
					"sl": "Tiếng Slovenia",
					"sm": "Tiếng Samoa",
					"so": "Tiếng Somali",
					"sq": "Tiếng Albania",
					"sr-Cyrl": "Tiếng Serbia (Kirin)",
					"sr-Latn": "Tiếng Serbia (Latin)",
					"sv": "Tiếng Thụy Điển",
					"sw": "Tiếng Swahili",
					"ta": "Tiếng Tamil",
					"te": "Tiếng Telugu",
					"th": "Tiếng Thái",
					"ti": "Tiếng Tigrinya",
					"tk": "Tiếng Turkmen",
					"tlh-Latn": "Tiếng Klingon (Latin)",
					"tlh-Piqd": "Tiếng Klingon (pIqaD)",
					"to": "Tiếng Tonga",
					"tr": "Tiếng Thổ Nhĩ Kỳ",
					"tt": "Tiếng Tatar",
					"ty": "Tiếng Tahiti",
					"ug": "Tiếng Uyghur",
					"uk": "Tiếng Ukraina",
					"ur": "Tiếng Urdu",
					"uz": "Tiếng Uzbek",
					"vi": "Tiếng Việt",
					"yua": "Tiếng Maya Yucatec",
					"yue": "Tiếng Quảng Đông",
					"zh-Hans": "Tiếng Trung (Giản Thể)",
					"zh-Hant": "Tiếng Trung (Phồn Thể)",
					"zu": "Tiếng Zulu"
				},
				"placeHolder":{
					"text-source": "  Nhập văn bản cần dịch",
					"text-target": "  Văn bản đã dịch",
					"inputSource": "Tìm kiếm",
					"inputTarget": "Tìm kiếm"
				}
			},
			"evtdTranslateResult": {
				"textAreaOrigin": "Bản dịch",
				"textAreaResult": "Bản dịch",
				"translate_example": "Liên quan",
				"translate_imageBtn": "Ảnh minh họa",
				"translate_sentence": "Ví dụ"
			}
		},
		"en": {
			"popupPage": {
				"content_access_login": "Access account",
				"content_login_option": "Login",
				"ToolSource": "Copy",
				"ToolTarget": "Copy",
				"content_access_query": "You will be directed to a link",
				"content_checkmarkButton": "Shift + E to turn EVTD on/off",
				"content_designHeader": "Themes",
				"content_design_title": "Themes",
				"content_ex_t": "Example sentence",
				"content_get_w": "Daily word",
				"content_get_w_title": "Daily word",
				"content_history_title": "Lookup history",
				"content_image_illustration": "Pictures",
				"content_language_title": "Languages",
				"content_mean_lang": "Show meaning",
				"content_open_option": "Read English Books",
				"content_open_setting": "Settings",
				"content_query_history": "Delete lookup history?",
				"content_settingHeader": "Settings",
				"content_show_hist_btn": "Lookup history",
				"dict-type": "Look up your way",
				"direct-no": "No",
				"direct-yes": "Yes",
				"loginDirect-no": "No",
				"loginDirect-yes": "Yes",
				"evtdSlogan": "Look up your way",
				"evtd_title_content": "EVTD - Your Dictionary",
				"reset-no": "No",
				"reset-yes": "Yes",
				"source_btn": "Select language",
				"target_btn": "Select language",
				"content_access_start": "Start using EVTD",
				"_loginRequired_accountManager": "Sign up / Sign in"
			},
			"scriptPopup": {
				"content_source_btn": "Auto",
				"content_copied_status": "Copied",
				"content_empty_history_title": "Empty",
				"language_full": {
					"af": "Afrikaans",
					"am": "Amharic",
					"ar": "Arabic",
					"as": "Assamese",
					"auto": "Automatic",
					"az": "Azerbaijani",
					"ba": "Bashkir",
					"bg": "Bulgarian",
					"bn": "Bangla",
					"bo": "Tibetan",
					"bs": "Bosnian",
					"ca": "Catalan",
					"cs": "Czech",
					"cy": "Welsh",
					"da": "Danish",
					"de": "German",
					"dv": "Divehi",
					"el": "The Greek language",
					"en": "English",
					"es": "Spanish",
					"et": "Estonian",
					"eu": "Basque",
					"fa": "Persian",
					"fi": "Finnish",
					"fil": "Filipino",
					"fj": "Fijian",
					"fo": "Faroese",
					"fr": "French",
					"fr-CA": "French (Canada)",
					"ga": "Irish",
					"gl": "Galician",
					"gu": "Gujarati",
					"he": "Hebrew",
					"hi": "Hindi",
					"hr": "Croatian",
					"hsb": "Upper Sorbian",
					"ht": "Haitian",
					"hu": "Hungarian",
					"hy": "Armenian",
					"id": "Indonesian language",
					"ikt": "Inuinnaqtun language",
					"is": "Icelandic",
					"it": "Italian",
					"iu": "Inuktitut language",
					"iu-Latn": "Inuktitut (Latin)",
					"ja": "Japanese",
					"ka": "Georgian",
					"kk": "Kazakh",
					"km": "Khmer language",
					"kmr": "Kurdish (North)",
					"kn": "Kannada",
					"ko": "Korean",
					"ku": "Kurdish (Chinese)",
					"ky": "Kyrgyz",
					"lo": "Laos",
					"lt": "Lithuanian",
					"lv": "Latvian",
					"mg": "Malagasy",
					"mi": "Maori",
					"mk": "Macedonian",
					"ml": "Malayalam",
					"mn-Cyrl": "Mongolian (Cyrillic)",
					"mn-Mong": "Mongolian",
					"mr": "Marathi",
					"ms": "Malay",
					"mt": "Maltanese",
					"mww": "H'Mong language",
					"my": "Burmese",
					"nb": "Norwegian (Bokmål)",
					"ne": "Nepalese",
					"nl": "Dutch",
					"or": "Odia",
					"otq": "Querétaro Otomi",
					"pa": "Punjabi",
					"pl": "Polish language",
					"prs": "Dari language",
					"ps": "Pashto",
					"pt": "Portugal (Brazil)",
					"pt-PT": "Portuguese",
					"ro": "Romanian",
					"ru": "Russian",
					"sk": "Slovak",
					"sl": "Slovene",
					"sm": "Samoan",
					"so": "Somali",
					"sq": "Albanian",
					"sr-Cyrl": "Serbian (Kirin)",
					"sr-Latn": "Serbian (Latin)",
					"sv": "Swedish",
					"sw": "Swahili",
					"ta": "Tamil",
					"te": "Telugu",
					"th": "Thai",
					"ti": "Tigrinya",
					"tk": "Turkish",
					"tlh-Latn": "Klingon (Latin)",
					"tlh-Piqd": "Klingon (pIqaD)",
					"to": "Tonga",
					"tr": "Turkish",
					"tt": "Tatar",
					"ty": "Tahitian",
					"ug": "Uighur",
					"uk": "Ukrainian",
					"ur": "Urdu",
					"uz": "Uzbek",
					"vi": "Vietnamese",
					"yua": "Yucatec Mayan",
					"yue": "Chinese (Literature)",
					"zh-Hans": "Chinese (Simplified)",
					"zh-Hant": "Chinese (Traditional)",
					"zu": "Zulu"
				},
				"placeHolder": {
					"text-source": "Enter the text",
					"text-target": "Translation",
					"inputSource": "Search",
					"inputTarget": "Search"
				}
				},
				"evtdTranslateResult": {
				"textAreaOrigin": "Translation",
				"textAreaResult": "Translation",
				"translate_example": "Relates",
				"translate_imageBtn": "Pictures",
				"translate_sentence": "Examples"
				}
		}
	},
	lang_speak = { "af": "Afrikaans Male", "am": "UK English Female", "ar": "Arabic Female", "as": "UK English Female", "az": "UK English Female", "ba": "UK English Female", "bg": "UK English Female", "bn": "UK English Female", "bo": "UK English Female", "bs": "Bosnian Male", "ca": "French Canadian Female", "cs": "Czech Male", "cy": "Welsh Male", "da": "Danish Male", "de": "Deutsch Female", "dv": "UK English Female", "el": "Greek male", "en": "US English Female", "es": "Spanish Latin American Female", "et": "Estonian Male", "eu": "UK English Female", "fa": "UK English Female", "fi": "Finnish Female", "fil": "Filipino Female", "fj": "UK English Female", "fo": "UK English Female", "fr": "French Female", "fr-CA": "French Canadian Female", "ga": "UK English Female", "gl": "UK English Female", "gu": "UK English Female", "he": "UK English Female", "hi": "Hindi Female", "hr": "Serbo-Croatian Male", "hsb": "UK English Female", "ht": "UK English Female", "hu": "Hungarian Female", "hy": "Armenian Male", "id": "Indonesian Female", "ikt": "UK English Female", "is": "Icelandic Female", "it": "Italian Female", "iu": "UK English Female", "iu-Latn": "UK English Female", "ja": "Japanese Female", "ka": "UK English Female", "kk": "UK English Female", "km": "UK English Female", "kmr": "UK English Female", "kn": "UK English Female", "ko": "Korean Male", "ku": "UK English Female", "ky": "UK English Female", "lo": "UK English Female", "lt": "Latvian Male", "lv": "Latvian Male", "mg": "UK English Female", "mi": "UK English Female", "mk": "Macedonian Male", "ml": "UK English Female", "mn-Cyrl": "UK English Female", "mn-Mong": "UK English Female", "mr": "UK English Female", "ms": "UK English Female", "mt": "UK English Female", "mww": "UK English Female", "my": "UK English Female", "nb": "Norwegian Female", "ne": "Nepali", "nl": "Dutch Female", "or": "Tiếng Odia", "otq": "UK English Female", "pa": "UK English Female", "pl": "Polish Female", "prs": "UK English Female", "ps": "UK English Female", "pt": "Brazilian Portuguese Male", "pt-PT": "Portuguese Male", "ro": "Romanian Female", "ru": "Russian Female", "sk": "Slovak Female", "sl": "UK English Female", "sm": "UK English Female", "so": "UK English Female", "sq": "Albanian Male", "sr-Cyrl": "Serbian Male", "sr-Latn": "Serbian Male", "sv": "Swedish Female", "sw": "Swahili Male", "ta": "Tamil Female", "te": "UK English Female", "th": "Thai Female", "ti": "UK English Female", "tk": "UK English Female", "tlh-Latn": "UK English Female", "tlh-Piqd": "UK English Female", "to": "UK English Female", "tr": "Turkish Female", "tt": "UK English Female", "ty": "UK English Female", "ug": "UK English Female", "uk": "UK English Female", "ur": "UK English Female", "uz": "UK English Female", "vi": "Vietnamese Female", "yua": "UK English Female", "yue": "Chinese Female", "zh-Hans": "Chinese Male", "zh-Hant": "Chinese Taiwan Female", "zu": "UK English Female", };
	//50 languages

function sound_source() {
	responsiveVoice.speak(document.getElementById("text-source").value, lang_speak[document.getElementById("text-source").getAttribute("detectedLanguage")]);
}

function sound_target() {
	responsiveVoice.speak(document.getElementById("text-target").value, lang_speak[localStorage.getItem("trans_lang")]);
}

function process_text(text) {
	if (localStorage.getItem("trans_lang") === null) {
		localStorage.setItem("trans_lang", "vi");
	}
	const data = JSON.stringify([{
		"Text": text
	}]);
	var index = localStorage.getItem('popupCallindex');
	const xhr = new XMLHttpRequest();
	xhr.withCredentials = true;
	xhr.addEventListener("readystatechange", function () {
		if (this.readyState === this.DONE) {
			if (JSON.parse(this.responseText)['message'] == null) {
				chrome.storage.local.set({
					'popupCallindex': index
				})
				console.log(index);
				localStorage.setItem('popupCallindex', index);
				var response = JSON.parse(this.responseText),
					detect_language = response[0]['detectedLanguage']['language'],
					textTranslate = response[0]['translations'][0]['text'];
				document.getElementById("text-target").value = textTranslate;
				document.getElementById("text-target").setAttribute('prevalue', text);
				document.getElementById("text-target").setAttribute('pretrans', textTranslate);
				document.getElementById('text-source').setAttribute('detectedLanguage', detect_language);
				if (language_full[detect_language] === undefined) {
					document.getElementById('source_btn').innerText = "Tự động";
				} else {
					document.getElementById('source_btn').innerText = language_full[detect_language];
				}
			document.getElementById('waiting-button').classList.remove('waiting');
		} else {
				index++;
				if (index < evtd_application.length) {
					send(xhr, index, localStorage.getItem("trans_lang"));
				} else {
					chrome.storage.local.set({
						'popupCallindex': 0
					});
					localStorage.setItem('popupCallindex', 0);
				}
			}
		}
	});

	function send(xhr, index, target) {
		xhr.open("POST", "https://microsoft-translator-text.p.rapidapi.com/translate?to%5B0%5D=" + target + "&api-version=3.0&profanityAction=NoAction&textType=plain");
		xhr.setRequestHeader("content-type", "application/json");
		xhr.setRequestHeader("X-RapidAPI-Key", evtd_application[index]);
		xhr.setRequestHeader("X-RapidAPI-Host", "microsoft-translator-text.p.rapidapi.com");
		xhr.send(data);
	}
	send(xhr, index, localStorage.getItem("trans_lang"));
}

function show_source() {
	document.getElementById("source_drop").classList.toggle("show_source");
	document.getElementById("SourceSearch").classList.toggle("show_source");
}

function update_source() {
	document.getElementById("SourceSearch").classList.toggle("show_source");
	document.getElementById("source_drop").classList.toggle("show_source");
	document.getElementById("source_btn").innerText = language_full[this.value];
	localStorage.setItem("source_lang", this.value);
	setDict();
}
function show_target() {
	document.getElementById("target_drop").classList.toggle("show_target");
	document.getElementById("TargetSearch").classList.toggle("show_source");
}

function update_target() {
	localStorage.setItem("trans_lang", this.value);
	process_text(document.getElementById('text-source').value);
	document.getElementById("target_drop").classList.toggle("show_target");
	document.getElementById("TargetSearch").classList.toggle("show_source");
	document.getElementById("target_btn").innerText = language_full[this.value];
//document.getElementById("st-target").innerText = language_full[this.value];
	setDict();
}

function setDict() {
	var mode = localStorage.getItem("source_lang") + "-" + localStorage.getItem("trans_lang");
	document.getElementById("history").style.display = "none";
	chrome.runtime.sendMessage({
		"message": "dictionaries",
		"data": mode,
		"la": localStorage.getItem("trans_lang")
	}, function (response) {});
}