"use strict";
var International_filtered = {'relatedWord':[]};
var	languagePack = {
    "vi": {
            "textArea": "Bản dịch",
            "translate_example": "Liên quan",
            "translate_imageBtn": "Ảnh minh họa",
			"translate_exBtn": "Định nghĩa",
            "translate_sentence": "Ví dụ",
			"evtd_dialog_on": "Đã bật EVTD bằng Shift + E",
			"evtd_dialog_off": "Đã tắt EVTD bằng Shift + E"
    },
    "en": {
			"translate_imageBtn": "Definition(s)",
            "textArea": "Translation",
            "translate_example": "Relate(s)",
            "translate_exBtn": "Picture(s)",
            "translate_sentence": "Example(s)",
			"evtd_dialog_on": "EVTD has been turned on by Shift + E",
			"evtd_dialog_off": "EVTD has been turned off by Shift + E"
		}
};
var __evtdlog_dialog = document.createElement('div');
var __evtdlog_wrapper = document.createElement('div');
var __evtdlog_content = document.createElement('div');
var __evtdlog_closeButton = document.createElement('button');

__evtdlog_content.innerHTML = 'dialog';
__evtdlog_wrapper.setAttribute('class', '__evtdlog_wrapper');

__evtdlog_closeButton.setAttribute('class', '__evtdlog_closeButton');

__evtdlog_closeButton.innerHTML = `<i class="fa fa-xmark"></i>`; 
__evtdlog_closeButton.setAttribute('id','__evtdlog_closeButton');
__evtdlog_closeButton.addEventListener('click', function(){
	__evtdlog_dialog.style.bottom = '-300px';
});
__evtdlog_content.setAttribute('class', '__evtdlog_content');
__evtdlog_dialog.setAttribute('class', '__evtdlog_dialog');


__evtdlog_wrapper.appendChild(__evtdlog_closeButton);
__evtdlog_wrapper.appendChild(__evtdlog_content);
__evtdlog_dialog.appendChild(__evtdlog_wrapper);
$('body').append(__evtdlog_dialog);
$("#__evtdlog_closeButton").hover(function() {
	$(this).css("background-color", "rgba(255, 255, 255, 0.342)");
}, function() {
	$(this).css("background-color", "rgba(255, 255, 255, 0.642)");
});
var __evtdlog_dialogTimeout;
// $(document).keydown(function(e){
// 	if(e.which === 69 && e.shiftKey ){
	
		  
// 	   chrome.storage.local.get(['evtdStatus'], function(data){
// 		var status = Math.abs(1-data['evtdStatus']);
// 		clearTimeout(__evtdlog_dialogTimeout);
// 		__evtdlog_dialog.style.bottom = '20px';
// 		if(status==1) __evtdlog_content.innerHTML = languagePack[localStorage.getItem('languagePack')]['evtd_dialog_on']
// 		else {
// 			__evtdlog_content.innerHTML = languagePack[localStorage.getItem('languagePack')]['evtd_dialog_off'];
// 			evtd.style.visibility = "hidden";
// 		}
// 		__evtdlog_dialogTimeout =setTimeout(function() { __evtdlog_dialog.style.bottom = '-300px'; }, 2000);
// 		localStorage.setItem('evtdStatus', status);	
// 			chrome.storage.local.set({
// 				'evtdStatus': status
// 			})	
// 	   })
// 	}
	
//   });
  

var resultDiv = $("<div>", { id: "translatorResult" });
var status_get = false;
var detect_language = "";
var text = "";
var imagePanel = document.createElement("div");
imagePanel.setAttribute("class", "imagePanel");
var sentencePanel = document.createElement("div");
sentencePanel.setAttribute("class", "imagePanel");
var examplePanel = document.createElement("div");
examplePanel.setAttribute("class", "imagePanel");
imagePanel.setAttribute('id', 'imgPanel');
var evtd = document.createElement("button");
evtd.setAttribute("class", "evtd");

$('body').append(evtd);
var node = document.createElement("div"),
	load = document.createElement("div");
var ta = document.createElement("textarea");
ta.setAttribute("class", "f-input");
ta.setAttribute("id", "textAreaResult");
ta.setAttribute("spellcheck", "false");
node.appendChild(ta);
var btn3 = document.createElement("button"),
	btn4 = document.createElement("button"),
	divContainer2 = document.createElement("div");
divContainer2.style = "margin-top: 4.5px!important;";
btn3.setAttribute("class", "feature");
btn3.innerHTML = `<i id="voice-awesome" class="fa-solid fa-volume-high"></i>`;
btn3.addEventListener("click", function () {
		responsiveVoice.speak(ta.value, lang_speak[localStorage.getItem("target_la")]);
});
btn4.setAttribute("class", "copy");
btn4.innerHTML = `<i class="far fa-clone"></i>`;
btn4.addEventListener("click", targetCopy);
divContainer2.appendChild(btn3);
divContainer2.appendChild(btn4);
node.appendChild(divContainer2);
node.setAttribute("class", "textarea-container");
load.style.display = "block";
function targetCopy() {
	var copytarget = ta;
	copytarget.select();
	copytarget.setSelectionRange(0, 99999);
	navigator.clipboard.writeText(copytarget.value);
	copytarget.setSelectionRange(0, 0);
}
load.style.fontSize = "18px";
load.innerHTML = `<div style="margin-top: 4.5px!important; background-color: rgba(255, 255, 255, 0.4)!important; color: rgba(0, 0, 0, 0.953)!important; overflow: auto!important; outline: none!important; resize: none!important; width:99%!important; height: 80px!important; max-height: 80px!important; font-size: 20px!important; border-radius: 5px!important; border: 1px solid rgba(255,255,255,.27);"> <i class="fas fa-cog fa-spin" style="margin-top: 3px; margin-left: 3px;"></i> </div>`;
var style_code = ["linear-gradient(315deg,#FFCC70 0%, #C850C0 46%, #4158D0 100%)",
	"linear-gradient(315deg, #f5c62c 0%, #fca606 46%, #ff831d 100%)",
	"linear-gradient(315deg, rgba(255,213,13,1) 0%, rgba(255,46,46,1) 95%, rgba(255,59,34,1) 97%)",
	"linear-gradient(315deg, rgba(231,225,4,1) 2%, rgba(240,223,2,1) 9%, rgba(3,214,223,1) 100%)",
	"linear-gradient(315deg,rgb(92, 35, 247) ,rgb(81, 107, 255) 46%,rgb(255, 111, 183) 100%)",
	"linear-gradient(315deg, rgba(0,255,141,1) 0%, rgba(34,150,255,1) 81%, rgba(11,110,255,1) 97%)",
	"linear-gradient(315deg, rgba(66,212,255,1) 0%, rgba(66,153,255,1) 16%, rgba(13,52,255,1) 100%)",
	"linear-gradient(315deg, rgba(255,238,0,1) 0%, rgba(255,66,130,1) 94%, rgba(255,66,66,1) 100%)",
	"linear-gradient(315deg, rgba(248,27,255,1) 18%, rgba(118,0,255,1) 51%, rgba(4,214,235,1) 100%)"
];

function loadCssStyle() {
	chrome.storage.local.get(['userAccount'], function (data){
		(async () => {
			const src = chrome.extension.getURL('src/js/content_main.js');
			const contentScript = await import(src);
			contentScript.main("", data['userAccount'], true);
		  })();
	});

	$("body").append(`<style>
	.evtdLoaderLogoAnimation{
		border-radius:50%:
		padding:5px;
		-webkit-transition: opacity 3s ease-in-out;
		-moz-transition: opacity 3s ease-in-out;
		-ms-transition: opacity 3s ease-in-out;
		-o-transition: opacity 3s ease-in-out;
		 opacity: 1;
		animation: rotation 0.5s, glow 1.38s  alternate;
	}
#evtdLoaderIdentificationAnimation {
	animation: fadeIn 2.38s!important;
}
#examplePanelEVTDLoader>.relatedWord>.list1>li>a{
	font-weight: 500;
	background:rgba(255,255,255,.47);
    color: rgba(0,0,0,.84);
    text-decoration: none;
}
	#examplePanelEVTDLoader>.relatedWord>.rwTitle{
		background: #ffffffa3;
 	font-weight: 600;
	text-align:center;
	 margin-top: 5px;
		border-top-right-radius: 5px;
		border-top-left-radius: 5px;
	}
#examplePanelEVTDLoader>.relatedWord>.list1>li>strong{
 	font-weight: 600;
    background: #ffffffab;
    border-top-right-radius: 5px;
    border-bottom-right-radius: 5px;
}
#examplePanelEVTDLoader>.relatedWord>.list1>li{
	background:rgba(255,255,255,.27);    line-height: 20px;
}
#examplePanelEVTDLoader>.relatedWord>.list1>li>a:hover{
	text-decoration: none;
	
	background:rgba(255,255,255,.14);
}
@keyframes fadeIn {
	0% { opacity: 1; }
	100% { opacity: 0; }
  }
	@keyframes glow {
		from {
			box-shadow: 0 0 10px -10px rgba(255,255,255,.37);
		  }
		  to {
			box-shadow: 0 0 10px 10px rgba(235,235,235, 0.74);
		  }
	  }
	@keyframes rotation {
		from {
			transform:rotate(290deg);
		}
		to {
			transform:rotate(360deg);
		}
	  }
	.__evtdlog_content { margin: 5px;
		font-weight: 700;
		font-family: Segoe UI;
		color: rgba(0,0,0,.88); 
		-moz-user-select: none;
		-khtml-user-select: none;
		-webkit-user-select: none;
	 
		/*
		  Introduced in Internet Explorer 10.
		  See http://ie.microsoft.com/testdrive/HTML5/msUserSelect/
		*/
		-ms-user-select: none;
		user-select: none;
	}
	.__evtdlog_dialog { transition: bottom ease-in 0.28s; position: fixed; bottom: -300px; right: 20px; background: linear-gradient(315deg, rgb(255, 204, 112) 0%, rgb(200, 80, 192) 46%, rgb(65, 88, 208) 100%); width: 300px; height: 80px; border-radius: 5px; }
	.__evtdlog_wrapper {    margin: 5px;
		background: none;
		border: 1px solid rgba(255,255,255, .27);
		height: 70px;
		border-radius: 5px;}
	.__evtdlog_closeButton {transition: background-color ease-in 0.118s;background-color: rgba(255, 255, 255, 0.643); padding: 4px; color: rgb(0, 0, 0); font-size: 10px; cursor: pointer; border-radius: 0px 0px 0px 5px; display: flex; align-items: center; justify-content: center; font-weight: 647; border: 1px solid rgba(255, 255, 255, 0.27); position: fixed; right: 25px; margin-top: -1px; width: 25px !important; height: 25px !important; font-family: "Segoe UI" !important; border-top-right-radius: 5px;}
	.textarea-container {
  position: relative;
}
.imgBtn:hover {
	background-color: rgba(255, 255, 255, 0.542)!important;
}
.phanloai{
	border-radius: 5px;
    border-top: 0px solid rgb(242, 242, 242);
    border-bottom: 0px solid rgb(242, 242, 242);
    margin-top: 5px;
    opacity: 1;
    padding: 4.5px;
    background: rgba(255, 255, 255, 0.5);
    color: rgb(9, 47, 71);
    font-size: 10pt;
    font-weight: 650;
    font-family: "Segoe UI";
    margin-bottom: 5px;
	border: 1px solid rgba(255,255,255,.27);
}
.imgBtn {
	margin-top: 5px;
	background-color: rgba(255, 255, 255, 0.642);
	color: #fff!important;
	padding: 5px!important;
	min-width: 100px!important;
	max-width: 250px!important;
	color: #000!important;
	cursor: pointer!important;
	border-top-left-radius: 5px!important;
	border-top-right-radius: 5px!important;
    font-size: 12px!important;
    font-weight: 650!important;
    font-family: "Segoe UI"!important;
	text-align:left;
	border: 1px solid rgba(255,255,255,.27)!important;
	border-bottom: none!important;
}
.imagePanel{
	border-top-right-radius: 5px!important;
	border-botto-right-radius: 5px!important;
	border-bottom-left-radius: 5px!important;
    padding: 4.25px!important;
    background: rgba(255, 255, 255, 0.5)!important;
    color: rgb(9, 47, 71)!important;
    font-size: 12px!important;
    font-weight: 650!important;
    font-family: "Segoe UI"!important;
	max-height: 180px;
	overflow: scroll;
	overflow-x: hidden;
	border: 1px solid rgba(255,255,255,.27);
}
.evtd-img{
	
	width:32px;height:32px;position:absolute; top: 50%; left:50%;
	-webkit-transform: translate(-50%, -50%); -ms-transform: translate(-50%, -50%); transform: translate(-50%, -50%);
}
.evtd:hover {
	transform: rotate(360deg);
	box-shadow: 0 0 11px rgba(33,33,33,.2); 
  }
.evtd{
	padding: 0!important;
	border:none!important;
	visibility: hidden;
	transition: transform .45s ease-in-out;
	position: absolute;
	left: 	0px;
	bottom: 0px;
	width: 32px;
	height: 32px;
	border-radius: 50%;
	z-index:999999999999;
}
.feature {
    background-color: rgba(255, 255, 255, 0.642);
    padding: 4px;
    width: 25px!important;
	height: 40px!important;
    color: #000;
    font-size: 10px;
    font-family: 'Segoe UI';
    border: none;
    cursor: pointer;
    border-top-right-radius: 5px;
    font-weight: 647;
	border: 1px solid rgba(255,255,255,.27);
	border-bottom: none;
	border-left: none;
}

.feature:hover {
    background-color: rgba(255, 255, 255, 0.342)
}

.copy {
    background-color: rgba(255, 255, 255, 0.642);
    padding: 4px;
    width: 25px!important;
	height: 40px!important;
    color: #000;
    font-size: 10px;
    font-family: 'Segoe UI';
    border: none;
    cursor: pointer;
    border-bottom-right-radius: 5px;
    font-weight: 647;
	border: 1px solid rgba(255,255,255,.27);
	border-top: none;
	border-left: none;
}

.copy:hover {
    background-color: rgba(255, 255, 255, 0.342)
}

.EVTDclose-btn {
    background-color: rgba(255, 255, 255, 0.642);
    color: #fff;
    padding: 4px;
    width: 25px!important;
	height: 25px!important;
    color: #000;
    font-size: 10px;
    font-family: 'Segoe UI'!important;
    cursor: pointer;
    border-radius: 5px;
	display: flex;
    align-items: center;
    justify-content: center;	
    font-weight: 647;
	margin-top: -5px;
	margin-right: -5px;
	border-top-left-radius: 0px;
	border-top-right-radius: 0px;
	border-bottom-right-radius: 0px;
	border: 1px solid rgba(255,255,255,.27);
}
.close-container{
	display:flex;
	justify-content:right;
	margin-bottom: 5px;
}
.EVTDclose-btn:hover {
    background-color: rgba(255, 255, 255, 0.342)!important;
}
.textarea-container textarea {
  box-sizing: border-box;
}
.textarea-container button {
    display: flex;
    align-items: center;
    align-content: center;
    justify-content: center;
    justify-items: center;
}
.f-input {
	margin-top: 4.5px!important;
    background-color: rgba(255, 255, 255, 0.4)!important;
    color: rgba(0, 0, 0, 0.953)!important;
    overflow: auto!important;
    outline: none!important;
    resize: none!important;
    width: 100%!important;
    height: 80px!important;
	max-height: 80px!important;
    font-size: 14px!important;
    font-family: 'Segoe UI'!important;
    border-top-left-radius: 5px!important;
    border-bottom-left-radius: 5px!important;
    font-weight: 625!important;
	border: 1px solid rgba(255,255,255,.27);
}
	.audio_button:hover {
	    color: rgba(255, 255, 255, 0.689);
	}

	.dropbtn:hover {
	    background-color: rgba(255, 255, 255, 0.342)
	}

	.dropbtn {
	    background-color: rgba(255, 255, 255, 0.642);
	    color: #fff!important;
	    padding: 5px!important;
	    min-width: 100px!important;
	    max-width: 250px!important;
	    color: #000!important;
	    font-size: 12px!important;
	    font-family: 'Segoe UI';
	    border: none!important;
	    cursor: pointer!important;
	    border-top-left-radius: 5px!important;
	    border-top-right-radius: 5px!important;
	    font-weight: 647!important
	}
	
	#textAreaResult::-webkit-scrollbar {
		width: 8px!important;
	}
	#textAreaResult::-webkit-scrollbar-track {
		border-top-right-radius: 2px!important;
		border-end-end-radius: 2px!important;
		box-shadow: outset 0 0 5px rgba(160, 160, 160, 0.336)!important;
		background: white!important;
	}
	
	#textAreaResult::-webkit-scrollbar-thumb {
		background: #dfdfdf!important;
		border-top-right-radius: 0px!important;
	}
	#textAreaResult::-webkit-scrollbar-thumb:hover {
		background: rgb(168 168 168)!important;
		width: 10px!important;
	}
	#translatorResult::-webkit-scrollbar {
		width: 8px!important;
	}
	#translatorResult::-webkit-scrollbar-track {
		border-top-right-radius: 2px!important;
		border-end-end-radius: 2px!important;
		box-shadow: outset 0 0 5px rgba(160, 160, 160, 0.336)!important;
		background: #fff!important;
	}
	#translatorResult::-webkit-scrollbar-thumb {
		background: #dfdfdf!important;
		border-top-right-radius: 0px!important;
	}
	#translatorResult::-webkit-scrollbar-thumb:hover {
		background: rgb(168 168 168)!important;
		width: 10px!important;
	}


	.imagePanel::-webkit-scrollbar {
		width: 8px!important;
	}
	
	.imagePanel::-webkit-scrollbar-track {
		border-top-right-radius: 2px!important;
		border-end-end-radius: 2px!important;
		box-shadow: outset 0 0 5px rgba(160, 160, 160, 0.336)!important;
		background: #fff
	}
	
	.imagePanel::-webkit-scrollbar-thumb {
		background: #dfdfdf!important;
		border-top-right-radius: 0px
	}
	.imagePanel::-webkit-scrollbar-thumb:hover {
		background: rgb(168 168 168)!important;
		width: 10px!important;
	}
	
	
	#textAreaOrigin::-webkit-scrollbar {
		width: 8px!important;
	}
	
	#textAreaOrigin::-webkit-scrollbar-track {
		border-top-right-radius: 2px!important;
		border-end-end-radius: 2px!important;
		box-shadow: outset 0 0 5px rgba(160, 160, 160, 0.336)!important;
		background: #fff!important;
	}
	
	#textAreaOrigin::-webkit-scrollbar-thumb {
		background: #dfdfdf!important;
		border-top-right-radius: 0px!important;
	}
	#textAreaOrigin::-webkit-scrollbar-thumb:hover {
		background: rgb(168 168 168)!important;
		width: 10px!important;
	}

	.wordPanel{
	border: 1px solid rgba(255,255,255,.27)!important;
		margin-top: 4.5px;
		border-radius: 5px!important;
		padding: 4.25px!important;
		background: rgba(255, 255, 255, 0.362)!important;
		color: rgb(9, 47, 71)!important;
		font-size: 14px!important;
		font-weight: 650!important;
		font-family: "Segoe UI"!important;
	}
	.highlight {
	    background-color: #ffffff66!important;
    border-radius: 3px!important;
    padding: 0.85px!important;
	  }
	.word_title{
		border-radius: 5px!important;
    padding: 4.25px!important;
    background: rgba(255, 255, 255, 0.5)!important;
    color: rgb(9, 47, 71)!important;
    font-size: 14px!important;
    font-weight: 650!important;
    font-family: "Segoe UI"!important;
	border: 1px solid rgba(255,255,255,.27);
	}
	.importantRule{ width: 400px!important; }
	</style>`);
}
loadCssStyle();
const data = null;
const xhr = new XMLHttpRequest();
xhr.withCredentials = true;
var value = 0;
var currentY = 0;
var windowY = 0;
var topPage = 0;
var currentX = 0;
var isDragging = false;
var curr_word = "";
var audio_link = "";
var WIDTH_POPUP = 400;
var RADOM_SRING = "4902743617";
var audio_cName = "";
var evtd_application = ['7cd95279b3msh22ca2841711a976p16c40cjsn6496096309d5', 
					'cab04e5891msh4c24f8994ca0b68p13e901jsn85591d19350a', 
					'7a80ca2ef5mshb089d282f64bc61p1f4b03jsn3d7f719f941e',
					 '6ea68323dcmshee0d767e1a662d2p19d328jsn32b06331969c',
					  '12300f284emsh4f8ef82b9cd45cdp1b59e1jsn350b64316fcd',
					   '0dc529f275mshb90d90ae899cc1ep1655fcjsn82dd810a35d7','6de3e37aa9mshf1e294fa42e226dp1bdfb3jsnde7361c24c64','ab9cc239dbmsh981394dc6cc84e9p19b784jsnbe0c8a08f80c'];
var lang_speak = { "af": "Afrikaans Male", "am": "UK English Female", "ar": "Arabic Female", "as": "UK English Female", "az": "UK English Female", "ba": "UK English Female", "bg": "UK English Female", "bn": "UK English Female", "bo": "UK English Female", "bs": "Bosnian Male", "ca": "French Canadian Female", "cs": "Czech Male", "cy": "Welsh Male", "da": "Danish Male", "de": "Deutsch Female", "dv": "UK English Female", "el": "Greek male", "en": "US English Female", "es": "Spanish Latin American Female", "et": "Estonian Male", "eu": "UK English Female", "fa": "UK English Female", "fi": "Finnish Female", "fil": "Filipino Female", "fj": "UK English Female", "fo": "UK English Female", "fr": "French Female", "fr-CA": "French Canadian Female", "ga": "UK English Female", "gl": "UK English Female", "gu": "UK English Female", "he": "UK English Female", "hi": "Hindi Female", "hr": "Serbo-Croatian Male", "hsb": "UK English Female", "ht": "UK English Female", "hu": "Hungarian Female", "hy": "Armenian Male", "id": "Indonesian Female", "ikt": "UK English Female", "is": "Icelandic Female", "it": "Italian Female", "iu": "UK English Female", "iu-Latn": "UK English Female", "ja": "Japanese Female", "ka": "UK English Female", "kk": "UK English Female", "km": "UK English Female", "kmr": "UK English Female", "kn": "UK English Female", "ko": "Korean Male", "ku": "UK English Female", "ky": "UK English Female", "lo": "UK English Female", "lt": "Latvian Male", "lv": "Latvian Male", "mg": "UK English Female", "mi": "UK English Female", "mk": "Macedonian Male", "ml": "UK English Female", "mn-Cyrl": "UK English Female", "mn-Mong": "UK English Female", "mr": "UK English Female", "ms": "UK English Female", "mt": "UK English Female", "mww": "UK English Female", "my": "UK English Female", "nb": "Norwegian Female", "ne": "Nepali", "nl": "Dutch Female", "or": "Tiếng Odia", "otq": "UK English Female", "pa": "UK English Female", "pl": "Polish Female", "prs": "UK English Female", "ps": "UK English Female", "pt": "Brazilian Portuguese Male", "pt-PT": "Portuguese Male", "ro": "Romanian Female", "ru": "Russian Female", "sk": "Slovak Female", "sl": "UK English Female", "sm": "UK English Female", "so": "UK English Female", "sq": "Albanian Male", "sr-Cyrl": "Serbian Male", "sr-Latn": "Serbian Male", "sv": "Swedish Female", "sw": "Swahili Male", "ta": "Tamil Female", "te": "UK English Female", "th": "Thai Female", "ti": "UK English Female", "tk": "UK English Female", "tlh-Latn": "UK English Female", "tlh-Piqd": "UK English Female", "to": "UK English Female", "tr": "Turkish Female", "tt": "UK English Female", "ty": "UK English Female", "ug": "UK English Female", "uk": "UK English Female", "ur": "UK English Female", "uz": "UK English Female", "vi": "Vietnamese Female", "yua": "UK English Female", "yue": "Chinese Female", "zh-Hans": "Chinese Male", "zh-Hant": "Chinese Taiwan Female", "zu": "UK English Female" };
$("body").mouseup(getString);
$('body').click(function(evt){
		if ((evt.target.id != "img-btn")) {
			chrome.storage.local.get(['userAccount', "color_code", "press-delete", "target_la", "dict_type", "imageCallindex", 'languagePack', 'translateCallindex', 'yourDictionary'], function (data) {
				localStorage.setItem('userAccount', data['userAccount']);
				style_code = ["linear-gradient(315deg,#FFCC70 0%, #C850C0 46%, #4158D0 100%)", "linear-gradient(315deg, #f5c62c 0%, #fca606 46%, #ff831d 100%)", "linear-gradient(315deg, rgba(255,213,13,1) 0%, rgba(255,46,46,1) 95%, rgba(255,59,34,1) 97%)", "linear-gradient(315deg, rgba(231,225,4,1) 2%, rgba(240,223,2,1) 9%, rgba(3,214,223,1) 100%)", "linear-gradient(315deg,rgb(92, 35, 247) ,rgb(81, 107, 255) 46%,rgb(255, 111, 183) 100%)", "linear-gradient(315deg, rgba(0,255,141,1) 0%, rgba(34,150,255,1) 81%, rgba(11,110,255,1) 97%)", "linear-gradient(315deg, rgba(66,212,255,1) 0%, rgba(66,153,255,1) 16%, rgba(13,52,255,1) 100%)", "linear-gradient(315deg, rgba(255,238,0,1) 0%, rgba(255,66,130,1) 94%, rgba(255,66,66,1) 100%)", "linear-gradient(315deg, rgba(248,27,255,1) 18%, rgba(118,0,255,1) 51%, rgba(4,214,235,1) 100%)" ];
					if (data['yourDictionary'] == undefined){
						localStorage.setItem('yourDictionary', 1);
						chrome.storage.local.set({
							'yourDictionary': '{}'
						})
					} else localStorage.setItem('yourDictionary', data['yourDictionary']);
					// if (data['evtdStatus'] == undefined){
					// 	localStorage.setItem('evtdStatus', 1);
					// 	chrome.storage.local.set({
					// 		'evtdStatus': 1
					// 	})
					// } else localStorage.setItem('evtdStatus', data['evtdStatus']);
					if (data["languagePack"] == undefined){
						localStorage.setItem('languagePack', 'en');
						chrome.storage.local.set({
							'languagePack': "en"
						});
					} else localStorage.setItem('languagePack', data['languagePack']);
					if (data["imageCallindex"] == undefined) {
						localStorage.setItem("imageCallindex", 0);
						chrome.storage.local.set({
							'imageCallindex': 0
						});
					} else localStorage.setItem('imageCallindex', data['imageCallindex']);
					if (data["translateCallindex"] == undefined) {
						localStorage.setItem("translateCallindex", 0);
						chrome.storage.local.set({
							'translateCallindex': 0
						});
					} else localStorage.setItem('translateCallindex', data['translateCallindex']);
					if (data["color_code"] == undefined) {
						localStorage.setItem("color_value", 0);
						chrome.storage.local.set({
							'color_code': 0
						});
					} else localStorage.setItem("color_value", data["color_code"]);
					// if (data["press-delete"] == 1) {
					// 	chrome.storage.local.set({
					// 		'press-delete': ''
					// 	});
					// 	localStorage.setItem("hist", data["word-list"]);
					// }
					if (data["dict_type"] == undefined) {
						localStorage.setItem("dict_type", "en-vi");
						chrome.storage.local.set({
							'dict_type': "en-vi"
						});
					} else localStorage.setItem("dict_type", data["dict_type"]);
					if (data["target_la"] == undefined) {
						localStorage.setItem("target_la", "vi");
						chrome.storage.local.set({
							'target_la': "vi"
						});
					} else localStorage.setItem("target_la", data["target_la"]);
			});
		
				if (!isDragging) {
					if (evt.target.id == "translatorResult") return;
					if ($(evt.target).closest('#translatorResult').length) return;
					if ($('#translatorResult').length > 0 && (evt.target != "img-btn")) {
						$('#translatorResult').remove();
						responsiveVoice.cancel();
					}
				} else {
					document.getElementById("translatorResult").dragging = false;
					isDragging = false;
				}
		}
});
function imageCall() {
	imagePanel.innerHTML = '';
	var index_key = localStorage.getItem('imageCallindex');
	const data = null;
	const sender = new XMLHttpRequest();
	sender.withCredentials = true;
	sender.addEventListener("readystatechange", function () {
		if (this.readyState === this.DONE) {
				if (JSON.parse(this.responseText)['message'] == null) {
					chrome.storage.local.set({
						'imageCallindex': index_key
					})
					var result = JSON.parse(this.responseText)["value"];
					var index = 0;
					for (index = 0; index < result.length; index++) {
						var k = document.createElement("img");
						k.src = result[index]["thumbnailUrl"];
						k.setAttribute('draggable', false);
						k.style = "max-height:400px;max-width:400px;width:400px;height:auto;border-radius:5px;margin-top:1px;";
						imagePanel.appendChild(k);
					}
					document.getElementById('evtdLoaderIdentificationAnimation').style = 'display:none!important';
				} else {
					index_key++;
					if (index_key < evtd_application.length) {
						send(sender, index_key);
					} else {
						chrome.storage.local.set({
							'imageCallindex': 0
						});
						localStorage.setItem('imageCallindex', 0);
					}
				}
		}
	});
	function send(xhr, index) {
		xhr.open("GET", "https://bing-image-search1.p.rapidapi.com/images/search?q="+text);
		xhr.setRequestHeader("X-RapidAPI-Key", evtd_application[index]);
		xhr.setRequestHeader("X-RapidAPI-Host", "bing-image-search1.p.rapidapi.com");
		xhr.send(data);
	}
	send(sender, index_key);
}
const isDescendant = function (parent, child) {
	let node = child.parentNode;
	while (node) {
		if (node === parent) {
			return true;
		}
		node = node.parentNode;
	}
	return false;
};
function getString(event) {
// 	if(localStorage.getItem('evtdStatus')==0)return;
	const img = document.createElement("img");
	img.src = chrome.runtime.getURL("./evtd.png");
	img.setAttribute("class", "evtd-img");
	img.setAttribute('draggable', false);
	img.setAttribute("id", "img-btn");
	evtd.appendChild(img);
	evtd.style.visibility = "hidden";
	if ((!isDragging) && (!(isDescendant(document.getElementById("translatorResult"), event.target))) && (event.target.id != "translatorResult") && (event.target.id != "img-btn") && (window.getSelection().toString().trim() != "")) {
		var y = "";
		currentY = parseInt(event.clientY);
		topPage = parseInt(event.pageY) - parseInt(event.clientY);
		windowY = parseInt(window.innerHeight);
		if (currentY > windowY / 2) {
			y = topPage + currentY - 345 + "px";
		} else {
			y = topPage + currentY + 15 + "px";
		}
		value = localStorage.getItem("color_value");
		if(value === null){
			value = 0;
		}
		currentX = parseInt(event.clientX) - WIDTH_POPUP / 2;
		resultDiv.css({
			"box-shadow": "#e4e4e4 0px 0px 2px 2px",
			"text-align": "left",
			"font-family": "'Segoe UI', sans-serif",
			"font-size": "9.8pt",
			"max-height": "450px",
			"overflow": "auto",
			"padding": "5px",
			"margin": "5px",
			"border-radius": "5px",
			"color": "#ffffff",
			"background": style_code[value],
			"position": "absolute",
			"top": y,
			"left": currentX + "px",
			"z-index": "99999999999999999",
			"opacity": "0.93",
			"overflow-x": "hidden"
		});
		resultDiv.addClass('importantRule');
		evtd.style.left = (parseInt(event.pageX)) + 48 + "px";
		evtd.style.top = (parseInt(event.pageY) - 0 * parseInt(event.clientX)) - 48 + "px";
		if (window.getSelection) {
			node.style.display = "none";
			load.style.display = "block";
			text = window.getSelection().toString().trim();
			if (text.indexOf("’") > -1) {
				text = text.substring(0, text.indexOf("’"));
			}
			if (text && text != "" && text.length > 1) {
				img.addEventListener('click', function (e) {
					curr_word = text;
					const data = JSON.stringify([{
						"Text": text
					}]);
					
					var index_key = localStorage.getItem('imageCallindex');
					const xhr = new XMLHttpRequest();
					xhr.withCredentials = true;
					xhr.addEventListener("readystatechange", function () {
						if (this.readyState === this.DONE) {
							var response =  JSON.parse(this.responseText);
							if (response['message'] == null) {
								chrome.storage.local.set({
									'translateCallindex': index_key
								})
								var text = response[0]['translations'][0]['text'];
								ta.innerText = text;
								load.style.display = "none";
								node.style.display = "flex";
								detect_language =  response[0]['detectedLanguage']['language'];
								storeHist(curr_word, text);
							} else {
								index_key++;
								if (index_key < evtd_application.length) {
									send(xhr, index_key, localStorage.getItem("target_la"));
								} else {
									chrome.storage.local.set({
										'translateCallindex': 0
									});
									localStorage.setItem('translateCallindex', 0);
								}
							}
						}
					});
					function send(xhr, index, target) {
						xhr.open("POST", "https://microsoft-translator-text.p.rapidapi.com/translate?to%5B0%5D=" + target + "&api-version=3.0&profanityAction=NoAction&textType=plain");
						xhr.setRequestHeader("content-type", "application/json");
						xhr.setRequestHeader("X-RapidAPI-Key", evtd_application[index]);
						xhr.setRequestHeader("X-RapidAPI-Host", "microsoft-translator-text.p.rapidapi.com");
						xhr.send(data);
					}
					document.getElementById("translatorResult").style.visibility = 'visible';
					var spalsh = document.createElement('div');
					spalsh.id = "evtdLoaderIdentificationAnimation"
					spalsh.style = 'position:absolute; width:100%; height:100%;top:0;left:0; background:white;display: flex; align-items: center; justify-content: center  /* Border color is optional */';
					var evtdLogo = document.createElement('img');
					evtdLogo.style=`
					padding:5px; background:white;border-radius:50%;
					width:50px; height:50px;`;

					evtdLogo.className = 'evtdLoaderLogoAnimation';
					evtdLogo.src = chrome.runtime.getURL("./evtd.svg");
					
					spalsh.appendChild(evtdLogo);
					document.getElementById('translatorResult').lastChild.after(spalsh);
					
					send(xhr, index_key, localStorage.getItem("target_la"));
					imageCall();
					chrome.runtime.sendMessage({
						"message": "vdict",
						"data": text,
						"dict": localStorage.getItem("dict_type")
					});
				})
				chrome.runtime.sendMessage({
					"message": "query",
					"data": text,
					"dict": localStorage.getItem("dict_type")
				});
			
			}
		}
	}
}
chrome.runtime.onMessage.addListener(
	function (request, sender, sendResponse) {
		if (request.message == "reply") {
			status_get = false;
			if ($(request.data).find("#result-contents").html() === undefined) {
				status_get = true;
				result = `
				<div id="tandp">
				<div class="word_title" id="language_title">EVTD</div>
				<div class="pronunciation">
				<div id="flashcontent"></div>
				<div class="pronounce"></div>
				</div>
				</div>
				`;
			} else {
				var result = $(request.data).find("#result-contents").html();
			}
			evtd.style.visibility = "visible";
			result = $.parseHTML(result);
			var alt_result = request.data;
			if (result == undefined) {
				result = '<div id="blank_stage" class="word_title">404 error</div>';
			} else {
				var audio_div = createAudio(alt_result);
				result.splice(4, 0, audio_div);
				filter(result);
			}
			
			if ($('#translatorResult').length > 0) {
				$('#translatorResult').empty();
			} else {
				$('body').append(resultDiv);
			}
		
			
			position(result);
			$("." + RADOM_SRING + "audio" + RADOM_SRING).click(playSound);
		} else if (request.message == "vdictReply"){
			var vdict = $(request.data).find("#result-contents").html();
			vdict = $.parseHTML(vdict);
			
			var disc = [];
			var filtered = {'relatedWord':[]};
			for (var i = 0; i < vdict.length; i++) {
				var className = vdict[i].className;
				var id = vdict[i].id;
				var nodeName = vdict[i].nodeName;
				if(id=='tandp'){
					try{filtered['word'] = vdict[i].children[0].innerHTML.replace(/(\r\t\n|\n|\r|\t)/gm, "");} catch(err){}
					try{filtered['pronounce'] = vdict[i].children[1].children[1].innerHTML.replace(/(\r\t\n|\n|\r|\t)/gm, "");} catch (err){}
				}
				if(className=="clear"||className==""||nodeName=="#text"||nodeName=="#comment"||id=="adsensediv"||className == "dictionary-name" || className == "")continue;
				if(className=="idioms")vdict[i].innerHTML = 'cụm động từ';
				disc.push(vdict[i]);
			}
			for(var index = 0; index < disc.length; index++){
				if(disc[index].className=="phanloai"||disc[index].className=="idioms"){
						if(!filtered.hasOwnProperty(disc[index].innerHTML))filtered[disc[index].innerHTML] = [];
					index++;
					for(var j = index; j < disc.length; j++){
						if(disc[j].className!="list1")break;
						filtered[disc[index-1].innerHTML].push(disc[j]);						
					}					
				} else if (disc[index].className == "relatedWord"){
					if(disc[index].children[1].id=="fb-root")continue;
					var relate = disc[index].children[1].children;
					for(var p = 0; p < relate.length; p++){
						var pa = relate[p].children;
						for(var pt = 0; pt < pa.length; pt++){
							if(pa[pt].tagName=='A') if(pa[pt].hasAttribute('href'))pa[pt].removeAttribute('href');
						}
					}
					filtered['relatedWord'].push(disc[index]);
				}
			}
			 International_filtered = filtered;
			 examplePanel.innerHTML = ``;
			// examplePanel.innerHTML = filtered['word'] + '&nbsp;' + filtered['pronounce'];
			var pronounceContainer = document.createElement('div');
			var wordDiv = document.createElement('button');
			wordDiv.style =  `border-radius:5px; width: 100%; background: rgba(255,255,255,.54); border: none; padding: 3px; color: rgb(0 0 0 / 64%); font-size: 14px; font-weight: 500; font-family: 'Segoe UI';`;
			wordDiv.innerHTML = filtered['word']+ "&nbsp;"+ filtered['pronounce'];
			pronounceContainer.appendChild(wordDiv);
			wordDiv.textAlign = 'left';
			pronounceContainer.style='border-radius:5px';
			examplePanel.appendChild(pronounceContainer);

			if(filtered.hasOwnProperty('word'))delete filtered['word'];
			if(filtered.hasOwnProperty('pronounce'))delete filtered['pronounce'];
			var split = [];
			if(filtered.hasOwnProperty('relatedWord')){
				var split = filtered['relatedWord'];
			}
			Object.keys(filtered).forEach(function(f){
				if (f != "relatedWord") {
					var temp_container = document.createElement('div');
					var temp_title = document.createElement('div');
					temp_title.innerHTML = f;

					temp_title.style = 'margin-top:5px; border-top-left-radius:5px; border-top-right-radius:5px; text-align:center; background: rgba(255,255,255,.64)!important; font-weight: 600;';
					temp_container.appendChild(temp_title);
					temp_container.style.background = 'rgba(255,255,255,.24)';
					var temp_content = document.createElement('div');
					for (var z = 0; z < filtered[f].length; z++) {
						filtered[f][z].style = 'background:rgba(255,255,255,.14); font-weight:400';
						temp_content.appendChild(filtered[f][z]);
					}
					temp_container.appendChild(temp_content);
					examplePanel.appendChild(temp_container);
				}
			})			
			for(var k = 0; k < split.length; k++){
				examplePanel.appendChild(split[k]);
			}				

		}
			
	});
function storeHist(word, mean) {
	var loader = {};	
	var idiom = [];
	Object.keys(International_filtered).forEach(function(f){
		if(f!="pronounce"&&f!="word"){
			loader[f] = {};
			for(var k = 0; k < International_filtered[f].length; k++){
					if(International_filtered[f][k].className == "relatedWord"){
						continue;
					} else {
						if(International_filtered[f][k].children[0].children[0].className =="idiom-meaning"){
							idiom = International_filtered[f][k];
							var id = [idiom.children[0].children[0].innerText, idiom.children[0].children[1].children[0].children[0].innerText];							
						}
						 else {
							var list1 = International_filtered[f][k];
							var header = list1.querySelector('li > b ').innerHTML;
							var body = list1.querySelectorAll('li > .list2 > li');
							if(!loader[f].hasOwnProperty(header))loader[f][header] = [];
							body.forEach(function(card){
								var pack = {};
								var temp = document.createElement('div');
								temp.innerHTML = card.innerHTML.split('<br>')[0];
								pack[temp.children[0].innerHTML] = card.innerHTML.split('<br>')[1];
								loader[f][header].push(pack);
							})
						}
					}
			}
		};
	})		
	var yourDictionary = JSON.parse(localStorage.getItem('yourDictionary')),
		userAccount = localStorage.getItem('userAccount');
		yourDictionary[word] = {};
	    yourDictionary[word]['loader'] = loader;
		yourDictionary[word]['mean'] = mean;
		yourDictionary[word]['timestamp'] = new Date().toLocaleString();
	// chrome.storage.local.get(['userAccount'], function(data){
	// });)
	if (localStorage.getItem('userAccount')!=null){
		(async () => {
			const src = chrome.extension.getURL('src/js/content_main.js');
			const contentScript = await import(src);
			contentScript.main(JSON.stringify(yourDictionary), userAccount, false);
		  })();
	}
	localStorage.setItem('yourDictionary', JSON.stringify(yourDictionary));
	chrome.storage.local.set({
		'yourDictionary': JSON.stringify(yourDictionary)
	});
}
function position(result) {

	//fix the pop - up location at edge cases
	if (parseInt(document.getElementById("translatorResult").style.left) < 0) document.getElementById("translatorResult").style.left = "0px";
	if (parseInt(document.getElementById("translatorResult").style.left) + WIDTH_POPUP > parseInt(window.innerWidth)) document.getElementById("translatorResult").style.left = parseInt(window.innerWidth) - 425 + "px";
	var atX = 0;
	var atY = 0;
	$('#translatorResult').html(result);
	document.getElementById("translatorResult").onmousedown = function () {
		isDragging = true;
		this.dragging = true;
		atX = parseInt(event.clientX);
		atY = parseInt(event.clientY);
	};
	document.getElementById("translatorResult").onmouseup = function () {
		isDragging = false;
		this.dragging = false;
	};
	document.getElementById("translatorResult").onmousemove = function () {
		if (this.dragging) {
			var newLocationX = parseInt(event.clientX);
			var newLocationY = parseInt(event.clientY);
			var dx = newLocationX - atX;
			var dy = newLocationY - atY;
			atX = newLocationX;
			atY = newLocationY;
			document.getElementById("translatorResult").style.left =
				parseInt(document.getElementById("translatorResult").style.left) + dx + "px";
			document.getElementById("translatorResult").style.top =
				parseInt(document.getElementById("translatorResult").style.top) + dy + "px";
		}
	};
	document.getElementById("translatorResult").style.visibility = 'hidden';
	pretty();
	if (parseInt(document.getElementById("translatorResult").offsetHeight) < 312 &&
		currentY > windowY / 2) {
		document.getElementById("translatorResult").style.top = parseInt(document.getElementById("translatorResult").style.top) +
			(320 - parseInt(document.getElementById("translatorResult").offsetHeight)) + "px";
	}
	
}
function createAudio(alt_result) {
	audio_link = "";
	var soundFileArray = alt_result.match(/http.*\.mp3/);
	var button = document.createElement("div");
	button.setAttribute('id', 'audio_player');
	audio_cName = RADOM_SRING + "audio" + RADOM_SRING;
	button.className = audio_cName;
	if (soundFileArray && soundFileArray.length > 0) {
		audio_link = soundFileArray[0];
		var img = document.createElement("i");
		img.className = "fa-solid fa-volume-high audio_button";
		img.alt = "sound";
		button.appendChild(img);
	}
	return button;
}
function playSound() {
	$("#audio_player").toggleClass("fa-fade");
	var sound = new Audio();
	sound.src = audio_link;
	sound.play();
	sound.addEventListener('ended', function () {
		$("#audio_player").toggleClass("fa-fade");
	}, false);
}
function resetPage() {
	if ($('#translatorResult').length > 0) {
		$('#translatorResult').remove();
	}
}
function filter(result) {
	var idioms = false;
	for (var i = 0; i < result.length; i++) {
		var className = result[i].className;
		var id = result[i].id;
		if ((className == "dictionary-name" || className == "relatedWord" || className == "") && id != "tandp") {
			result.splice(i, 1);
			i--;
		} else if (className == "list1") {
			if (idioms == true) {
				result.splice(i, 1);
				i--;
			} else {
				var li = $.parseHTML(result[i].innerHTML)[0];
				var cur = $.parseHTML(li.innerHTML);
				cur.splice(1, cur.length - 1);
				li.innerHTML = cur[0].outerHTML;
				result[i].innerHTML = li.outerHTML;
			}
		} else if (className == "pronunciation") {
			var li = $.parseHTML(result[i].innerHTML)[0];
			var cur = $.parseHTML(li.innerHTML);
		} else {
			idioms = false;
		}
		if (result[i].className == "idioms") {
			result[i].innerHTML = "cụm động từ";
		}
	}
}
function pretty() {
	ta.setAttribute("placeholder", languagePack[localStorage.getItem('languagePack')]['textArea']);
	$(".pronounce")[0].innerHTML = "&nbsp" + $(".pronounce")[0].innerHTML;
	var container = document.createElement("div");
	container.setAttribute("class", "close-container");
	var closebtn = document.createElement("button");
	closebtn.setAttribute("class", "EVTDclose-btn");
	container.appendChild(closebtn);
	closebtn.addEventListener('click', function () {
		responsiveVoice.cancel();
		document.getElementById("translatorResult").remove();
	})
	closebtn.innerHTML = `<i class="fa-solid fa-xmark"></i>`;
	$("#tandp").prepend(container);

	$(".pronounce").appendTo(".word_title");
	$('#audio_player').appendTo(".word_title");
	if (status_get) {
		var node1 = document.createElement("div"),
			load1 = document.createElement("div");
		var ta1 = document.createElement("textarea");
		ta1.setAttribute("class", "f-input");
		ta1.setAttribute("id", "textAreaOrigin");
		ta1.setAttribute("spellcheck", "false");
		ta1.setAttribute("placeholder", languagePack[localStorage.getItem('languagePack')]['textArea']);
		node1.appendChild(ta1);
		ta1.innerText = text;
		var btn1 = document.createElement("button"),
			btn2 = document.createElement("button");
		var divContainer1 = document.createElement("div");
		divContainer1.style = "margin-top: 4.5px";	
		btn1.setAttribute("class", "feature");
		btn1.innerHTML = `<i id="voice-awesome" class="fa-solid fa-volume-high"></i>`;
		btn2.setAttribute("class", "copy");
		btn2.addEventListener('click', function(){
			var copytarget = ta1;
			copytarget.select();
			copytarget.setSelectionRange(0, 99999);
			navigator.clipboard.writeText(copytarget.value);
			copytarget.setSelectionRange(0, 0);
		})
		btn2.innerHTML = `<i class="far fa-clone"></i>`;
		btn1.addEventListener("click", function () {
				responsiveVoice.speak(text, lang_speak[detect_language]);
			}),
		divContainer1.appendChild(btn1);
		divContainer1.appendChild(btn2);
		node1.appendChild(divContainer1);
		node1.setAttribute("class", "textarea-container");
		node1.style.display = 'flex';
		load1.style.display = "block";
		$('.word_title').append(node1);
	}
	$('.word_title').append(node);
		var imageBtn = document.createElement("button");
		imageBtn.innerHTML = languagePack[localStorage.getItem('languagePack')]['translate_imageBtn'] +` <i class="fa-solid fa-images"></i>`;
		imageBtn.setAttribute("class", "imgBtn");

		sentencePanel.style.display = 'none';
		imagePanel.style.display = 'block';
		examplePanel.style.display = 'none'; 
		examplePanel.id="examplePanelEVTDLoader";
		var defBtn = document.createElement("button");
		defBtn.innerHTML = languagePack[localStorage.getItem('languagePack')]['translate_exBtn'] + ` <i class="fa-solid fa-quote-right"></i>`;
		defBtn.setAttribute("class", "imgBtn");
		defBtn.style.marginLeft = '3px';
		var sentenceBtn = document.createElement("button");
		sentenceBtn.innerHTML = languagePack[localStorage.getItem('languagePack')]['translate_sentence']+` <i class="fa-solid fa-comment-dots"></i>`;
		sentenceBtn.setAttribute("class", "imgBtn");
		sentenceBtn.style.marginLeft = '3px';

		sentenceBtn.addEventListener('click', function () {
			imagePanel.style.display = 'none';
			sentencePanel.style.display = 'block';
			examplePanel.style.display = 'none';
			defBtn.style.backgroundColor = imageBtn.style.backgroundColor = 'rgba(255, 255, 255, 0.342)';
			this.style.backgroundColor = 'rgba(255, 255, 255, 0.642)';
		});
		defBtn.addEventListener('click', function(){
			imagePanel.style.display = 'none';
			sentencePanel.style.display = 'none';
			examplePanel.style.display = 'block';
			imageBtn.style.backgroundColor = sentenceBtn.style.backgroundColor = 'rgba(255, 255, 255, 0.342)';
			this.style.backgroundColor = 'rgba(255,255,255,.642)';
		})
		imageBtn.addEventListener('click', function () {
			sentencePanel.style.display = 'none';
			imagePanel.style.display = 'block';
			examplePanel.style.display = 'none';
			defBtn.style.backgroundColor = sentenceBtn.style.backgroundColor = 'rgba(255, 255, 255, 0.342)';
			this.style.backgroundColor = 'rgba(255, 255, 255, 0.642)';
		});

		document.getElementById("tandp").appendChild(imageBtn);
		document.getElementById("tandp").appendChild(defBtn);
		document.getElementById("tandp").appendChild(sentenceBtn);
		document.getElementById("tandp").appendChild(sentencePanel);
		document.getElementById("tandp").appendChild(imagePanel);
		document.getElementById("tandp").appendChild(examplePanel);
		sentenceBtn.style.backgroundColor = 'rgba(255, 255, 255, 0.342)';
		defBtn.style.backgroundColor = 'rgba(255,255,255,.342)';
		sentencePanel.innerHTML = '';
	if(text.length<100){
		const settings = {
		"async": true,
		"crossDomain": true,
		"url": "https://dictionary-by-api-ninjas.p.rapidapi.com/v1/dictionary?word="+text,
		"method": "GET",
		"headers": {
			"X-RapidAPI-Key": "12b7781a77msh2d36dafa39bd357p1eb566jsnb791eae2d7b3",
			"X-RapidAPI-Host": "dictionary-by-api-ninjas.p.rapidapi.com"
		}
	};
	
	$.ajax(settings).done(function (response) {
		var def = document.createElement('div');
		if(response['definition'] == ""){
			def.innerHTML = '<i style="font-size: 20px;" class="fa-solid fa-beer-mug-empty fa-beat"></i>'	;
		} else {
			def.innerText = response['definition'];
		}
		def.style = `padding: 5px; background: rgba(255, 255, 255, 0.27); border-radius: 5px; border: 1px solid rgba(255,255,255,.27); margin-top: 5px`;
		sentencePanel.innerHTML = ``;
		sentencePanel.prepend(def); 
	});
}
	node.after(load);
	$("b").css({
		"font-weight": "600"
	}), $(".idioms").css({
		"border-radius": "6px",
		"border-top": "0px solid #f2f2f2",
		"border-bottom": "0px solid #f2f2f2",
		margin: "5px",
		opacity: "1",
		padding: "4.5px",
		background: "rgba(255, 255, 255, 0.5)",
		color: "#092f47",
		"font-size": "10pt",
		"font-weight": "645",
		"font-family": "'Segoe UI'"
	}), $(".audio_button").css({
		"margin-left": "10px",
		"display": "inline-block",
		width: "14px",
		height: "14px"
	}), $(".audio").css({
		"margin-left": "8px"
	}), $("." + audio_cName).css({
		display: "inline"
	}), $(".pronounce").css({
		"font-size": "13px",
		"display": "inline-block",
		"font-weight": "bold",
		"font-weight": "600",
		"font-family": "'Segoe UI'"
	}), $(".list1").css({
		"list-style-type": "disc",
		background: "none",
		padding: "0px",
		"margin-left": "30px",
		"margin-bottom": "15px"
	}), $(".list1 li").css({
		"list-style-type": "disc",
		background: "none",
		padding: "0px",
		"font-size": "13px",
		"font-weight": "645"
	}), $(".idiom-meaning").css({
		"list-style-type": "disc",
		background: "none",
		padding: "0px",
		"font-size": "13px",
		"font-weight": "600",
		"font-family": "'Segoe UI'"
	})
}