var database ={
    "0": {
        "word": "Hello",
        "type": "động từ",
        "us": "/həˈləʊ/",
        "uk": "həˈləʊ/",
        "mean": "Used as a greeting when you meet somebody, in an email, when you answer the phone or when you want to attract somebody’s attention",
        "img": [
            "https://i.pinimg.com/originals/dd/5a/31/dd5a31c736d9944eccd18bc9372274ab.png",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTozz4GdElsKyXNqyMqdO2hxP2BLH1xQ9Td7w&usqp=CAU"
        ],
        "ex": {
            "Dùng như lời chào hỏi": [
                "Hello John, how are you?",
                "Say hello to Tom for me"
            ],
            "Dùng như sự ngạc nhiên về một cái gì đó": [
                "Hello, hello, what 's going on here?"
            ]
        },
        "vimean": "Được sử dụng như một lời chào khi bạn gặp ai đó, trong email, khi bạn trả lời điện thoại hoặc khi bạn muốn thu hút sự chú ý của ai đó"
    },
    "1": {
        "word": "Happy",
        "type": "cảm thán",
        "us": "/ˈhæpi/",
        "uk": "/ˈhæpi/",
        "mean": "Feeling or showing pleasure; pleased",
        "img": [
            "https://img.freepik.com/free-vector/happy-young-couple-having-fun-girl-guy-dancing-party-celebrating-good-news-flat-illustration_74855-10820.jpg?size=338&ext=jpg&ga=GA1.2.1512964624.1637884800",
            "https://thumbs.dreamstime.com/b/happy-girl-enjoying-freedom-female-person-happy-girl-enjoying-freedom-female-person-spread-arms-wide-nature-outdoor-149509365.jpg"
        ],
        "ex": {
            "Thể hiện niềm vui, sự hạnh phúc": [
                "He always seemed happy enough.",
                "Money won't make you happy."
            ],
            "Cho hoặc tạo ra niềm vui": [
                "I have many happy memories from that time.",
                "The story has a happy ending."
            ]
        },
        "vimean": "Cảm thấy hoặc thể hiện niềm vui; khoái"
    },
    "2": {
        "word": "Enjoy",
        "type": "động từ",
        "us": "/ɪnˈdʒɔɪ/",
        "uk": "/ɪnˈdʒɔɪ/",
        "mean": "To get pleasure from something",
        "img": [
            "https://img.freepik.com/free-vector/enthusiastic-concept-illustration_114360-3478.jpg?size=338&ext=jpg",
            "https://previews.123rf.com/images/jemastock/jemastock1803/jemastock180304532/97214449-happy-man-jumping-cartoon-vector-illustration-graphic-design.jpg"
        ],
        "ex": {
            "Tận hưởng một thứ gì đó": [
                "We thoroughly enjoyed our time in New York.",
                "She seems to be enjoying life in Paris."
            ],
            "Dùng để nói rằng bạn hy vọng ai đó nhận được niềm vui mà bạn đang dành cho họ": [
                "Here's that book I promised you. Enjoy!"
            ],
            "Niềm vui, hạnh phúc từ những gì bạn đang làm": [
                "They all enjoyed themselves at the party."
            ]
        },
        "vimean": "Để có được niềm vui từ một cái gì đó"
    },
    "3": {
        "word": "Believe",
        "type": "động từ",
        "us": "/bɪˈliːv/",
        "uk": "/bɪˈliːv/",
        "mean": "Feel certain that something is true or that somebody is telling you the truth",
        "img": [
            "https://img.freepik.com/free-vector/believe-yourself-happy-life-people-motivating-card_81522-2512.jpg?size=626&ext=jpg",
            "https://img.freepik.com/free-vector/self-image-abstract-concept-vector-illustration-positive-self-image-personal-portrait-social-role-mental-picture-personality-trait-individual-psychology-perception-abstract-metaphor_335657-4224.jpg?size=338&ext=jpg"
        ],
        "ex": {
            "Tin tưởng một ai đó hay một cái gì đó": [
                "The man claimed to be a social worker and she believed him.",
                "I believed his lies for years."
            ],
            "Nghĩ rằng việc gì đó có thể đúng mặc dù bạn không hoàn toàn chắc chắn": [
                "Police believe (that) the man may be armed.",
                "l firmly believe that she is still alive."
            ],
            "Dùng để nói rằng bạn ngạc nhiên hoặc khó chịu về điều gì đó": [
                "She couldn’t believe (that) it was all happening again.",
                "I don't believe I'm doing this!"
            ]
        },
        "vimean": "Cảm thấy chắc chắn rằng một cái gì đó là sự thật hoặc ai đó đang nói với bạn sự thật"
    },
    "4": {
        "word": "Moment",
        "type": "danh từ",
        "us": "/ˈməʊmənt/",
        "uk": "/ˈməʊmənt/",
        "mean": "A very short period of time",
        "img": [
            "https://st3.depositphotos.com/9218878/13468/v/450/depositphotos_134686950-stock-illustration-catch-the-moment-lettering-and.jpg",
            "https://thumbs.dreamstime.com/b/conceptual-caption-enjoy-every-moment-concept-meaning-stay-positive-thinking-personal-development-abstract-working-together-225857510.jpg"
        ],
        "ex": {
            "Một chút, một lúc": [
                "Could you wait a moment, please?",
                "Have you got a moment?"
            ],
            "Một thời điểm tốt để làm một cái gì đó; một cơ hội": [
                "I'm waiting for the right moment to tell him the bad news"
            ]
        },
        "vimean": "Một khoảng thời gian rất ngắn"
    },
    "5": {
        "word": "Viral",
        "type": "tính từ",
        "us": "/ˈvaɪrəl/",
        "uk": "/ˈvaɪrəl/",
        "mean": "● 1 : of, relating to, or caused by a virus a viral infection.<br>● 2 : quickly and widely spread or popularized especially by means of social media a viral video.",
        "img": [
            "https://img.freepik.com/free-vector/man-with-hashtag-viral-illustration-social-network-concept_106954-1027.jpg?size=626&ext=jpg",
            "https://img.freepik.com/free-vector/viral-social-media-information-content_25147-81.jpg?size=626&ext=jpg"
        ],
        "ex": {
            "Giống hoặc do virus gây ra": [
                "Polio is a viral infection that can result in permanent paralysis .",
                "We take a peek at it under a microscope, and maybe we find a viral infection."
            ],
            "Một cái gì đó trở nên nổi tiếng, được lan truyền rộng rãi": [
                "Within 24 hours, the video went viral on YouTube and Facebook."
            ]
        },
        "vimean": "● 1: của, liên quan đến, hoặc gây ra bởi một virus nhiễm virus. <br>● 2: nhanh chóng và rộng rãi lan truyền hoặc phổ biến đặc biệt là thông qua phương tiện truyền thông xã hội một video lan truyền."
    },
    "6": {
        "word": "Health",
        "type": "danh từ",
        "us": "/helθ/",
        "uk": "/helθ/",
        "mean": "The condition of a person’s body or mind",
        "img": [
            "https://image.freepik.com/free-vector/illustration-healthy-lifestyle_53876-28533.jpg",
            "https://img.freepik.com/free-vector/healthy-people-carrying-different-icons_53876-43069.jpg?size=626&ext=jpg"
        ],
        "ex": {
            "Dùng để chỉ sức khỏe thể chất hay sức khỏe tinh thần": [
                "Smoking can seriously damage your health.",
                "Her mental health began to deteriorate."
            ],
            "Trạng thái khỏe mạnh về thể chất và tinh thần": [
                "Slowly they nursed him back to health.",
                "Rest and exercise restored her health."
            ]
        },
        "vimean": "Tình trạng cơ thể hoặc tâm trí của một người"
    },
    "7": {
        "word": "Authentic",
        "type": "tính từ",
        "us": "/ɔːˈθentɪk/",
        "uk": "/ɔːˈθentɪk/",
        "mean": "Describes something that is real or genuine and not counterfeit or describes something reliable, based on fact",
        "img": [
            "https://cdn.w600.comps.canstockphoto.com/authentic-stamp-vector-clipart_csp17513201.jpg"
        ],
        "ex": {
            "Chỉ một cái gì đó đúng và chính xác": [
                "An authentic account of life in the desert",
                "The authentic voice of young black Americans"
            ],
            "Được làm hoàn toàn giống với bản gốc": [
                "Take a trip on an authentic Spanish galleon to the famous Papagayo beach."
            ]
        },
        "vimean": "Mô tả một cái gì đó là thật hoặc chính hãng và không giả mạo hoặc mô tả một cái gì đó đáng tin cậy, dựa trên thực tế"
    },
    "8": {
        "word": "Computer",
        "type": "danh từ",
        "us": "/kəmˈpjuːtə(r)/",
        "uk": "/kəmˈpjuːtər/",
        "mean": "an electronic machine that can store, organize and find information, do processes with numbers and other data, and control other machines",
        "img": [
            "https://media.istockphoto.com/vectors/laptop-computer-isolated-icon-laptop-flat-illustration-vector-id1089763482",
            "https://cdn.dribbble.com/users/77598/screenshots/5919494/media/a9051eeb36604468216dfa7dfed49727.png?compress=1&resize=400x300"
        ],
        "ex": {
            "Máy tính": [
                "The whole process is run and monitored by computer.",
                " He spends all day playing on his computer."
            ]
        },
        "vimean": "Một máy điện tử có thể lưu trữ, tổ chức và tìm kiếm thông tin, thực hiện các quy trình với các con số và dữ liệu khác và kiểm soát các máy khác"
    },
    "9": {
        "word": "Electronic",
        "type": "tính từ",
        "us": "/ɪˌlekˈtrɒnɪk/",
        "uk": "/ɪˌlekˈtrɑːnɪk/",
        "mean": "(of a device) having or using many small parts, such as microchips, that control and direct a small electric current",
        "img": [
            "https://i.pinimg.com/originals/73/1e/f6/731ef69177a949fbc427e1692d1f3be8.png",
            "https://thumbs.dreamstime.com/b/electronic-circuit-board-26592678.jpg"
        ],
        "ex": {
            "Thuộc về thiết bị điện tử": [
                "Airline passengers no longer have to turn off all electronic devices while on the plane.",
                "Sophisticated electronic calculators could give some students an unfair advantage."
            ],
            "Liên quan hoặc kết nối với thiết bị điện tử": [
                "Electronic and mechanical components don't last as long as they used to."
            ]
        },
        "vimean": "(của một thiết bị) có hoặc sử dụng nhiều bộ phận nhỏ, chẳng hạn như vi mạch, điều khiển và điều khiển một dòng điện nhỏ"
    },
    "10": {
        "word": "Update",
        "type": "động từ",
        "us": "/ˌʌpˈdeɪt/",
        "uk": "/ˌʌpˈdeɪt/",
        "mean": "1 : To make something more modern by adding new parts, etc.<br>●2 : To give somebody the most recent information",
        "img": [
            "https://img.freepik.com/free-vector/update-concept-illustration_114360-5204.jpg?size=626&ext=jpg",
            "https://as2.ftcdn.net/v2/jpg/02/88/69/73/500_F_288697338_qkoUtwec6MvvJseJgpr0kEBCSwuQGh4x.jpg"
        ],
        "ex": {
            "Cập nhật một cái gì đó": [
                "It's about time we updated our software."
            ],
            "Cập nhật thông tin vào một cái gì đó": [
                " I'll be updating you shortly.",
                "I called the office to update them on the day's developments."
            ]
        },
        "vimean": "1: Để làm cho một cái gì đó hiện đại hơn bằng cách thêm các phần mới, v.v.<br>●2: Để cung cấp cho ai đó thông tin gần đây nhất"
    },
    "11": {
        "word": "Comment",
        "type": "danh từ",
        "us": "/ˈkɒment/",
        "uk": "/ˈkɑːment/",
        "mean": "Something that you say or write that gives an opinion on or explains somebody/something",
        "img": [
            "https://static2.bigstockphoto.com/6/7/3/large2/376042504.jpg",
            "https://st3.depositphotos.com/5011263/19125/v/1600/depositphotos_191258024-stock-illustration-speech-bubbles-for-comment-and.jpg"
        ],
        "ex": {
            "Nhận xét, bình luận về điều gì đó": [
                "She made helpful comments on my work.",
                "Have you any comment to make about the cause of the disaster?"
            ],
            "Chỉ ra lỗi của điều gì đó": [
                "There was a lot of comment about his behaviour."
            ]
        },
        "vimean": "Một cái gì đó mà bạn nói hoặc viết đưa ra ý kiến về hoặc giải thích ai đó / một cái gì đó"
    },
    "12": {
        "word": "Wacth",
        "type": "động từ",
        "us": "/wɒtʃ/",
        "uk": "/wɑːtʃ/",
        "mean": "To look at somebody/something for a time, paying attention to what happens",
        "img": [
            "https://static.vecteezy.com/system/resources/thumbnails/000/273/378/small/Young_Girl_Watching_TV.jpg",
            "https://thumbs.dreamstime.com/b/vector-illustration-kid-watching-tv-movie-screen-boy-child-childhood-entertainment-fun-happy-cartoon-television-children-girl-157365879.jpg"
        ],
        "ex": {
            "Xem ai đó, cái gì đó": [
                "I was in the living room, watching TV.",
                "We watched to see what would happen next."
            ],
            "Theo dõi một cái gì đó": [
                "We'll watch for any developments.",
                "This election is being closely watched in the region."
            ]
        },
        "vimean": "Nhìn vào ai đó / một cái gì đó trong một thời gian, chú ý đến những gì xảy ra"
    },
    "13": {
        "word": "Book",
        "type": "danh từ",
        "us": "/bʊk/",
        "uk": "/bʊk/",
        "mean": "A set of printed pages that are fastened inside a cover so that you can turn them and read them",
        "img": [
            "https://previews.123rf.com/images/ssstocker/ssstocker1604/ssstocker160400049/55346131-opened-book-illustration-open-book-with-pages-fluttering-vector-illustration.jpg",
            "https://i.pinimg.com/564x/66/e9/09/66e909cf0f6239f0d67f060484c7647b.jpg"
        ],
        "ex": {
            "Quyển sách, cuốn sách": [
                "He has written a book on local architecture.",
                "His desk was covered with piles of books."
            ]
        },
        "vimean": "Một tập hợp các trang in được gắn chặt bên trong bìa để bạn có thể lật chúng và đọc chúng"
    },
    "14": {
        "word": "Pen",
        "type": "danh từ",
        "us": "/pen/",
        "uk": "/pen/",
        "mean": "An instrument made of plastic or metal used for writing with ink (= coloured liquid for writing, etc.)",
        "img": [
            "https://previews.123rf.com/images/rizal999/rizal9991803/rizal999180300047/96788738-pen-cartoon-illustration-cartoon-design-style-.jpg",
            "https://st2.depositphotos.com/5891300/8674/v/950/depositphotos_86749450-stock-illustration-ballpen-pen-vector-illustration.jpg"
        ],
        "ex": {
            "Cây bút mực": [
                "A message written in red pen",
                "I dropped my pen."
            ]
        },
        "vimean": "Một dụng cụ làm bằng nhựa hoặc kim loại được sử dụng để viết bằng mực (= chất lỏng màu để viết, v.v.)"
    },
    "15": {
        "word": "Build",
        "type": "động từ",
        "us": "/bɪld/",
        "uk": "/bɪld/",
        "mean": "To make something, especially a building, by putting parts together",
        "img": [
            "https://cdn.dribbble.com/users/24158/screenshots/12303481/media/7d9b3f7efc03fb599dedcca279daf12c.jpg?compress=1&resize=400x300",
            "https://previews.123rf.com/images/seahorsevector/seahorsevector2009/seahorsevector200900061/154793557-build-city-building-vector-illustration-cartoon-flat-designer-people-create-cityscape-design-holding.jpg"
        ],
        "ex": {
            "Xây dựng một cái gì đó": [
                " They have permission to build 200 new homes.",
                "We build computer systems for large companies.",
                "We focused on building the business one customer at a time."
            ]
        },
        "vimean": "Để tạo ra một cái gì đó, đặc biệt là một tòa nhà, bằng cách đặt các bộ phận lại với nhau"
    },
    "16": {
        "word": "Teamwork",
        "type": "danh từ",
        "us": "/ˈtiːmwɜːk/",
        "uk": "/ˈtiːmwɜːrk/",
        "mean": "​The activity of working well together as a team",
        "img": [
            "https://thumbs.dreamstime.com/b/teamwork-concept-team-building-team-metaphor-together-concept-vector-illustration-flat-cartoon-character-graphic-design-teamwork-141427385.jpg",
            "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/7b218443130741.57e425255227d.jpg"
        ],
        "ex": {
            "Tinh thần đồng đội": [
                "Cô ấy nhấn mạnh tầm quan trọng của tinh thần đồng đội tốt."
            ],
            "Làm việc nhóm": [
                "This emphasizes increasing teamwork skills such as giving and receiving support, communication and sharing.",
                "He treated employees as family, rewarding and encouraging teamwork."
            ]
        },
        "vimean": "Hoạt động làm việc tốt với nhau như một nhóm"
    },
    "17": {
        "word": "Beautiful",
        "type": "tính từ",
        "us": "/ˈbjuːtɪfl/",
        "uk": "/ˈbjuːtɪfl/",
        "mean": "Having beauty; giving pleasure to the senses or to the mind",
        "img": [
            "https://cdn.dribbble.com/users/1355613/screenshots/15754568/media/bc6a59efce4b922c2250a118c1674d28.jpg?compress=1&resize=400x300",
            "https://cdn.dribbble.com/users/3768006/screenshots/9140163/media/d8f494f7d6d9716063012073560e7ed9.jpg?compress=1&resize=400x300"
        ],
        "ex": {
            "Xinh đẹp": [
                "She looked stunningly beautiful that night.",
                "The scenery here is so beautiful."
            ],
            "Rất tốt bụng; làm điều gì đó tuyệt vời": [
                "Thank you—you have done a beautiful thing."
            ]
        },
        "vimean": "Có nhan sắc; Mang lại niềm vui cho các giác quan hoặc cho tâm trí"
    },
    "18": {
        "word": "Intelligent",
        "type": "tính từ",
        "us": "/ɪnˈtelɪdʒənt/",
        "uk": "/ɪnˈtelɪdʒənt/",
        "mean": "good at learning, understanding and thinking in a logical way about things; showing this ability",
        "img": [
            "https://media.istockphoto.com/vectors/creative-icon-of-a-half-brain-half-lightbulb-representing-ideas-vector-id1159741374?k=20&m=1159741374&s=612x612&w=0&h=iOn1afz86ugo6htm-wQcGIfGXRR5xeW9ykRWAL0uaXA=",
            "https://previews.123rf.com/images/unitonevector/unitonevector1904/unitonevector190404255/122914340-smart-boy-having-idea-flat-vector-illustration-genius-intelligent-guy-thinking-creative-solution-sea.jpg"
        ],
        "ex": {
            "Thông minh": [
                "She is clearly extremely intelligent.",
                "He is a highly intelligent person who can think outside the box."
            ]
        },
        "vimean": "giỏi học hỏi, hiểu biết và suy nghĩ một cách hợp lý về mọi thứ; Thể hiện khả năng này"
    },
    "19": {
        "word": "Mind",
        "type": "danh từ",
        "us": "/maɪnd/",
        "uk": "/maɪnd/",
        "mean": "The part of a person that makes them able to be aware of things, to think and to feel",
        "img": [
            "https://img.freepik.com/free-vector/mind-map-concept-illustration_114360-2880.jpg?size=338&ext=jpg&ga=GA1.2.1518270500.1634083200",
            "https://img.freepik.com/free-vector/mind-map-concept-illustration_114360-1727.jpg?size=338&ext=jpg"
        ],
        "ex": {
            "Tâm trí": [
                "She was in a disturbed state of mind.",
                "The campaign to win the hearts and minds of the public continues."
            ],
            "Khả năng suy nghĩ, lập luận": [
                "He had the body of a man and the mind of a child.",
                "His mind is as sharp as ever."
            ]
        },
        "vimean": "Một phần của một người làm cho họ có thể nhận thức được mọi thứ, suy nghĩ và cảm nhận"
    }
}