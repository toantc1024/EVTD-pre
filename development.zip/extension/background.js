var hist = "";
var dict_type = "eng-vi";
localStorage.setItem("dict_type", "en-vi");
localStorage.setItem("target_la", "");
var target_la = "";
chrome.runtime.onMessage.addListener(
	function (request, sender, sendResponse) {
		if (request.message == "query") {
			chrome.tabs.query({
				active: true,
				currentWindow: true
			}, function (tabs) {
				var activeTab = tabs[0];
				lookUp(request.data, activeTab, request.dict);
			});
		} else if (request.message == "history") hist = request.data;
		else if (request.method == "getHist") {
			sendResponse(hist);
			getHist(sendResponse);
			return true;
		} else if (request.message == "dictionaries") {
			chrome.storage.local.set({
				'dict_type': request.data,
				'target_la': request.la
			})
		} else if (request.message == "vdict"){
			chrome.tabs.query({
				active: true,
				currentWindow: true
			}, function(tabs){
				var activeTab = tabs[0];
				VdictDatabase(request.data, activeTab, request.dict);
			})
		}
	});

function VdictDatabase(word, activeTab, dict_type){
	var url = "";
	if (dict_type == "en-vi") {
		url = "http://www.vdict.com/" + word + ",1,0,0.html";
	} else if (dict_type == "en-en") {
		url = "http://www.vdict.com/" + word + ",7,0,0.html";
	} else if (dict_type == "vi-en") {
		url = "http://www.vdict.com/" + word + ",2,0,0.html";
	} else if (dict_type == "fr-vi") {
		url = "http://www.vdict.com/" + word + ",5,0,0.html";
	} else if (dict_type == "cse") {
		url = "http://www.vdict.com/" + word + ",6,0,0.html";
	}
	var xhr = new XMLHttpRequest();
	xhr.onload = receiveData;
	xhr.onerror = receiveError;
	xhr.open('GET', url, true);
	xhr.send();
	function receiveData() {
		var responseText;
		if (this.status == 200) {
			responseText = xhr.responseText;
		} else {
			responseText = "";
		}
		chrome.tabs.sendMessage(activeTab.id, {
			"message": "vdictReply",
			"data": responseText,
			"word": word,
			"la": localStorage.getItem("target_la")
		});
		}
	function receiveError() {
		chrome.tabs.sendMessage(activeTab.id, {
			"message": "vdictReply",
			"data": "",
			"word": word
		});
	}
}

function lookUp(word, activeTab, dict_type) {
	chrome.tabs.sendMessage(activeTab.id, {
		"message": "reply",
		"data": "",
		"word": word
	});
}
chrome.runtime.onInstalled.addListener(function (details) {
	if (details.reason === "install") {
	  window.open("https://github.com/ghelix2004/EVTD-pre/blob/main/Help.md");
	} 
	chrome.storage.local.set({
		'combinationKey': 1,
		'languagePack': "vi",
		'imageCallindex': 0,
		'press-delete': 1,
		"introduction": 1,
		'translateCallindex': 0,
		'popupCallindex': 0,
		'evtdStatus': 1,
		'yourDictionary': '{}',
		'userAccount': null
	});
  });