
    //========================================================//

    var modal_direct = document.getElementById("modalDirect");
    var btn_direct = document.getElementById("open_option");
    btn_direct.onclick = function() {
        modal_direct.style.display = "block";
        modal_direct.style.background = document.body.style.background;
    }
    var direct_yes = document.getElementById("direct-yes");
    var direct_no = document.getElementById("direct-no");
    direct_yes.onclick = function(){
        modal_direct.style.display = "none";
        window.open("https://hand-ebook.blogspot.com/search/label/Th%C6%B0%20Vi%E1%BB%87n%20S%C3%A1ch", "_blank");
    }
    direct_no.onclick = function(){
        modal_direct.style.display = "none";
    }
    //========================================================//

    var modalSetting = document.getElementById("modalSetting"),
        settingClose = document.getElementById('settingClose'),
        open_setting = document.getElementById("open_setting");
    open_setting.onclick = function() {
        modalSetting.style.display = "block";
        document.getElementById("modalSetting").style.background = document.body.style.background;
    }
    settingClose.onclick = function(){
        modalSetting.style.display = "none";
    }
    //========================================================//
