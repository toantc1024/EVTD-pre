
import {
  initializeApp
} from "./firebase-app.js";
const firebaseConfig = {
  apiKey: "AIzaSyD68tUQTr02XIRSlOCidLxADehWFZ3yjMU",
  authDomain: "evtd-app.firebaseapp.com",
  databaseURL: "https://evtd-app-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "evtd-app",
  storageBucket: "evtd-app.appspot.com",
  messagingSenderId: "43580014900",
  appId: "1:43580014900:web:4d8b4d3406cb9330c92561",
  measurementId: "G-GFHLFDQBM5"
};
const app = initializeApp(firebaseConfig);

import {
  getDatabase,
  ref,
  set,
  child,
  onValue,
  get,
  onChildChanged,
  update
} from "./firebase-database.js";

const db = getDatabase();
function UpdateColor(id){
  document.body.style.background = style_code[id];
  document.getElementById("list-hist").style.background = style_code[id];
  document.getElementById("menu").style.background = style_code[id];
  document.getElementById("color-content").style.background = style_code[id];
  document.getElementById("today-content").style.background = style_code[id];
}
function LoadHist(){
  chrome.storage.local.get(["word-list", "yourDictionary"], function(data) {
    if(data["yourDictionary"]==null||data["yourDictionary"]=="{}")
  document.getElementById("history").innerHTML = languagePack[localStorage.getItem('languagePack')]['scriptPopup']['content_empty_history_title'] +"&nbsp<i class='fas fa-search'></i>";
    else {
      var listWord = JSON.parse(data['yourDictionary']);
      // console.log(JSON.parse(data['yourDictionary']));
      var main = document.createElement('div');
      Object.keys(listWord).forEach(function(key){
        var li = document.createElement('li'),
            word = document.createElement('div'),
            mean = document.createElement('div');
        var word_title = document.createElement('button');
        var word_star = document.createElement('button');
        word_star.innerHTML = '<i class="fa-solid fa-star"></i>';
        var word_delete = document.createElement('button');
        word_delete.innerHTML = '<i class="fa-solid fa-xmark"></i>';
        li.appendChild(word_title);
//         li.appendChild(word_star);
 //       li.appendChild(word_delete);
        word_star.setAttribute('class','modalWordButton_star');
        word_delete.setAttribute('class','modalWordButton_delete');
        li.style = `
        margin-bottom: 5px;
        background: #ffffff2e;
    padding: 5px;
    height: 136px!important;
    border: 1px solid rgba(255,255,255,.37);
    border-radius: 5px;`;
    word_title.style = `
    margin-right: 5px;
    background: rgba(255,255,255,.64);
    border: 1px solid rgba(255,255,255,.37);
    border-bottom: none;
    border-radius: 5px;
    font-size:16px;
    border-bottom-left-radius: 0px;
    border-bottom-right-radius: 0px;
    `;
 
        word.style = `background: rgba(255,255,255,.44);
        border: 1px solid rgba(255,255,255,.37);
        border-bottom: none;
        border-radius: 5px;
        border-bottom-right-radius: 0px;
        border-top-left-radius: 0px;
        border-bottom-left-radius: 0px;
        padding: 5px;
        height: 50px;
        overflow-y: auto;
        overflow-x: hidden;
    `;
     
        mean.style=  `
        background: rgb(255 255 255 / 24%);
        border: 1px solid rgba(255,255,255,.37);
        border-bottom: none;
        border-radius: 5px;
        border-top-right-radius: 0px;
        border-top-left-radius: 0px;
        padding: 5px;
        height: 50px;
        overflow-y: auto;
        overflow-x: hidden;
        `;
            word.innerHTML = key;
        mean.innerHTML = listWord[key]['mean']; 
        
        li.appendChild(word);
        word_title.innerHTML = listWord[key]['timestamp'];
        li.appendChild(mean);    
        var deleteQuery = document.createElement('div'),
            deleteQueryContainer = document.createElement('div'),
            deleteQueryYes = document.createElement('button'),
            deleteQueryNo = document.createElement('button'),
            deleteQueryTieuDe = document.createElement('button');
          
        deleteQueryContainer.style.background = document.getElementById('list-hist').style.background;    
        deleteQuery.className = 'modal_deleteQuery';
        deleteQueryContainer.className = 'modal_deleteQueryContainer';
        deleteQueryYes.className = 'modal_deleteQueryYes';
        deleteQueryNo.className = 'modal_deleteQueryNo';
        deleteQueryTieuDe.className = 'modal_deleteQueryTieuDe';
        
        var deletQueryLang = {
         'vi':{
           'deleteQueryTieuDe': 'Xóa thẻ này?',
           'deleteQueryYes': 'Có',
           'deleteQueryNo': 'Không'
         },
         'en':{
           'deleteQueryTieuDe': 'Delete this?',
           'deleteQueryYes': 'Yes',
           'deleteQueryNo': 'No'
         }
        }
        var languagePackQuery = deletQueryLang[localStorage.getItem('languagePack')];
        deleteQueryTieuDe.innerHTML = languagePackQuery['deleteQueryTieuDe'];
        deleteQueryYes.innerHTML = languagePackQuery['deleteQueryYes'];
        deleteQueryNo.innerHTML = languagePackQuery['deleteQueryNo'];
        
        deleteQueryContainer.appendChild(deleteQueryTieuDe);
        deleteQueryContainer.appendChild(deleteQueryYes);
        deleteQueryContainer.appendChild(deleteQueryNo);
        deleteQuery.appendChild(deleteQueryContainer);



        li.appendChild(deleteQuery);
         
        main.appendChild(li);
//document.getElementById('modal_word_delete').addEventListener('click', function(){alert(true)});
      });
      document.getElementById("history").innerHTML = main.innerHTML;
     }
    
  });
}
function AuthenticateUser(userName) {
  const dbRef = ref(db);
  
  function callData(valueData, user){
    UpdateColor(JSON.parse(valueData.val()[user].evtdColor));
 

  }
  
const evtdColor = ref(db, 'UserList/'+JSON.parse(userName)+'/evtdColor');
onValue(evtdColor, (snapshot) => {
UpdateColor(JSON.parse(snapshot.val()));
}, {
  onlyOnce:false
});

const yourDictionary = ref(db, 'UserList/'+JSON.parse(userName)+'/yourDictionary');
onValue(yourDictionary, (snapshot) => {
  chrome.storage.local.set({
    'yourDictionary': snapshot.val()
  });
  LoadHist();
}, {
  onlyOnce:false
});

  get(child(dbRef, "UserList/" + JSON.parse(userName))).then((snapshot) => {
    document.getElementById('content_login_option').innerHTML = snapshot.val().fullname;
   
    if(snapshot.val().deletedHistory == true){
      chrome.storage.local.set({
        'yourDictionary': snapshot.val().yourDictionary,
      });
      update(ref(db, "UserList/" + JSON.parse(localStorage.getItem('user'))), {
        deletedHistory: false
      })
      .then(() => {})
      .catch((error) => {});
    }
    if(snapshot.val().colorChanged == true){
  		localStorage.setItem("style_id",snapshot.val().evtdColor);
      UpdateColor(snapshot.val().evtdColor);
      chrome.storage.local.set({
        'color_code': snapshot.val().evtdColor,
      });
      update(ref(db, "UserList/" + JSON.parse(localStorage.getItem('user'))), {
        colorChanged: false
      })
      .then(() => {})
      .catch((error) => {});
    }
        if(localStorage.getItem('evtd_FirstTimeLogin')==1){
          localStorage.setItem('evtd_FirstTimeLogin', 0);
          //Tai khoan dang nhap truoc
          get(child(dbRef, "UserList/" + JSON.parse(localStorage.getItem('user')))).then((snapshot) => {
                    chrome.storage.local.set({
                      'yourDictionary': snapshot.val().yourDictionary,
                      'color_code': snapshot.val().evtdColor
                    });
                    UpdateColor(snapshot.val().evtdColor);
          });
        } else if (localStorage.getItem('evtd_FirstTimeLogin')==0){
          get(child(dbRef, "UserList/" + JSON.parse(localStorage.getItem('user')))).then((snapshot) => {
            // chrome.storage.local.set({
            //   'yourDictionary': snapshot.val().yourDictionary,
            // });
            localStorage.setItem("style_id", snapshot.val().evtdColor);
            chrome.storage.local.set({
              'color_code': snapshot.val().evtdColor
            });
            UpdateColor(snapshot.val().evtdColor);
            chrome.storage.local.get(['yourDictionary'], function(data){
              var first = JSON.parse(data['yourDictionary']),
                  second = JSON.parse(snapshot.val().yourDictionary);
              Object.keys(first).forEach(function(key){
                if(!second.hasOwnProperty(key)){
                  second[key] = first[key];
                  //console.log(key,' has been added!');
                }
              });
              update(ref(db, "UserList/" + JSON.parse(localStorage.getItem('user'))), {
                        yourDictionary: JSON.stringify(second)
                      })
                      .then(() => {})
                      .catch((error) => {});
            })
          });
        }
        
  });
}

// function Sync(user, data, type) {
//   if (type == "History") {
//     update(ref(db, "UserList/" + user), {
//         History: data
//       })
//       .then(() => {})
//       .catch((error) => {});
//   } else {
//     update(ref(db, "UserList/" + user), {
//         DataWord: data
//       })
//       .then(() => {})
//       .catch((error) => {});
//   }

// }

// function SynchronizeData() {
//   chrome.storage.local.get(["word-list", "word-data"], function (data) {
//     if (data['word-list'] === undefined) {
//       const dbRef = ref(db);
//       get(child(dbRef, "UserList/" + JSON.parse(localStorage.getItem('user')))).then((snapshot) => {
//         chrome.storage.local.set({
//           'word-list': snapshot.val().History,
//           'word-data': snapshot.val().DataWord
//         });
//       });
//     }
//     Sync(JSON.parse(localStorage.getItem('user')), data["word-list"], "History");
//     Sync(JSON.parse(localStorage.getItem('user')), data["word-data"], "DataWord");
//   });

// };

function reset() {
	chrome.storage.local.set({
		'yourDictionary': "{}",
	});
  update(ref(db, "UserList/" + JSON.parse(localStorage.getItem('user'))), {
    yourDictionary: "{}"
  })
  .then(() => {})
  .catch((error) => {});
	document.getElementById("history").innerHTML = languagePack[localStorage.getItem('languagePack')]['scriptPopup']['content_empty_history_title'] +"&nbsp<i class='fas fa-search'></i>";
}

document.addEventListener('DOMContentLoaded', function () {

  // COLOR cho EVTD
  function unpreview(id) {
    var id = localStorage.getItem("style_id");
    document.body.style.background = style_code[id];
    document.getElementById("list-hist").style.background = style_code[id];
    document.getElementById("menu").style.background = style_code[id];
    document.getElementById("color-content").style.background = style_code[id];
    document.getElementById("today-content").style.background = style_code[id];
  }
  
  function preview(id) {
    document.body.style.background = style_code[id];
    document.getElementById("list-hist").style.background = style_code[id];
    document.getElementById("menu").style.background = style_code[id];
    document.getElementById("color-content").style.background = style_code[id];
    document.getElementById("today-content").style.background = style_code[id];
  }
  
  function test(id) {
    localStorage.setItem("style_id", id);
    chrome.storage.local.set({
      'color_code': id
    });
    update(ref(db, "UserList/" + JSON.parse(localStorage.getItem('user'))), {
      evtdColor: id
    })
    .then(() => {})
    .catch((error) => {});
    document.body.style.background = style_code[id];
    document.getElementById("list-hist").style.background = style_code[id];
    document.getElementById("menu").style.background = style_code[id];
    document.getElementById("color-content").style.background = style_code[id];
    document.getElementById("today-content").style.background = style_code[id];
    document.getElementById("modalSetting").style.background = document.body.style.background;
  }
  
  var modal_color = document.getElementById("content"),
      btn_color = document.getElementById("change"),
      span_color = document.getElementsByClassName("hide-close")[0],
      o1 = document.getElementById("btn1"),
      o2 = document.getElementById("btn2"),
      o3 = document.getElementById("btn3"),
      o4 = document.getElementById("btn4"),
      o5 = document.getElementById("btn5"),
      o6 = document.getElementById("btn6"),
      o7 = document.getElementById("btn7"),
      o8 = document.getElementById("btn8"),
      o9 = document.getElementById("btn9");
  btn_color.onclick = function () {
      modal_color.style.display = "block";
  }
  span_color.onclick = function () {
      modal_color.style.display = "none";
  
  }
  o1.onclick = function () {
      modal_color.style.display = "none";
      test(0);
  }
  o2.onclick = function () {
      modal_color.style.display = "none";
      test(1);
  }
  o3.onclick = function () {
      modal_color.style.display = "none";
      test(2);
  }
  o4.onclick = function () {
      modal_color.style.display = "none";
      test(3);
  }
  o5.onclick = function () {
      modal_color.style.display = "none";
      test(4);
  }
  o6.onclick = function () {
      modal_color.style.display = "none";
      test(5);
  }
  o7.onclick = function () {
      modal_color.style.display = "none";
      test(6);
  }
  o8.onclick = function () {
      modal_color.style.display = "none";
      test(7);
  }
  o9.onclick = function () {
      modal_color.style.display = "none";
      test(8);
  }
  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function (event) {
      if (event.target == modal_color) {
          modal_color.style.display = "none";
      }
  }
  o1.onmouseover = function () {
      preview(0);
  }
  o1.onmouseout = function () {
      unpreview(0);
  }
  o2.onmouseover = function () {
      preview(1);
  }
  o2.onmouseout = function () {
      unpreview(1);
  }
  o3.onmouseover = function () {
      preview(2);
  }
  o3.onmouseout = function () {
      unpreview(2);
  }
  
  o4.onmouseover = function () {
      preview(3);
  }
  o4.onmouseout = function () {
      unpreview(3);
  }
  o5.onmouseover = function () {
      preview(4);
  }
  o5.onmouseout = function () {
      unpreview(4);
  }
  o6.onmouseover = function () {
      preview(5);
  }
  o6.onmouseout = function () {
      unpreview(5);
  }
  
  o7.onmouseover = function () {
      preview(6);
  }
  o7.onmouseout = function () {
      unpreview(6);
  }
  o8.onmouseover = function () {
      preview(7);
  }
  o8.onmouseout = function () {
      unpreview(7);
  }
  o9.onmouseover = function () {
      preview(8);
  }
  o9.onmouseout = function () {
      unpreview(8);
  }
//

var modal_logindirect = document.getElementById("loginDirect");
var btn_logindirect = document.getElementById("login_option");
btn_logindirect.onclick = function() {
    modal_logindirect.style.display = "block";
    modal_logindirect.style.background = document.body.style.background;
}
var logindirect_yes = document.getElementById("loginDirect-yes");
var logindirect_no = document.getElementById("loginDirect-no");
logindirect_yes.onclick = function(){
    modal_logindirect.style.display = "none";
    chrome.runtime.openOptionsPage();
}
logindirect_no.onclick = function(){
    modal_logindirect.style.display = "none";
}
document.getElementById('_loginRequired_accountManager').addEventListener('click', function(){  chrome.runtime.openOptionsPage();
});

var modal = document.getElementById("myModal"), hist = document.getElementById("history"), span = document.getElementsByClassName("close")[0];
var show_hist_btn = document.getElementById("show_hist_btn");

show_hist_btn.onclick = function() {
  LoadHist();
  modal.style.display = "block";
  hist.style.display = "block";
}
span.onclick = function() {
  modal.style.display = "none";
  hist.style.display = "none";
}
window.onclick = function(event) {
  if (event.target == modal) modal.style.display = "none";
}
 var modal_reset = document.getElementById("modal-reset");
 var btn_reset = document.getElementById("reset-btn");
 btn_reset.onclick = function() {
     modal_reset.style.display = "block";
     modal_reset.style.background = document.body.style.background;
 }
 var btn_yes = document.getElementById("reset-yes");
 var btn_no = document.getElementById("reset-no");
 btn_yes.onclick = function(){
     reset();
     modal_reset.style.display = "none";
 }
 btn_no.onclick = function(){
     modal_reset.style.display = "none";
 }
 //

  document.getElementById('_loginRequired_accountManager').addEventListener('click', function(){  chrome.runtime.openOptionsPage();
  });
  var userName = localStorage.getItem('user');
  if (userName == null) {
    document.getElementById('content_login_option').innerHTML = `Đăng nhập`;
    var obj = document.getElementById('loginRequired');
    obj.style.display = 'block';
    var code_id = localStorage.getItem('style_id');
    if (code_id==null)code_id = 0;
    obj.style.background = style_code[code_id];
  } else {
    //SynchronizeData();
    chrome.storage.local.set({"userAccount": JSON.parse(userName)});
    AuthenticateUser(userName);
  }

});

// document.getElementById("reset-yes").addEventListener('click', function () {
//   var userName = localStorage.getItem('user');
//   if (userName != null) {
//     update(ref(db, "UserList/" + JSON.parse(userName)), {
//         History: ""
//       })
//       .then(() => {})
//       .catch((error) => {});
//       update(ref(db, "UserList/" + JSON.parse(userName)), {
//         DataWord: ""
//       })
//       .then(() => {})
//       .catch((error) => {});
//   }
// })


